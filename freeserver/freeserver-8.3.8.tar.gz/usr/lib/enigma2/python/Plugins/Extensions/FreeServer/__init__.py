# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/ALAJRE/outils/__init__.py
pass