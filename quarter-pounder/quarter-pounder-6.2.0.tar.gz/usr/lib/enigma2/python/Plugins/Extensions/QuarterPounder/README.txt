Enigma2 Quarter Pounder.

Attempts to detect a stuck stream and to
restart it.

@oottppxx
