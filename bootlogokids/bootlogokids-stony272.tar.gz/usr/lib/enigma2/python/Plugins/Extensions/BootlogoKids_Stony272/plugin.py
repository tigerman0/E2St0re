from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console
from Screens.Standby import TryQuitMainloop
from Components.ActionMap import ActionMap
from Components.AVSwitch import AVSwitch
from Components.config import config, configfile, ConfigYesNo, ConfigSubsection, getConfigListEntry, ConfigSelection, ConfigNumber, ConfigText, ConfigInteger
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.Language import language
from os import environ, listdir, remove, rename, system
from skin import parseColor
from Components.Pixmap import Pixmap
from Components.Label import Label
import gettext
from enigma import ePicLoad
from Tools.Directories import fileExists, resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS

#############################################################

lang = language.getLanguage()
environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("BootlogosKids", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/Bootlogo_Stony272/locale/"))

def _(txt):
	t = gettext.dgettext("BootlogosKids", txt)
	if t == txt:
		t = gettext.gettext(txt)
	return t

def translateBlock(block):
	for x in TranslationHelper:
		if block.__contains__(x[0]):
			block = block.replace(x[0], x[1])
	return block

#############################################################
#############################################################
config.plugins.BootlogosKids = ConfigSubsection()
config.plugins.BootlogosKids.active = ConfigSelection(default="Bootlogo1", choices = [
				("Bootlogo1", _("Bootlogo1")),
				("Bootlogo2", _("Bootlogo2")),
				("Bootlogo3", _("Bootlogo3")),
				("Bootlogo4", _("Bootlogo4")),
				("Bootlogo5", _("Bootlogo5")),
				("Bootlogo6", _("Bootlogo6")),
				("Bootlogo7", _("Bootlogo7")),
				("Bootlogo8", _("Bootlogo8")),
				("Bootlogo9", _("Bootlogo9")),
				("Bootlogo10", _("Bootlogo10")),
				("Bootlogo11", _("Bootlogo11")),
				("Bootlogo12", _("Bootlogo12")),
				("Bootlogo13", _("Bootlogo13")),
				("Bootlogo14", _("Bootlogo14")),
				("Bootlogo15", _("Bootlogo15")),
				("Bootlogo16", _("Bootlogo16")),
				("Bootlogo17", _("Bootlogo17")),
				("Bootlogo18", _("Bootlogo18")),
				("Bootlogo19", _("Bootlogo19")),
				("Bootlogo20", _("Bootlogo20")),
				("Bootlogo21", _("Bootlogo21")),
				("Bootlogo22", _("Bootlogo22")),
				("Bootlogo23", _("Bootlogo23")),
				("Bootlogo24", _("Bootlogo24")),
				("Bootlogo25", _("Bootlogo25")),
				("Bootlogo26", _("Bootlogo26")),
				("Bootlogo27", _("Bootlogo27")),
				("Bootlogo28", _("Bootlogo28")),
				("Bootlogo29", _("Bootlogo29")),
				("Bootlogo30", _("Bootlogo30")),
				("Bootlogo31", _("Bootlogo31")),
				("Bootlogo32", _("Bootlogo32"))
				])
#############################################################
#############################################################

class BootlogosKids(ConfigListScreen, Screen):
	skin = """
  <screen name="Bootlogo-Setup" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#90000000">
    <eLabel name="new eLabel" position="390,90" zPosition="-2" size="500,540" backgroundColor="#20000000" transparent="0" />
    <eLabel font="Regular; 20" foregroundColor="unffffff" backgroundColor="#20000000" halign="left" position="427,595" size="250,33" text="Cancel" transparent="1" />
    <eLabel font="Regular; 20" foregroundColor="unffffff" backgroundColor="#20000000" halign="left" position="727,595" size="250,33" text="Save" transparent="1" />
    <widget name="config" position="410,400" size="460,150" scrollbarMode="showOnDemand" transparent="1" />
    <eLabel position="415,115" size="498,50" text="BootlogoKids-Stony272" font="Regular; 40" valign="center" transparent="1" backgroundColor="#20000000" />
    <eLabel position="710,590" size="5,40" backgroundColor="#61e500" />
    <eLabel position="410,590" size="5,40" backgroundColor="#e61700" />
    <widget name="bootlogohelperimage" position="515,200" size="250,141" zPosition="1" />
  </screen>
"""

	def __init__(self, session, args = None, picPath = None):
		self.config_lines = []
		Screen.__init__(self, session)
		self.session = session
		self.bootlogosourcepath = "/usr/lib/enigma2/python/Plugins/Extensions/BootlogoKids_Stony272/logos/"
		self.picPath = picPath
		self.Scale = AVSwitch().getFramebufferScale()
		self.PicLoad = ePicLoad()
		self["bootlogohelperimage"] = Pixmap()
		list = []
		list.append(getConfigListEntry(_("Select Bootlogo:"), config.plugins.BootlogosKids.active))
		ConfigListScreen.__init__(self, list)
		self["actions"] = ActionMap(["OkCancelActions","DirectionActions", "InputActions", "ColorActions"], {"left": self.keyLeft,"down": self.keyDown,"up": self.keyUp,"right": self.keyRight,"red": self.exit,"yellow": self.reboot, "blue": self.showInfo, "green": self.save,"cancel": self.exit}, -1)
		self.onLayoutFinish.append(self.UpdatePicture)

	def GetPicturePath(self):
		try:
			returnValue = self["config"].getCurrent()[1].value
			path = "/usr/lib/enigma2/python/Plugins/Extensions/BootlogoKids_Stony272/preview/" + returnValue + ".png"
			return path
		except:
			return "/usr/lib/enigma2/python/Plugins/Extensions/BootlogoKids_Stony272/preview/nopreview.png"

	def UpdatePicture(self):
		self.PicLoad.PictureData.get().append(self.DecodePicture)
		self.onLayoutFinish.append(self.ShowPicture)

	def ShowPicture(self):
		self.PicLoad.setPara([self["bootlogohelperimage"].instance.size().width(),self["bootlogohelperimage"].instance.size().height(),self.Scale[0],self.Scale[1],0,1,"#20000000"])
		self.PicLoad.startDecode(self.GetPicturePath())

	def DecodePicture(self, PicInfo = ""):
		ptr = self.PicLoad.getData()
		self["bootlogohelperimage"].instance.setPixmap(ptr)

	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		self.ShowPicture()

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		self.ShowPicture()

	def keyDown(self):
		self["config"].instance.moveSelection(self["config"].instance.moveDown)
		self.ShowPicture()

	def keyUp(self):
		self["config"].instance.moveSelection(self["config"].instance.moveUp)
		self.ShowPicture()

	def reboot(self):
		restartbox = self.session.openWithCallback(self.restartSTB,MessageBox,_("Do you really want to reboot now?"), MessageBox.TYPE_YESNO)
		restartbox.setTitle(_("Restart STB"))

	def showInfo(self):
		self.session.open(MessageBox, _("Information"), MessageBox.TYPE_INFO)

	def save(self):
		for x in self["config"].list:
			if len(x) > 1:
					x[1].save()
			else:
					pass
		configfile.save()
		self.changebootlogo()
		configfile.save()

		#self.session.open(MessageBox, _("Configuration files successfully generated!.\nTo apply changes reboot your Box and start OscamSmartcard in Softcampanel!"), MessageBox.TYPE_INFO)
		restartbox = self.session.openWithCallback(self.restartSTB,MessageBox,_("Your STB needs a restart to apply the new bootlogo.\nDo you want to Restart you STB now?"), MessageBox.TYPE_YESNO)
		restartbox.setTitle(_("Restart STB"))

	def changebootlogo(self):
		try:
			self.bootlogoactive = (config.plugins.BootlogosKids.active.value + ".mvi")
			self.bootlogosource = (self.bootlogosourcepath + self.bootlogoactive)
			self.bootlogotarget = "/usr/share/bootlogo.mvi"
			self.bootlogocommand = (self.bootlogosource + " " + self.bootlogotarget)
			#print "[Bootlogo] ", self.bootlogocommand
			system('cp -f ' + self.bootlogocommand)
			self.config_lines = []
		except:
			self.session.open(MessageBox, _("Error setting Bootlogo!"), MessageBox.TYPE_ERROR)
			self.config_lines = []

	def restartSTB(self, answer):
		if answer is True:
			configfile.save()
			system('reboot')
		else:
			self.close()

	def exit(self):
		for x in self["config"].list:
			if len(x) > 1:
					x[1].cancel()
			else:
					pass
		self.close()

#############################################################

def main(session, **kwargs):
	session.open(BootlogosKids)

def Plugins(**kwargs):
	return PluginDescriptor(name="Bootlogo", description=_("Select your Bootlogo"), where = PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main)