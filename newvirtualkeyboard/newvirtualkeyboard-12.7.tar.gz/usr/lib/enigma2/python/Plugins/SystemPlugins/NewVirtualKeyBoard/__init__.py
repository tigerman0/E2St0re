import os

if os.path.exists('/tmp/VirtualKeyBoard.log'):
	os.system('rm -f /tmp/VirtualKeyBoard.log')
