# -*- coding: utf-8 -*-
#===============================================================================
# OscamStatus Plugin by puhvogel 2011-2018
# modified by Pr2 
#
# This is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2, or (at your option) any later
# version.
#===============================================================================
# ******************************************************************************
VERSION = "6.3"
# ******************************************************************************
#from .__init__ import _

from . import _
from Plugins.Plugin import PluginDescriptor

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox

from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.Button import Button
from Components.ProgressBar import ProgressBar
from Components.MenuList import MenuList
from Components.ConfigList import ConfigListScreen
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaBlend, MultiContentEntryPixmapAlphaTest

from Tools.Directories import fileExists, resolveFilename, SCOPE_CURRENT_PLUGIN

from enigma import ePicLoad, eTimer, getDesktop, eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, RT_WRAP, ePythonMessagePump, ePoint
from Tools.LoadPixmap import LoadPixmap

from .OscamStatusSetup import logstatusin
from .OscamStatusSetup import logfileschrift

#from Components.SystemInfo import BoxInfo


from .OscamStatusSetup import globalsConfigScreen




try:
    from Components.Renderer.Picon import getPiconName
    getPiconsName = True
except:
    getPiconsName = False

from threading import Thread, Lock
import xml.dom.minidom

import re
import glob
import sys
import os
runningcam = "nocam"

# abfrage python und umwandeln
if sys.version_info[0] >= 3:
    import urllib.request, urllib.error, urllib.parse
    from xml.dom.minidom import parse, parseString
else:
    import urllib2


from .OscamStatusSetup import oscamServer, readCFG, OscamServerEntriesListConfigScreen, \
                             globalsConfigScreen, LASTSERVER, XOFFSET, EXTMENU, USEECM,\
                             dlg_xh, USEPICONS
from Plugins.Plugin import PluginDescriptor
# --------------------------- Logfile -------------------------------

from datetime import datetime
from shutil import copyfile
from os import remove
from os.path import isfile
########################### log file loeschen ##################################

myfile="/tmp/oscamstatus_plugin.log"

## If file exists, delete it ##
if isfile(myfile):
    remove(myfile)
############################## File copieren ############################################


###########################  log file anlegen ##################################
# kitte888 logfile anlegen die eingabe in logstatus

logstatus = "off"
logstatus = logstatusin
# ________________________________________________________________________________

def write_log(msg):
    if logstatus == ('on'):
        with open(myfile, "a") as log:

            log.write(datetime.now().strftime("%Y/%d/%m, %H:%M:%S.%f") + ": " + msg + "\n")

            return
    return

# ****************************  test ON/OFF Logfile ************************************************


def logout(data):
    if logstatus == ('on'):
        write_log(data)
        return
    return


# ----------------------------- so muss das commando aussehen , um in den file zu schreiben  ------------------------------
logout(data="start")
logout(data="logstatusin")
logout(data=str(logstatusin))
logout(data="logfileschrift")
logout(data=str(logfileschrift))






TIMERTICK = 10000
QXGA = False
FULLHD = False
if getDesktop(0).size().width() > 1920:
    QXGA = True
    logout(data="QXGA")
if getDesktop(0).size().width() == 1920:
    logout(data="FULLHD")
    FULLHD = True

def getPicon(channelname):
    logout(data="piconname")
    searchPiconPaths = ['/usr/share/enigma2/picon/', '/media/usb/picon/', '/media/cf/picon/', '/picon/', '/media/hdd/picon/']
    channelname = re.sub(r'\[.*?\]', '', channelname)
    channelname = re.sub('[^a-z0-9]', '', channelname.replace('&', 'and').replace('+', 'plus').replace('*', 'star').lower())
    for path in searchPiconPaths:
        pngname = path + channelname + ".png"
        if fileExists(pngname):
            return pngname
        elif len(channelname) > 2 and channelname.endswith('hd'):
            pngname = path + channelname[:-2] + ".png"
            if fileExists(pngname):
                return pngname      
    pngname=resolveFilename(SCOPE_CURRENT_PLUGIN, "Extensions/OscamStatus/icons/unknown.png")
    return pngname


# Converts past seconds into days, hours, minutes and seconds ...
def elapsedTime(s, fmt, hasDays = False):
    logout(data="elapsedtime")
    try:
        if sys.version_info[0] >= 3:
            secs = int(s)
        else:
            secs = long(s)
        if hasDays:
            days, secs = divmod(secs, 86400)
        hours, secs = divmod(secs, 3600)
        mins, secs = divmod(secs, 60)
        if hasDays:
            return fmt % (days, hours, mins, secs)
        else:
            return fmt % (hours, mins, secs)
    except ValueError:
        return s

class ThreadQueue:
    logout(data="threadqueue")
    def __init__(self):
        logout(data="init")
        self.__list = [ ]
        self.__lock = Lock()

    def push(self, val):
        logout(data="push")
        lock = self.__lock
        lock.acquire()
        self.__list.append(val)
        lock.release()

    def pop(self):
        logout(data="pop")
        lock = self.__lock
        lock.acquire()
        ret = self.__list.pop()
        lock.release()
        return ret

THREAD_WORKING = 1
THREAD_FINISHED = 2
THREAD_ERROR = 3

# twisted can not digest auth, whatever ...
class GetPage2(Thread):
    logout(data="getpage2")
    def __init__(self):
        logout(data="getpage2_init")
        Thread.__init__(self)
        self.__running = False
        self.__messages = ThreadQueue()
        self.__messagePump = ePythonMessagePump()

    def __getMessagePump(self):
        logout(data="getmessagepump")
        return self.__messagePump

    def __getMessageQueue(self):
        logout(data="getmesssage queue")
        return self.__messages

    def __getRunning(self):
        logout(data="getrunning")
        return self.__running

    MessagePump = property(__getMessagePump)
    Message = property(__getMessageQueue)
    isRunning = property(__getRunning)

    def Start(self, url, username, password):
        logout(data="start_user.pass")
        if not self.__running:
            self.url = url
            logout(data=str(url))
            self.username = username
            logout(data=str(username))
            self.password = password
            logout(data=str(password))
            self.start()

    def run(self):
        logout(data="run")
        mp = self.__messagePump
        logout(data=str(mp))
        self.__running = True
        self.__cancel = False

        if sys.version_info[0] >= 3:
            PasswdMgr = urllib.request.HTTPPasswordMgrWithDefaultRealm()
            PasswdMgr.add_password(None, self.url, self.username, self.password)

            handler = urllib.request.HTTPDigestAuthHandler(PasswdMgr)
            opener = urllib.request.build_opener(urllib.request.HTTPHandler, handler)

            urllib.request.install_opener(opener)
            request = urllib.request.Request(self.url)

            self.__messages.push((THREAD_WORKING, "Download Thread is running"))
            logout(data=str("mp-1"))
            mp.send(0)

            try:
                logout(data=str("mp-2"))
                page = urllib.request.urlopen(request, timeout=5).read()


            except urllib.error.URLError as err:
                logout(data=str("mp-3"))
                error = "Error: "
                if hasattr(err, "code"):
                    logout(data=str("mp-4"))
                    error += str(err.code)
                if hasattr(err, "reason"):
                    logout(data=str("mp-5"))
                    error += str(err.reason)
                logout(data=str("mp-6"))
                self.__messages.push((THREAD_ERROR, error))

            except Exception:
                logout(data=str("mp_error"))
                self.__messages.push((THREAD_ERROR, "General Exception Error!\n(no Osamserver?)"))

            else:
                self.__messages.push((THREAD_FINISHED, page))
        else:
            PasswdMgr = urllib2.HTTPPasswordMgrWithDefaultRealm()
            PasswdMgr.add_password(None, self.url, self.username, self.password)

            handler = urllib2.HTTPDigestAuthHandler(PasswdMgr)
            opener = urllib2.build_opener(urllib2.HTTPHandler, handler)

            urllib2.install_opener(opener)
            request = urllib2.Request(self.url)

            self.__messages.push((THREAD_WORKING, "Download Thread is running"))
            mp.send(0)

            try:
                page = urllib2.urlopen(request, timeout=5).read()

            except urllib2.URLError as err:
                error = "Error: "
                if hasattr(err, "code"):
                    error += str(err.code)
                if hasattr(err, "reason"):
                    error += str(err.reason)
                self.__messages.push((THREAD_ERROR, error))

            except Exception:
                self.__messages.push((THREAD_ERROR, "General Exception Error!\n(no Oscamserver?)"))

            else:
                self.__messages.push((THREAD_FINISHED, page))

        mp.send(0)

        self.__running = False
        Thread.__init__(self)


getPage2 = GetPage2()


class oscamdata:
    def __init__(self):
        logout(data="oscamdatat_init")
        self.version = "n/a"
        self.revision = "n/a"
        self.starttime = "n/a"
        self.uptime = "n/a"
        self.readonly = "n/a"

class ncamdata:
    def __init__(self):
        logout(data="ncamdatat_init")
        self.version = "n/a"
        self.revision = "n/a"
        self.starttime = "n/a"
        self.uptime = "n/a"
        self.readonly = "n/a"

class client:
    def __init__(self):
        logout(data="client_init")
        self.type = "n/a"
        self.name = "n/a"
        self.protocol = "n/a"
        self.protocolext = "n/a"
        self.au = "n/a"
        self.caid = "n/a"
        self.provid = "n/a"
        self.srvid = "n/a"
        self.ecmtime = "n/a"
        self.ecmhistory = "n/a"
        self.answered = "n/a"
        self.service = "n/a"
        self.login = "n/a"
        self.online = "n/a"
        self.idle = "n/a"
        self.ip = "n/a"
        self.port = "n/a"
        self.connection = "n/a"

class user:
    def __init__(self):
        logout(data="user_init")
        self.name = "n/a"
        self.status = "n/a"
        self.ip = "n/a"
        self.protocol = "n/a"
        self.timeonchannel = "n/a" # ab 6793

class reader:
    def __init__(self):
        logout(data="reader_init")
        self.label = "n/a"
        self.hostaddress = "n/a"
        self.hostport = "n/a"
        self.totalcards = "n/a"
        self.cards = []

class card:
    def __init__(self):
        logout(data="card_init")
        self.number = "n/a"
        self.caid = "n/a"
        self.provid = "n/a"
        self.system = "n/a"
        self.reshare = "n/a"
        self.hop = "n/a"
        self.shareid = "n/a"
        self.remoteid = "n/a"
        self.totalproviders = "n/a"
        self.providers = []
        self.totalnodes = "n/a"
        self.nodes = []

class provider: 
    def __init__(self):
        logout(data="provider_init")
        self.number = "n/a"
        self.sa = "n/a"
        self.caid = "n/a"
        self.provid = "n/a"
        self.service = "n/a"

class pnode:
    def __init__(self):
        logout(data="pnode_init")
        self.number = "n/a"
        self.hexval = "n/a"

class ecm:
    def __init__(self):
        logout(data="ecm_init")
        self.caid = "n/a"
        self.provid = "n/a"
        self.srvid = "n/a"
        self.channelname = "n/a"
        self.avgtime = "n/a"
        self.lasttime = "n/a"
        self.rc = "n/a"
        self.rcs = "n/a"
        self.lastrequest = "n/a"
        self.val = "n/a"

class emm:
    def __init__(self):
        logout(data="emm_init")
        self.type = "n/a"
        self.result = "n/a"
        self.val = "n/a"

class readerlist:
    def __init__(self):
        logout(data="readerlist_init")
        self.label = "n/a"
        self.protocol = "n/a"
        self.type = "n/a"
        self.enabled = "n/a"



#**************************************************************************************************************************************************************************



# ReaderServiceDataScreen...
class ReaderServiceDataScreen(Screen):
    logout(data="ReaderServiceDataScreen")
    if FULLHD:
        skin = """
            <screen name="ReaderDataScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="11" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget source="data" render="Listbox" position="20,130" size="1000,400" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" transparent="1"  scrollbarMode="showOnDemand">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryText(pos = (  1, 0), size = ( 55, 42), font=0, flags = RT_HALIGN_LEFT, text = 0),
                            MultiContentEntryText(pos = ( 60, 0), size = ( 80, 42), font=0, flags = RT_HALIGN_LEFT, text = 1),
                            MultiContentEntryText(pos = (145, 0), size = (340, 42), font=0, flags = RT_HALIGN_LEFT, text = 2),
                            MultiContentEntryText(pos = (500, 0), size = (130, 42), font=0, flags = RT_HALIGN_LEFT, text = 3),
                            MultiContentEntryText(pos = (635, 0), size = ( 50, 42), font=0, flags = RT_HALIGN_LEFT, text = 4),
                        ],
                        "fonts": [gFont("Regular", 25)],
                        "itemHeight": 50
                        }
                    </convert>
                </widget>
            </screen>"""
    else:
        skin = """
            <screen name="ReaderDataScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="11" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget source="data" render="Listbox" position="20,130" size="1000,400" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" transparent="1"  scrollbarMode="showOnDemand">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryText(pos = (  1, 0), size = ( 55, 42), font=0, flags = RT_HALIGN_LEFT, text = 0),
                            MultiContentEntryText(pos = ( 60, 0), size = ( 80, 42), font=0, flags = RT_HALIGN_LEFT, text = 1),
                            MultiContentEntryText(pos = (145, 0), size = (340, 42), font=0, flags = RT_HALIGN_LEFT, text = 2),
                            MultiContentEntryText(pos = (500, 0), size = (130, 42), font=0, flags = RT_HALIGN_LEFT, text = 3),
                            MultiContentEntryText(pos = (635, 0), size = ( 50, 42), font=0, flags = RT_HALIGN_LEFT, text = 4),
                        ],
                        "fonts": [gFont("Regular", 25)],
                        "itemHeight": 50
                        }
                    </convert>
                </widget>
            </screen>"""

    def __init__(self, session, r):
        self.skin = ReaderServiceDataScreen.skin
        self.session = session
        Screen.__init__(self, session)

        tmp = []
        for c in r[0].cards:
            for p in c.providers:
                tmp.append((c.caid, p.provid, p.service, c.system, c.number))

        self["title"] = StaticText(str(len(tmp))+' Services@'+r[0].label+'('+r[0].hostaddress+')')

        if sys.version_info[0] >= 3:
            self["data"] = List(sorted(tmp, key=lambda x: (x[0], x[1])))
        else:
            def compare(a, b):
                return cmp(a[0], b[0]) or cmp(a[1], b[1])
            self["data"] = List(sorted(tmp, compare))

        self["actions"] = ActionMap(["OkCancelActions"],
        {
            "cancel": self.close
        }, -1)



        self.onLayoutFinish.append(self.LayoutFinished)

    def LayoutFinished(self):
        pass



# ClientDataScreen...
class ClientDataScreen(Screen):
    logout(data="ClientDataScreen")
    if FULLHD:
        # HD skin  -------------------------------------  Reader Info   Part 2 ist links und part 1 rechts ---------------------------------------
        part1 = """
                
             <screen name="ClientDataScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="Reader Info">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="10" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="lprotocol" position="  20,180" size="120,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "protocol" position="140,180" size="435,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lprotocolext" position=" 20,100" size="120,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "protocolext" position="140,100" size="1000,70" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lau" position=" 20,230" size="120,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "au" position="140,230" size="235,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lcaid" position=" 20,580" size="120,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "caid" position="140,580" size="235,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lprovid" position="20,280" size="130,40" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "provid" position="140,280" size="190,40" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lsrvid" position=" 20,530" size="120,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "srvid" position="140,530" size="235,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lecmtime" position=" 20,330" size="120,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "ecmtime" position="140,330" size="235,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lecmhistory" position=" 20,380" size="120,80" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="historymax" position=" 525,390" size="40,26" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="historymin" position=" 535,480" size="40,26" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>"""


        ecmhistory = ""
        x = 210
        for i in range(20):
            ecmhistory += "<widget name=\"progress%d\" zPosition=\"4\" position=\"%d,393\" size=\"15,117\" transparent=\"1\" borderColor=\"#404040\" borderWidth=\"1\" orientation=\"orBottomToTop\" />\n" % (i, x)
            x += 15

        part2 = """
                     <widget render="Label" source="lanswered" position=" 620,530" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "answered" position="840,530" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source="lservice" position=" 620,180" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "service" position="840,180" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source="llogin" position=" 620,230" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "login" position="840,230" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source="lonline" position=" 620,280" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "online" position="840,280" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source="lidle" position=" 620,330" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "idle" position="840,330" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source="lip" position=" 620,380" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "ip" position="840,380" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source="lport" position=" 620,430" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "port" position="840,430" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source="lconnection" position=" 620,480" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "connection" position="840,480" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget name="KeyYellow" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/bt_yellow.png" position="1050,480" size="35,25" zPosition="4" transparent="1" alphatest="on"/>
                </screen>"""
    else:
        part1 = """
                <screen name="ClientDataScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="Reader Info">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="10" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="lprotocol" position="  20,180" size="120,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "protocol" position="140,180" size="435,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lprotocolext" position=" 20,100" size="120,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "protocolext" position="140,100" size="1000,70" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lau" position=" 20,230" size="120,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "au" position="140,230" size="235,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lcaid" position=" 20,580" size="120,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "caid" position="140,580" size="235,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lprovid" position="20,280" size="130,40" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "provid" position="140,280" size="190,40" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lsrvid" position=" 20,530" size="120,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "srvid" position="140,530" size="235,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lecmtime" position=" 20,330" size="120,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "ecmtime" position="140,330" size="235,30" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lecmhistory" position=" 20,380" size="120,80" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="historymax" position=" 525,390" size="40,26" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="historymin" position=" 535,480" size="40,26" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>"""


        ecmhistory = ""
        x = 140
        for i in range(20):
            ecmhistory += "<widget name=\"progress%d\" zPosition=\"4\" position=\"%d,362\" size=\"10,78\" transparent=\"1\" borderColor=\"#404040\" borderWidth=\"1\" orientation=\"orBottomToTop\" />\n" % (i, x)
            x += 10

        part2 = """
                     <widget render="Label" source="lanswered" position=" 620,530" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "answered" position="840,530" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source="lservice" position=" 620,180" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "service" position="840,180" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source="llogin" position=" 620,230" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "login" position="840,230" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source="lonline" position=" 620,280" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "online" position="840,280" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source="lidle" position=" 620,330" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "idle" position="840,330" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source="lip" position=" 620,380" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "ip" position="840,380" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source="lport" position=" 620,430" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "port" position="840,430" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source="lconnection" position=" 620,480" size="120,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget render="Label" source= "connection" position="840,480" size="235,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                    <widget name="KeyYellow" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/bt_yellow.png" position="1050,480" size="35,25" zPosition="4" transparent="1" alphatest="on"/>
                </screen>"""

    def __init__(self, session, type, oServer, data):
        logout(data="ClientDataScreen-init")
        self.skin = ClientDataScreen.part1+ClientDataScreen.ecmhistory+ClientDataScreen.part2
        print(self.skin)
        self.session = session
        self.type = type
        self.oServer = oServer
        logout(data=str(oServer))
        Screen.__init__(self, session)

        # dict for Status AU
        auEntrys = {"1":"ACTIVE", "0":"OFF", "-1":"ON"}

        self["title"] = StaticText("")
        self["KeyYellow"] = Pixmap()
        self["KeyYellow"].hide()

        if type == "clients":
            logout(data="ClientDataScreen-clients")
            self["title"].setText(_("Client")+" "+data.name+"@"+oServer.serverName)
        else:
            logout(data="ClientDataScreen-reader")
            self["title"].setText(_("Reader")+" "+data.name+"@"+oServer.serverName)
            if data.protocol.startswith("cccam"):
                self["KeyYellow"].show()

        self.ecmhistory = data.ecmhistory.split(',')
        # really great if in the OSCAM sources the ecmhistory is changed meaningless ...
        if self.ecmhistory[0] == '':
            self.ecmhistory[0] = '0'
        if len(self.ecmhistory) < 20:
            for x in range(20 - len(self.ecmhistory)):
                 self.ecmhistory.append('0')

        maxh = 0.0
        for i in range(20):
            self["progress%d" % i] = ProgressBar()
            self.ecmhistory[i] = float(self.ecmhistory[i])
            if self.ecmhistory[i] > maxh:
                maxh = self.ecmhistory[i]
        if maxh < 1000.0:
            self.base = 1000.0
        elif maxh < 2000.0:
            self.base = 2000.0
        elif maxh < 3000.0:
            self.base = 3000.0
        elif maxh < 4000.0:
            self.base = 4000.0
        elif maxh < 5000.0:
            self.base = 5000.0
        else:
            self.base = 9999.0

        self.name = data.name
        self.protocol = data.protocol
        self["lprotocol"] = StaticText("protocol:")
        self[ "protocol"] = StaticText(data.protocol)
        self["lprotocolext"] = StaticText("protocolext:")
        if data.protocolext != "":
            self[ "protocolext"] = StaticText(data.protocolext)
        else:
            self[ "protocolext"] = StaticText(_("not available"))
        self["lau"] = StaticText("au:")
        self[ "au"] = StaticText(auEntrys[data.au])
        self["lcaid"] = StaticText("caid:")
        self[ "caid"] = StaticText(data.caid)
        self["lprovid"] = StaticText("provid:")
        self[ "provid"] = StaticText(data.provid)
        self["lsrvid"] = StaticText("srvid:")
        self[ "srvid"] = StaticText(data.srvid)
        self["lecmtime"] = StaticText("ecmtime:")
        if data.ecmtime != "":
            logout(data="ClientDataScreen-ecmtime")
            self[ "ecmtime"] = StaticText(data.ecmtime)
        else:
            self[ "ecmtime"] = StaticText(_("not available"))
        self["lecmhistory"] = StaticText("ecmhistory:")
        self[ "historymax"] = StaticText(str(int(self.base)))
        self[ "historymin"] = StaticText("0")
        self["lanswered"] = StaticText("answered:")
        if data.answered != "":
            self[ "answered"] = StaticText(data.answered)
        else:
            self[ "answered"] = StaticText(_("not available"))
        self["lservice"] = StaticText("service:")
        self[ "service"] = StaticText(data.service)
        self["llogin"] = StaticText("login:")
        self[ "login"] = StaticText(data.login)
        self["lonline"] = StaticText("online:")
        self[ "online"] = StaticText(elapsedTime(data.online, "%02dd %02dh %02dm %02ds", True))
        self["lidle"] = StaticText("idle:")
        self[ "idle"] = StaticText(elapsedTime(data.idle, "%02d:%02d:%02d"))
        self["lip"] = StaticText("ip:")
        self[ "ip"] = StaticText(data.ip)
        self["lport"] = StaticText("port:")
        self[ "port"] = StaticText(data.port)
        self["lconnection"] = StaticText("connection:")
        self[ "connection"] = StaticText(data.connection)

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
        {
            "yellow": self.yellowPressed,
            "cancel": self.Close
        }, -1)
        self.onExecBegin.append(self.setProgress)

        self.onLayoutFinish.append(self.LayoutFinished)

    def LayoutFinished(self):
        pass


    def setProgress(self):
        for i in range(20):
            val = int((100.0*self.ecmhistory[i])/self.base)
            self["progress%d" % i].setValue(val)

    def yellowPressed(self):
        if self.type != "clients" and self.protocol.startswith("cccam"):
            part = "entitlement&label="+self.name
            self.session.open(ReaderDataScreen, part, self.oServer)

    def Close(self):
        self.close(0)

# "Mother" of all download windows ...
class DownloadXMLScreen(Screen):
    logout(data="Class_DownloadXMLScreen")
    def __init__(self, session, part, oServer, timerOn=True):
        self.oServer = oServer
        self["title"] = StaticText("")
        if oServer.useSSL: self.url = "https://"
        else: self.url = "http://"
        logout(data="Http_Cam")
        logout(data=str(runningcam))
        if runningcam == ('oscam'):
            self.url += oServer.serverIP+":"+oServer.serverPort+"/oscamapi.html?part="+part
        else:
            self.url += oServer.serverIP + ":" + oServer.serverPort + "/ncamapi.html?part=" + part
        URL = self.url
        logout(data="URL")
        logout(data=str(URL))
        self.oldurl = self.url
        self.download = False
        self.data = False
        self.timer = eTimer()
        self.timer.callback.append(self.downloadXML)
        self.downloadXML()
        self.timerOn = timerOn
        if self.timerOn:
            self.timer.start(TIMERTICK)
        self.newurl = False

    def downloadXML(self):
        logout(data="downloadxml")
        self.setTitle(_("loading..."))
        self.download = True
        print("[OscamStatus] loading", self.url)
        self.getIndex()
        # Message Queue initialisation...
        getPage2.MessagePump.recv_msg.get().append(self.gotThreadMsg)
        # Download Thread started...
        try:
            getPage2.Start(self.url, self.oServer.username, self.oServer.password)
        except RuntimeError:
            self.download = False
            getPage2.MessagePump.recv_msg.get().remove(self.gotThreadMsg)
            print("[OscamStatus] Thread already running...")

    def sendNewPart(self, part):
        logout(data="sendnewpart")
        self.timer.stop()
        if self.oServer.useSSL: url = "https://"
        else: url = "http://"

        url += self.oServer.serverIP+":"+self.oServer.serverPort
        logout(data="**************************************************************")
        logout(data=str(url))
        if runningcam == ('oscam'):
            url += "/oscamapi.html?part="+part
        else:
            url += "/ncamapi.html?part=" + part


        self.newurl = True
        self.url = url
        logout(data=str(url))
        self.downloadXML()

    def gotThreadMsg(self, msg):
        logout(data="gotthreadMSG")
        #       try:
        msg = getPage2.Message.pop()
        #ausgabe von oscam info
        test = msg
        #logout(data=str(test))



#       except IndexError:
#           getPage2.MessagePump.recv_msg.get().remove(self.gotThreadMsg)
#           return

        if msg[0] == THREAD_ERROR:
            logout(data="msgthreaderror")
            getPage2.MessagePump.recv_msg.get().remove(self.gotThreadMsg)
            self.download = False
            errStr = str(msg[1])
            if self.timerOn:
                self.timer.stop()
            print("[OscamStatus]", errStr)
            info = self.session.open(MessageBox, errStr, MessageBox.TYPE_ERROR)
            info.setTitle(_("Oscam Status"))
            self.close(1)

        elif msg[0] == THREAD_FINISHED:
            logout(data="msgthreadfinished")
            test = msg
            #logout(data=str(test))
            getPage2.MessagePump.recv_msg.get().remove(self.gotThreadMsg)
            test1 = msg
            #logout(data=str(test1))
            self.download = False
            print("[OscamStatus] Download finished")



            self.data = msg[1]
            test = self.data
            self.download = False
            # if no xml comes back something is not right ..
            if not b"<?xml version=\"1.0\"" in self.data:
                logout(data="if_not")
                print("[OscamStatus] Oscam Download Error: no xml")
                info = self.session.open(MessageBox, _("no xml"), MessageBox.TYPE_ERROR)
                info.setTitle(_("Oscam Download Error"))
                self.close(1)
                return
            try:
                logout(data="if_not_try")
                dom = xml.dom.minidom.parseString(self.data)

            except:
                logout(data="if_not_except")
                info = self.session.open(MessageBox, _("Maybe set 'chaninfo = 0' at oscam.conf"), MessageBox.TYPE_ERROR)
                info.setTitle(_("Oscam XML Error"))
                self.close(1)

                return

            node = dom.getElementsByTagName("error")
            if node:
                logout(data="if node")
                if self.timerOn:
                    self.timer.stop()

                errmsg = str(node[0].firstChild.nodeValue.strip())

                print("[OscamStatus] Oscam XML Error:", errmsg)
                info = self.session.open(MessageBox, _(errmsg), MessageBox.TYPE_ERROR)
                info.setTitle(_("Oscam XML Error"))
                self.close(1)

            else:

                self.dlAction()

    def getIndex(self):
        logout(data="getindex")
        try:
            self.oldIndex = self["data"].getIndex()
        except:
            self.oldIndex = 0

    def Close(self):
        if self.timerOn:
            self.timer.stop()
        if self.download:
            getPage2.MessagePump.recv_msg.get().remove(self.gotThreadMsg)

        self.close(0)

    def setTitle(self, txt):
        self["title"].setText(txt)


# *********************************************************************************************************************************************************************
class UpdateOscamScreen(DownloadXMLScreen):
    logout(data="*******************  UpdateOscamScreen   ****************************************")
    if FULLHD:
        skin = """
            <screen name="UpdateOscamScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="Update Binary">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="20" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <eLabel text="source:" position=" 20,100" size="190,50" zPosition="2" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" font="Regular;26"/>
                <eLabel text="update binary:" position=" 20,200" size="190,50" zPosition="2" transparent="1" foregroundColor="#00ff4a3c" backgroundColor="#00000000" font="Regular;26"/>
                <eLabel text="Icam:" position=" 20,300" size="190,50" zPosition="2" transparent="1" foregroundColor="#00fff000" font="Regular;26"/>
                <eLabel text="Oscam Run Version:" position=" 20,250" size="230,50" zPosition="2" transparent="1" foregroundColor="#00fff000" backgroundColor="#00000000" font="Regular;26"/>
                
                
                <eLabel text="Oscam Run:" position=" 20,360" size="190,50" zPosition="2" transparent="1" foregroundColor="#00fff000" backgroundColor="#00000000" font="Regular;26"/>
                <eLabel text="restore update:" position=" 20,440" size="190,50" zPosition="2" transparent="1" foregroundColor="#000000ff" backgroundColor="#00000000" font="Regular;26"/>


                <widget name="ButtonRed" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/red.png" position="50,670" size="250,40" zPosition="2" transparent="1" alphatest="on"/>
                <widget name="ButtonRedtext" position="50,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>               

                <widget name="ButtonGreen" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/green.png" position="350,670" size="250,40" zPosition="2" transparent="1" alphatest="on"/>
                <widget name="ButtonGreentext" position="350,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                
                <widget name="ButtonYellow" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/yellow.png" position="650,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonYellowtext" position="650,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonBlue" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/blue.png" position="950,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonBluetext" position="950,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>

                <widget name="boxinfo" position="445,580" size="360,50" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <eLabel text="BoxInfo:" position=" 250,580" size="190,50" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>

                <eLabel text="Image name:" position=" 550,580" size="190,50" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="imagename" position="745,580" size="360,50" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <ePixmap position="20,550" size="200,200" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/iconsbox/GigaBlue_UE_4K.png" transparent="1" alphatest="blend" />

                <widget name="status" font="Regular; 30"  position="250,500" size="780,50" foregroundColor ="#00fff000" backgroundColor="#00000000"  transparent="1"  zPosition="3" halign="center" valign="center" />

                <widget name="sourcefile" position="250,100" size="900,50" zPosition="2" transparent="1" backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular;26"/>    
                <eLabel  position=" 0,155" size="1280,3" zPosition="2" transparent="0" backgroundColor="#00ffffff" />

                
                <widget name="oscamfile1" position="250,200" size="900,50" zPosition="2" transparent="1" backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular;26"/>    
                <widget name="oscamversion" position="250,250" size="900,50" zPosition="2" transparent="1" backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular;26"/>    
                <widget name="icamversion" position="250,300" size="900,50" zPosition="2" transparent="1" backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular;26"/>    

                
                <widget name="oscamrunname" position="250,360" size="900,50" zPosition="2" transparent="1" backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular;26"/>    
                
                <eLabel  position=" 0,430" size="1280,3" zPosition="2" transparent="0" backgroundColor="#00ffffff" />
                <widget name="oscamfile4" position="250,440" size="900,50" zPosition="2" transparent="1" backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular;26"/>    


         
            </screen>"""
    else:
        skin = """
           <screen name="UpdateOscamScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="Update Binary">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="20" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="#00000000" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <eLabel text="source:" position=" 20,100" size="190,50" zPosition="2" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00000000" font="Regular;26"/>
                <eLabel  position=" 0,155" size="1280,3" zPosition="2" transparent="0" backgroundColor="#00ffffff" />
                <eLabel text="update binary:" position=" 20,200" size="190,50" zPosition="2" transparent="1" foregroundColor="#00ff4a3c" backgroundColor="#00000000" font="Regular;26"/>
                <eLabel text="Icam:" position=" 20,300" size="190,50" zPosition="2" transparent="1" foregroundColor="#00fff000" font="Regular;26"/>
                <eLabel text="Oscam Run Version:" position=" 20,250" size="230,50" zPosition="2" transparent="1" foregroundColor="#00fff000" backgroundColor="#00000000" font="Regular;26"/>
                <eLabel text="Oscam Run:" position=" 20,360" size="190,50" zPosition="2" transparent="1" foregroundColor="#00fff000" backgroundColor="#00000000" font="Regular;26"/>
                <eLabel text="restore update:" position=" 20,440" size="190,50" zPosition="2" transparent="1" foregroundColor="#000000ff" backgroundColor="#00000000" font="Regular;26"/>


                <widget name="ButtonRed" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/red.png" position="50,670" size="250,40" zPosition="2" transparent="1" alphatest="on"/>
                <widget name="ButtonRedtext" position="50,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>               
                <widget name="ButtonGreen" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/green.png" position="350,670" size="250,40" zPosition="2" transparent="1" alphatest="on"/>
                <widget name="ButtonGreentext" position="350,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonYellow" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/yellow.png" position="650,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonYellowtext" position="650,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonBlue" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/blue.png" position="950,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonBluetext" position="950,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>

                <widget name="boxinfo" position="445,580" size="360,50" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <eLabel text="BoxInfo:" position=" 250,580" size="190,50" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <eLabel text="Image name:" position=" 550,580" size="190,50" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="imagename" position="745,580" size="360,50" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <ePixmap position="20,550" size="200,200" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/iconsbox/GigaBlue_UE_4K.png" transparent="1" alphatest="blend" />

                <widget name="status" font="Regular; 30"  position="250,500" size="780,50" foregroundColor ="#00fff000" backgroundColor="#00000000"  transparent="1"  zPosition="3" halign="center" valign="center" />

                <widget name="sourcefile" position="250,100" size="900,50" zPosition="2" transparent="1" backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular;26"/>    
                <widget name="oscamfile1" position="250,200" size="900,50" zPosition="2" transparent="1" backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="oscamversion" position="250,250" size="900,50" zPosition="2" transparent="1" backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular;26"/>    
                <widget name="icamversion" position="250,300" size="900,50" zPosition="2" transparent="1" backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular;26"/>    
                <widget name="oscamrunname" position="250,360" size="900,50" zPosition="2" transparent="1" backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular;26"/>    
                
                <eLabel  position=" 0,430" size="1280,3" zPosition="2" transparent="0" backgroundColor="#00ffffff" />
                <widget name="oscamfile4" position="250,440" size="900,50" zPosition="2" transparent="1" backgroundColor="#00000000" foregroundColor="#00ffffff" font="Regular;26"/>    


            </screen>"""

    def __init__(self, session, part, oServer):
        logout(data="init.part.server")
        Screen.__init__(self, session)
        #self.setTitle("Update Binary")
        DownloadXMLScreen.__init__(self, session, part, oServer, False)

        #self.oServer = oServer
        self.skin = UpdateOscamScreen.skin
        #self.session = session

        logout(data="INIT-11")


        #  ************************************************* hier die neuen labels
        imagename = "no Info"
        boxinfo = "no Info"
        status = ""
        sourcefile = "no File --- oscam-update  ----  "
        oscamfile1 = ""
        oscamfile2 = ""
        oscamfile3 = ""
        oscamfile4 = ""
        oscamrunname = "no file"
        self.imagename = imagename
        self.status = status
        self.boxinfo = boxinfo

        self.oscamrunname = oscamrunname
        self.sourcefile = sourcefile
        self.oscamfile1 = oscamfile1
        self.oscamfile2 = oscamfile2
        self.oscamfile3 = oscamfile3
        self.oscamfile4 = oscamfile4

        self["oscamrunname"] = Label()
        self["imagename"] = Label()
        self["status"] = Label()
        self["boxinfo"] = Label()
        self["sourcefile"] = Label()
        self["oscamfile1"] = Label()
        self["oscamfile2"] = Label()
        self["oscamfile3"] = Label()
        self["oscamfile4"] = Label()
        self["oscamversion"] = Label()
        self["icamversion"] = Label()

        # **************************************************************************
        # ***************  oscam in tmp zum updaten , check ob da *******************************

        # ***************************  hier file in tmp da , dann ins array rein


        self["ButtonRed"] = Pixmap()
        self["ButtonRedtext"] = Button(_("update binary "))

        #self["ButtonGreen"] = Pixmap()
        #self["ButtonGreentext"] = Button(_("update Line 2"))
        #self["ButtonYellow"] = Pixmap()
        #self["ButtonYellowtext"] = Button(_("update Line 3"))
        self["ButtonBlue"] = Pixmap()
        self["ButtonBluetext"] = Button(_("restore"))

        self["imagename"].setText("%s " % (self.imagename))

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
                                    {
                                        "red": self.update,
                                        #"green": self.updateline2,
                                        #"yellow": self.updateline3,
                                        "blue": self.restore,
                                        "cancel": self.cancel
                                    }, -1)

        # **************************oscam version info auslesen *****************************
        oscamversionpfad = "/tmp/oscam.version"
        oscamversion = "not found"
        icamversion = "not found"
        self.icamversion = icamversion
        self.oscamversion = oscamversion

        for line in open(oscamversionpfad):

            if "Version:" in line:
                logout("version line suchen ")
                logout(data=str(line))
                my_string = line

                text1, text2 = my_string.split(": ")
                # leerzeichen entfernen
                oscamversion = text2.strip()
                self.oscamversion = oscamversion
                self["oscamversion"].setText("%s " % (self.oscamversion))

            if "DVB API with ICAM streamrelay support:" in line:
                logout("icam yes line suchen ")
                logout(data=str(line))
                #my_string = line

                #text1, text2 = my_string.split(": ")
                # leerzeichen entfernen
                icamversion = "yes"
                self.icamversion = icamversion
                self["icamversion"].setText("%s " % (self.icamversion))




        # ***************  oscam in tmp zum updaten , check ob da *******************************

        # ***************************  hier file in tmp da , dann ins array rein

        from os import listdir
        #array anlegen in was geschrieben wird
        filenameout = []
        logout(data="*********************  oscam-update file suchen  ***************************")
        directory = "/tmp/"
        self.sourcefile = "no File :             file muss im tmp sein als name :    oscam-update   "
        self["sourcefile"].setText("%s " % (self.sourcefile))
        for filename in os.listdir(directory):
            f = os.path.join(directory, filename)
            logout(data="oscam-update file")
            logout(data=str(f))
            line = f
            logout(data=str(line))
            if os.path.isfile(f) and filename.endswith('oscam-update'):
                logout(data="---------------  oscam-update file ist da  --------------------------")
                filenameout.append(filename)
                self.sourcefile = filenameout[0]
                self["sourcefile"].setText("%s " % (self.sourcefile))
            elif "pid" in line:
                logout(data="------------------------  oscam-run file -----------------------------")
                logout(data=str(line))
                # jetzt hinten die 4 weg .pid
                line1 = line[:-4]
                logout(data=str(line1))
                #jetzt vorne 5 weg /tmp/
                self.oscamrunname = line1[5:]
                logout(data=str(self.oscamrunname))
                self["oscamrunname"].setText("%s " % (self.oscamrunname))


        # ***************************  hier file in usr/bin , dann ins array rein
        oscamnameout = []
        logout(data="------------------------  oscam binary file -----------------------------")
        directory = "/usr/bin/"
        self.oscamfile1 = "no file"
        self["oscamfile1"].setText("%s " % (self.oscamfile1))
        self.oscamfile2 = "no file"
        self["oscamfile2"].setText("%s " % (self.oscamfile2))
        self.oscamfile3 = "no file"
        self["oscamfile3"].setText("%s " % (self.oscamfile3))
        self.oscamfile4 = "no file"
        self["oscamfile4"].setText("%s " % (self.oscamfile4))

        oscampfad = "/usr/bin/"
        self.oscampfad = oscampfad

        # line wird in oscamname rein geschrieben zum vergleichen
        for oscamname in os.listdir(directory):
            #logout(data="*********************  oscam-binary file suchen  ***************************")
            f = os.path.join(directory, oscamname)
            logout(data=" oscam-binarys file suchen name ")
            #logout(data=str(self.oscamrunname))
            #logout(data=str(f))
            lines = f
            logout(data=str(lines))
            # if os.path.isfile(f) and oscamname.endswith('oscam*.*'):
            #binary =("%s%s " % (directory, self.oscamrunname))
            #logout(data=str(binary))
            logout(data="----------- name suchen old ------------")
            sichernsuchen = "%s%s.old" % (self.oscampfad, self.oscamrunname)
            logout(data=str(sichernsuchen))
            # hier suchen welche cam gerade aktiv ist
            if self.oscamrunname in lines:
                logout(data="----------- oscam-binarys running file ist da ------------")
                oscamnameout.append(self.oscamrunname)
                self.oscamfile1 = oscamnameout[0]
                logout(data=str(self.oscamfile1))
                self["oscamfile1"].setText("%s " % (self.oscamfile1))
            # hie suchen ob es eine old gibt
            if sichernsuchen in lines:
                logout(data="--------------- oscam-binarys.old file ist da ---------------")
                gefunden = sichernsuchen
                self.oscamfile4 = gefunden[9:]

                logout(data=str(self.oscamfile4))
                self["oscamfile4"].setText("%s " % (self.oscamfile4))





        # ***************  welche image version ist das *******************************
        if os.path.isfile('/etc/image-version'):
            logout(data="welches images ist es")
            for line in open('/etc/image-version'):
                if 'creator' in line:
                    imagename = line.split('=')[1]
                    # hier sieht man jede line was drin ist , braucht viel log
                    #logout(data=str(imagename))
                    self.imagename = imagename
                    self["imagename"].setText("%s " % (self.imagename))
# *********************************  pfade in den images ******************************************
        openatv ="/usr/bin/"        # openpli , VTI , openvix

        oscampfad = "/usr/bin/"
        self.oscampfad = oscampfad
        imagebinary = self.imagename
        imagebinary = imagebinary.lower()
        logout(data="Image ist")
        logout(data=str(imagebinary))

        if imagebinary == "openatv":
            self.oscampfad = openatv

        if imagebinary == "openpli":
            self.oscampfad = openatv

        if imagebinary == "vti":
            self.oscampfad = openatv
# *************************************************************************************************





        self.onLayoutFinish.append(self.LayoutFinished)
        logout(data="onLayoutFinish")


    def dlAction(self):
        # dom = xml.dom.minidom.parseString(self.data)
        # r = self.parseXML(dom)
        # self.r = r
        return

    def LayoutFinished(self):
        logout(data="Layout Finished")
        pass

    # ************************ update der oscam binary **************************************
    def update(self):
        logout(data="************* updateline 1 red ******************************")
        FILE_update = "/tmp/oscam-update"
# **************************************  hier noch oscam stoppen einbauen ************************************
        if not self.oscamfile1 == "no file":

            if isfile(FILE_update):
                logout(data="************* updateline 1 red oscam stoppen ******************************")
                #self.sendNewPart("shutdown&action=shutdown")
                os.system("/etc/init.d/softcam stop")
                import time
                # der wert 1 ist in sec
                begin_time = 0
                while begin_time < 10:
                    begin_time += 1
                    time.sleep(1.0)
                logout(data="************* updateline 1 red oscam ist gestoppt ******************************")

                logout(data="update-copy-file")
                logout(data=str(self.oscampfad))
                logout(data=str(self.oscamfile1))
                # wo es hincopiert werden soll
                oscamcopypfad = "%s%s" % (self.oscampfad, self.oscamfile1)
                logout(data=str(oscamcopypfad))

                logout(data="************* file sichern in .old ******************************")
                # hier an den filename .old
                FILE_sichern = "%s%s.old" % (self.oscampfad, self.oscamfile1)
                self.FILE_sichern = FILE_sichern
                logout(data="file sichern")
                logout(data=str(FILE_sichern))

                # z.B /usr/bin/oscamicam nach /usr/bin/oscamicam.old
                source = oscamcopypfad
                destination = FILE_sichern
                copyfile(source, destination)
                logout(data="************* file gesichert in .old ******************************")

                FILE_update = "/tmp/oscam-update"
                source = FILE_update
                logout(data="source")
                logout(data=str(source))
                logout(data="+++++++++++++  copy file von nach +++++++++++++++++++++++++++")
                destination = oscamcopypfad
                logout(data="destination")
                logout(data=str(destination))
                # datei rechte setzen
                logout(data="+++++++++++++  copy file +++++++++++++++++++++++++++")

                copyfile(source, destination)
                logout(data="+++++++++++++  copy file dateirechte +++++++++++++++++++++++++++")
                os.chmod(destination, 0o755)

                logout(data="+++++++++++++  restart oscam +++++++++++++++++++++++++++")

                import subprocess
                #program = "/usr/bin/oscamicam -b -r2 -c /etc/tuxbox/config/oscamicam/"
                #os.system("/usr/bin/self.oscamfile1 -b -r2 -c /etc/tuxbox/config/self.oscamfile1")
                #os.system("/usr/bin/oscamicam --config-dir /etc/tuxbox/config/oscamicam --daemon --pidfile /tmp/oscamicam.pid --restart 2 --utf8")
                os.system("/etc/init.d/softcam start")
                #process = subprocess.Popen(program)
                #subprocess.call(program)
                #subprocess.call("/usr/bin/oscamicam -b -r2 -c /etc/tuxbox/config/oscamicam/")
                #{/usr/bin/oscamcopypfad -b -r2 -c /etc/tuxbox/config/self.oscamfile1 & }
                #subprocess.run([sys.executable, "-c", "/usr/bin/oscamicam -b -r2 -c /etc/tuxbox/config/oscamicam/"])
                self['status'].setText(_("update fertig ,   Oscam muss neu gestartet werden"))
            else:
                self['status'].setText(_("kein File zum Updaten vorhanden"))

        else:
            self['status'].setText(_("kein Ziel zum Updaten vorhanden"))



    def restore(self):
        logout(data="************* restore 4 blau ******************************")
        logout(data=str(self.oscamfile4))
        self.FILE_sichern = "%s%s" % (self.oscampfad, self.oscamfile4)
        logout(data=str(self.FILE_sichern))




        if isfile(self.FILE_sichern):
            logout(data="restore-copy-file")

            logout(data="************* updateline 4 blue oscam stoppen ******************************")
            self.sendNewPart("shutdown&action=shutdown")
            import time
            # der wert 1 ist in sec
            begin_time = 0
            while begin_time < 10:
                begin_time += 1
                time.sleep(1.0)

            logout(data="************* updateline 4 blue oscam ist gestoppt ******************************")


            # source ist .old
            source = self.FILE_sichern
            logout(data="source")
            logout(data=str(source))


            string = self.FILE_sichern
            string = string[:-4]  # die letzten 4 weg .old
            destination = string
            logout(data="destination")
            logout(data=str(destination))
            logout(data="+++++++++++++  copy file +++++++++++++++++++++++++++")

            copyfile(source, destination)
            logout(data="+++++++++++++  copy file dateirechte +++++++++++++++++++++++++++")

            os.chmod(destination, 0o755)
            self['status'].setText(_("restore fertig ,     Oscam muss neu gestartet werden"))
        else:
            self['status'].setText(_("kein File zum Restore vorhanden"))

    # ***************************************************************************************


    def cancel(self):
        logout(data="cancel exit")
        self.close()


# OscamDataScreen... -----------------  LOGFILE -------------------------------------
class OscamDataScreen(DownloadXMLScreen):
    logout(data="OscamDataScreen")
    if FULLHD:
        skin = """
            <screen name="OscamDataScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="9" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />

                <widget render="Label" source="lversion" position=" 20,130" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "version" position="215,130" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lrevision" position=" 20,180" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "revision" position="215,180" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lstarttime" position=" 20,230" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "starttime" position="215,230" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="luptime" position=" 20,280" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "uptime" position="215,280" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lreadonly" position=" 20,330" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "readonly" position="215,330" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
            </screen>"""
    else:
        skin = """
             <screen name="OscamDataScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="9" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />

                <widget render="Label" source="lversion" position=" 20,130" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "version" position="215,130" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lrevision" position=" 20,180" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "revision" position="215,180" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lstarttime" position=" 20,230" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "starttime" position="215,230" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="luptime" position=" 20,280" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "uptime" position="215,280" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lreadonly" position=" 20,330" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "readonly" position="215,330" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
            </screen>"""

    def __init__(self, session, part, oServer):
        self.oServer = oServer
        self.skin = OscamDataScreen.skin
        self.session = session
        Screen.__init__(self, session)

        DownloadXMLScreen.__init__(self, session, part, oServer, False)

        self["lversion"] = StaticText("version:")
        self["version"] = StaticText("")
        self["lrevision"] = StaticText("revision:")
        self["revision"] = StaticText("")
        self["lstarttime"] = StaticText("starttime:")
        self["starttime"] = StaticText("")
        self["luptime"] = StaticText("uptime:")
        self["uptime"] = StaticText("")
        self["lreadonly"] = StaticText("readonly:")
        self["readonly"] = StaticText("")
        self["actions"] = ActionMap(["OkCancelActions"],

                                    {
                                        "cancel": self.Close
                                    }, -1)

        self.onLayoutFinish.append(self.LayoutFinished)

    def LayoutFinished(self):
        pass

    # x,h = dlg_xh(self.instance.size().width())
    # if getDesktop(0).size().width() >= 1920:
    # self.instance.move(ePoint(320, 180))
    # else:
    # self.instance.move(ePoint(x, 0))

    def parseXML(self, dom):
        logout(data="parseXML")
        o = oscamdata()
        logout(data="parseXML-1")
        if runningcam == ('oscam'):
            cam = "oscam"
        else:
            cam = "ncam"

        for node in dom.getElementsByTagName(cam):
            logout(data="parseXML-2")

            logout(data="dom.getElementsByTagName")
            o.version = str(node.getAttribute("version"))
            logout(data=str(o.version))
            o.revision = str(node.getAttribute("revision"))
            o.starttime = str(node.getAttribute("starttime"))
            o.uptime = str(node.getAttribute("uptime"))
            o.readonly = str(node.getAttribute("readonly"))
        return o

    def dlAction(self):
        dom = xml.dom.minidom.parseString(self.data)
        d = self.parseXML(dom)
        logout(data="dlAction")
        logout(data=str(d))
        self.setTitle("Oscam Server" + "@" + self.oServer.serverName)
        self["version"].setText(d.version)
        self["revision"].setText(d.revision)
        self["starttime"].setText(d.starttime)
        self["uptime"].setText(elapsedTime(d.uptime, _("%d days %d hours %d minutes %d seconds"), True))
        self["readonly"].setText(d.readonly)


# OscamRestartScreen...
class OscamRestartScreen(DownloadXMLScreen):
    logout(data="OscamReaderScreen")
    if FULLHD:
        skin = """
            <screen name="OscamRestartScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="8" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="lversion" position=" 20,130" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "version" position="215,130" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lrevision" position=" 20,180" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "revision" position="215,180" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lstarttime" position=" 20,230" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "starttime" position="215,230" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="luptime" position=" 20,280" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "uptime" position="215,280" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lreadonly" position=" 20,330" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "readonly" position="215,330" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonYellow" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/yellow.png" position="650,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonYellowtext" position="650,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonBlue" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/blue.png" position="950,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonBluetext" position="950,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
            </screen>"""
    else:
        skin = """
           <screen name="OscamRestartScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="8" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
           <widget render="Label" source="lversion" position=" 20,130" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "version" position="215,130" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lrevision" position=" 20,180" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "revision" position="215,180" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lstarttime" position=" 20,230" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "starttime" position="215,230" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="luptime" position=" 20,280" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "uptime" position="215,280" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="lreadonly" position=" 20,330" size="190,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source= "readonly" position="215,330" size="360,30" zPosition="2" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonYellow" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/yellow.png" position="650,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonYellowtext" position="650,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonBlue" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/blue.png" position="950,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonBluetext" position="950,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
            </screen>"""

    def __init__(self, session, part, oServer):
        logout(data="init.part.server")
        self.oServer = oServer
        self.skin = OscamRestartScreen.skin
        self.session = session
        Screen.__init__(self, session)
        logout(data="INIT_1")



        DownloadXMLScreen.__init__(self, session, part, oServer, False)
        logout(data="INIT_back")


        self["lversion"] = StaticText("version:")
        self[ "version"] = StaticText("")
        self["lrevision"] = StaticText("revision:")
        self[ "revision"] = StaticText("")
        self["lstarttime"] = StaticText("starttime:")
        self[ "starttime"] = StaticText("")
        self["luptime"] = StaticText("uptime:")
        self[ "uptime"] = StaticText("")
        self["lreadonly"] = StaticText("readonly:")
        self[ "readonly"] = StaticText("")


        self["ButtonYellow"] = Pixmap()
        self["ButtonYellowtext"] = Button(_("restart oscam"))
        self["ButtonBlue"] = Pixmap()
        self["ButtonBluetext"] = Button(_("shutdown oscam"))



        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
        {

            "yellow": self.yellowPressed,
            "blue": self.bluePressed,
            "cancel": self.Close
        }, -1)
        self.canRestart = False

        self.onLayoutFinish.append(self.LayoutFinished)

    def LayoutFinished(self):
        pass


    def parseXML(self, dom):
        logout(data="parsexml")
        o = oscamdata()
        if runningcam == ('oscam'):
            cam = "oscam"

        else:
            cam = "ncam"


        for node in dom.getElementsByTagName(cam):
            o.version = str(node.getAttribute("version"))
            o.revision = str(node.getAttribute("revision"))
            o.starttime = str(node.getAttribute("starttime"))
            o.uptime = str(node.getAttribute("uptime"))
            o.readonly = str(node.getAttribute("readonly"))
        self.canRestart = True
        return o

    def dlAction(self):
        logout(data="dlAction")
        if self.newurl:
            self.close(0)
        dom = xml.dom.minidom.parseString(self.data)
        d = self.parseXML(dom)

        self.setTitle("Oscam Server"+"@"+self.oServer.serverName)
        self[ "version"].setText(d.version)
        self[ "revision"].setText(d.revision)
        self[ "starttime"].setText(d.starttime)
        self[ "uptime"].setText(elapsedTime(d.uptime, _("%d days %d hours %d minutes %d seconds"), True))
        self[ "readonly"].setText(d.readonly)

        if not self.canRestart:
            msg = _("you can\'t shutdown/restart this oscam.\n")
            info = self.session.open(MessageBox, msg, MessageBox.TYPE_ERROR)
            info.setTitle(_("Oscam Status"))
            self.close(1)







    def yellowPressed(self):
        logout(data="yellowpressed")
        if self.download:
            logout(data="yellowpressed-download")
            return
        self.mode = "restart"
        self.mbox(_("really restart oscam@%s?")%self.oServer.serverName)

    def bluePressed(self):
        logout(data="bluepressed")
        if self.download:
            logout(data="bluepressed-download")
            return
        self.mode = "shutdown"
        self.mbox(_("really really shutdown oscam@%s?")%self.oServer.serverName)


    def mbox(self, txt):
        logout(data="mbox")
        msg = self.session.openWithCallback(self.mboxCB, MessageBox, txt, default = False)
        msg.setTitle(_("Oscam Status"))

    def mboxCB(self, retval):
        logout(data="mboxCB")
        if retval:
            logout(data="mboxCB-retval")
            if self.mode == "restart":
                logout(data="mboxCB-retval-restart")
                self.sendNewPart("shutdown&action=restart")
            elif self.mode == "shutdown":
                logout(data="mboxCB-retval-shtdown")
                self.sendNewPart("shutdown&action=shutdown")

# ReaderDataScreen...
class ReaderDataScreen(DownloadXMLScreen):
    logout(data="ReaderDataScreen")
    if FULLHD:
        # HD skin

        skin = """
           <screen name="ReaderDataScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="7" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="title" position="10,80" size="700,26" valign="center" zPosition="5" transparent="0" foregroundColor="#fcc000" font="Regular;22"/>
                <widget source="data" render="Listbox" position="10,130" size="700,360" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" transparent="1" scrollbarMode="showOnDemand">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryText(pos = (  2, 2), size = ( 40, 28), font=2, flags = RT_HALIGN_LEFT, text = 0),
                            MultiContentEntryText(pos = ( 40, 5), size = ( 25, 24), font=0, flags = RT_HALIGN_LEFT, text = 1),
                            MultiContentEntryText(pos = (110, 5), size = (200, 24), font=0, flags = RT_HALIGN_LEFT, text = 2),
                            MultiContentEntryText(pos = (320, 2), size = (140, 24), font=0, flags = RT_HALIGN_LEFT, text = 3),
                            MultiContentEntryText(pos = (470, 2), size = (140, 24), font=0, flags = RT_HALIGN_LEFT, text = 4),

                            MultiContentEntryText(pos = ( 40,35), size = ( 20, 30), font=1, flags = RT_HALIGN_LEFT, text = 5),
                            MultiContentEntryText(pos = ( 70,35), size = (300, 30), font=1, flags = RT_HALIGN_LEFT, text = 6),
                            MultiContentEntryText(pos = ( 40,64), size = ( 20, 30), font=1, flags = RT_HALIGN_LEFT, text = 7),
                            MultiContentEntryText(pos = ( 70,64), size = (300, 30), font=1, flags = RT_HALIGN_LEFT, text = 8),
                            MultiContentEntryText(pos = (320,35), size = ( 20, 30), font=1, flags = RT_HALIGN_LEFT, text = 9),
                            MultiContentEntryText(pos = (350,35), size = (300, 30), font=1, flags = RT_HALIGN_LEFT, text = 10),
                            MultiContentEntryText(pos = (320,64), size = ( 20, 30), font=1, flags = RT_HALIGN_LEFT, text = 11),
                            MultiContentEntryText(pos = (350,64), size = (300, 30), font=1, flags = RT_HALIGN_LEFT, text = 12),
                        ],
                        "fonts": [gFont("Regular", 28), gFont("Regular", 25), gFont("Regular", 24)],
                        "itemHeight": 90
                        }
                    </convert>
                </widget>
                <widget name="KeyYellow" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/bt_yellow.png"" position="675,495" size="35,25" zPosition="4" transparent="1" alphatest="on"/>
            </screen>"""


    else:
        # Low res skin

        skin = """
           <screen name="ReaderDataScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="7" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="title" position="10,80" size="700,26" valign="center" zPosition="5" transparent="0" foregroundColor="#fcc000" font="Regular;22"/>
                <widget source="data" render="Listbox" position="10,130" size="700,360" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" transparent="1" scrollbarMode="showOnDemand">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryText(pos = (  2, 2), size = ( 40, 28), font=2, flags = RT_HALIGN_LEFT, text = 0),
                            MultiContentEntryText(pos = ( 40, 5), size = ( 25, 24), font=0, flags = RT_HALIGN_LEFT, text = 1),
                            MultiContentEntryText(pos = (110, 5), size = (200, 24), font=0, flags = RT_HALIGN_LEFT, text = 2),
                            MultiContentEntryText(pos = (320, 2), size = (140, 24), font=0, flags = RT_HALIGN_LEFT, text = 3),
                            MultiContentEntryText(pos = (470, 2), size = (140, 24), font=0, flags = RT_HALIGN_LEFT, text = 4),

                            MultiContentEntryText(pos = ( 40,35), size = ( 20, 30), font=1, flags = RT_HALIGN_LEFT, text = 5),
                            MultiContentEntryText(pos = ( 70,35), size = (300, 30), font=1, flags = RT_HALIGN_LEFT, text = 6),
                            MultiContentEntryText(pos = ( 40,64), size = ( 20, 30), font=1, flags = RT_HALIGN_LEFT, text = 7),
                            MultiContentEntryText(pos = ( 70,64), size = (300, 30), font=1, flags = RT_HALIGN_LEFT, text = 8),
                            MultiContentEntryText(pos = (320,35), size = ( 20, 30), font=1, flags = RT_HALIGN_LEFT, text = 9),
                            MultiContentEntryText(pos = (350,35), size = (300, 30), font=1, flags = RT_HALIGN_LEFT, text = 10),
                            MultiContentEntryText(pos = (320,64), size = ( 20, 30), font=1, flags = RT_HALIGN_LEFT, text = 11),
                            MultiContentEntryText(pos = (350,64), size = (300, 30), font=1, flags = RT_HALIGN_LEFT, text = 12),
                        ],
                        "fonts": [gFont("Regular", 28), gFont("Regular", 25), gFont("Regular", 24)],
                        "itemHeight": 90
                        }
                    </convert>
                </widget>
                <widget name="KeyYellow" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/bt_yellow.png"" position="675,495" size="35,25" zPosition="4" transparent="1" alphatest="on"/>
            </screen>"""


    def __init__(self, session, part, oServer):
        self.skin = ReaderDataScreen.skin
        self.session = session
        Screen.__init__(self, session)

        DownloadXMLScreen.__init__(self, session, part, oServer, False)

        self["data"] = List([])
        self["KeyYellow"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
        {
            "yellow": self.yellowPressed,
            "cancel": self.Close
        }, -1)

        self.onLayoutFinish.append(self.LayoutFinished)

    def LayoutFinished(self):
        pass


    def parseXML(self, dom):
        d = []
        # readout dom...
        for elem in dom.getElementsByTagName("reader"):
            r = reader()
            r.label = str(elem.getAttribute("label"))
            r.hostaddress = str(elem.getAttribute("hostaddress"))
            r.hostport = str(elem.getAttribute("hostport"))
            for node in elem.getElementsByTagName("cardlist"):
                r.totalcards = str(node.getAttribute("totalcards"))
                for snode in node.childNodes:
                    if snode.nodeName == "card":
                        c = card()
                        c.number = str(snode.getAttribute("number"))
                        c.caid = str(snode.getAttribute("caid"))
                        c.system = str(snode.getAttribute("system"))
                        c.reshare = str(snode.getAttribute("reshare"))
                        c.hop = str(snode.getAttribute("hop"))
                        for snode2 in snode.childNodes:
                            if snode2.nodeName == "shareid":
                                if snode2.firstChild and snode2.firstChild.nodeType == snode2.firstChild.TEXT_NODE:
                                    c.shareid = str(snode2.firstChild.nodeValue.strip())
                            if snode2.nodeName == "remoteid":
                                if snode2.firstChild and snode2.firstChild.nodeType == snode2.firstChild.TEXT_NODE:
                                    c.remoteid = str(snode2.firstChild.nodeValue.strip())
                            if snode2.nodeName == "providers":
                                c.totalproviders = str(snode2.getAttribute("totalproviders"))
                                for snode3 in snode2.childNodes:
                                    if snode3.nodeName == "provider":
                                        p = provider()
                                        p.number = str(snode3.getAttribute("number"))
                                        p.sa = str(snode3.getAttribute("sa"))
                                        p.caid = str(snode3.getAttribute("caid"))
                                        p.provid = str(snode3.getAttribute("provid"))
                                        if snode3.firstChild and snode3.firstChild.nodeType == snode3.firstChild.TEXT_NODE:
                                            # HACK! on different platforms 'ü' is encoded differently?
                                            p.service = str(snode3.firstChild.nodeValue.strip()).replace("&#195;&#188;", "ü").replace("&#451;&#444;", "ü").replace("&amp;", "&")
                                            #p.service = unescape(str(snode3.firstChild.nodeValue.strip())).replace("&#451;&#444;", "ü")
                                        c.providers.append(p)
                            if snode2.nodeName == "nodes":
                                c.totalproviders = str(snode2.getAttribute("totalnodes"))
                                for snode3 in snode2.childNodes:
                                    if snode3.nodeName == "node":
                                        n = pnode()
                                        n.number = str(snode3.getAttribute("number"))
                                        if snode3.firstChild and snode3.firstChild.nodeType == snode3.firstChild.TEXT_NODE:
                                            n.hexval = str(snode3.firstChild.nodeValue.strip())
                                        c.nodes.append(n)
                        r.cards.append(c)
                d.append(r)
        return d

    def dlAction(self):
        dom = xml.dom.minidom.parseString(self.data)
        r = self.parseXML(dom)

        list = []
        self.setTitle(r[0].totalcards+' Cards@'+r[0].label+'('+r[0].hostaddress+')')
        for c in r[0].cards:
            p = c.providers
            if len(p) > 4:
                list.append((c.number, c.caid, c.system, 'reshare = '+c.reshare, 'hops = '+c.hop,\
                str(len(p)),_("providers on this card max. display is:"),' ',_("Use Oscam Webif to see them all."),'4',' ',' ',' '))
            elif len(p) == 4:
                list.append((c.number, c.caid, c.system, 'reshare = '+c.reshare, 'hops = '+c.hop,\
                p[0].number,'@'+p[0].provid+'='+p[0].service,p[1].number,'@'+p[1].provid+'='+p[1].service,p[2].number,'@'+p[2].provid+'='+p[2].service,p[3].number,'@'+p[3].provid+'='+p[3].service))
            elif len(p) == 3:
                list.append((c.number, c.caid, c.system, 'reshare = '+c.reshare, 'hops = '+c.hop,\
                p[0].number,'@'+p[0].provid+'='+p[0].service,p[1].number,'@'+p[1].provid+'='+p[1].service,p[2].number,'@'+p[2].provid+'='+p[2].service,' ',' '))
            elif len(p) == 2:
                list.append((c.number, c.caid, c.system, 'reshare = '+c.reshare, 'hops = '+c.hop,\
                p[0].number,'@'+p[0].provid+'='+p[0].service,p[1].number,'@'+p[1].provid+'='+p[1].service,' ',' ',' ',' '))
            elif len(p) == 1:
                list.append((c.number, c.caid, c.system, 'reshare = '+c.reshare, 'hops = '+c.hop,\
                p[0].number,'@'+p[0].provid+'='+p[0].service,' ',' ',' ',' ',' ',' '))
        self["data"].setList(list)
        self.r = r

    def yellowPressed(self):
        self.session.open(ReaderServiceDataScreen, self.r)

# LogDataList...
class LogDataList(MenuList):
    def __init__(self, list, fontSize, enableWrapAround = True):
        MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)

        self.fontSize = fontSize

#  ------------------------------------ hier found und itemhigh fuer list logfile  ---------------------------------
        #if QXGA:
            #self.l.setFont(0, gFont("Regular", self.fontSize + 10))
        self.l.setFont(0, gFont("Regular", self.fontSize + 5))

    def postWidgetCreate(self, instance):
        MenuList.postWidgetCreate(self, instance)
        #if QXGA:
            #instance.setItemHeight(self.fontSize + 20)
        instance.setItemHeight(self.fontSize + 10)

# LogDataScreen...
class LogDataScreen(DownloadXMLScreen):
    w = "1280"
    w = getDesktop(0).size().width()
    if FULLHD:
        logout(data="LogDataScreen-skinFullFHD1")
        skin = """
        <screen flags="wfNoBorder" position="0,0" size="1920,1080" name="LogDataScreen" >
            <!-- Balken oben -->
            <eLabel name="oben" position="0,80" size="1920,4" backgroundColor="#00ffffff" zPosition="0" />
            <!-- Titel oben -->
            <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
            <!-- UHR -->
            <widget render="Label" source="global.CurrentTime" position="1641,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
            <convert type="ClockToText">Format:%H:%M:%S</convert>
            </widget>
            <!-- Hintergrung -->
            <eLabel name="mitte" position="0,80" size="1920,920" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
            <!-- Balken unten -->
            <eLabel name="unten" position="0,996" size="1920,4" backgroundColor="#00ffffff" zPosition="0" />
            <eLabel text="6" name="nummer" position="1840,1040" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                     
            <widget name="data" position="40,120" size="1900,800" font="Regular; 28" foregroundColor="#00ffffff" transparent="1" scrollbarMode="showOnDemand" />
        </screen>"""
    elif w == 1280:
        logout(data="LogDataScreen-skinFullFHD2")
        skin = """
            <screen name="LogDataScreen"  position="0,0" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="6" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget name="data" position="40,120" size="1200,500" font="Regular; 28" itemHeight="50" foregroundColor="#00ffffff" transparent="1" scrollbarMode="showOnDemand" />
            </screen>"""
    elif w == 1024:
        logout(data="LogDataScreen-skinFullFHD3")
        skin = """
            <screen flags="wfNoBorder" position="0,0" size="1024,576" name="LogDataScreen" >
                <widget render="Label" source="title"  position="42,70" size="700,26" valign="center" zPosition="5" transparent="0" foregroundColor="#fcc000" font="Regular;22"/>
                <widget name="data" position="42,100" size="940,400" scrollbarMode="showOnDemand" />
            </screen>"""
    else:
        logout(data="LogDataScreen-skinFullFHD4")
        skin = """
            <screen flags="wfNoBorder" position="0,0" size="720,576" name="LogDataScreen" >
                <widget render="Label" source="title"  position="10,70" size="700,26" valign="center" zPosition="5" transparent="0" foregroundColor="#fcc000" font="Regular;22"/>
                <widget name="data" position="10,130" size="700,352" scrollbarMode="showOnDemand" />
            </screen>"""


    def __init__(self, session, part, oServer):
        self.oServer = oServer
        self.skin = LogDataScreen.skin
        self.session = session
        Screen.__init__(self, session)

        globals_screen_instance = globalsConfigScreen(session)
        globals_screen_instance.Save()
        logfileschrift1 = globals_screen_instance.logschrift
        logout(data="logfileschrift1")
        logout(data=str(logfileschrift1))

        logfileschrift = logfileschrift1

        logout(data="logfileschrift")
        logout(data=str(logfileschrift))
        DownloadXMLScreen.__init__(self, session, part, oServer)


        if LogDataScreen.w == 3200:
            logout(data="LogDataScreen-QXGA")
            self.entryW = 2878
            self.entryH = 50 + logfileschrift
            self["data"] = LogDataList([], 30 + logfileschrift)


        elif FULLHD:
            logout(data="LogDataScreen-FullFHD1")
            self.entryW = 1878
            self.entryH = 20 + logfileschrift
            self["data"] = LogDataList([], 10 + logfileschrift)
        elif LogDataScreen.w == 1280:
            logout(data="LogDataScreen-FullFHD2")
            self.entryW = 1198
            self.entryH = 15 + logfileschrift
            self["data"] = LogDataList([], 15 + logfileschrift)
        elif LogDataScreen.w == 1024:
            logout(data="LogDataScreen-FullFHD3")
            self.entryW = 938
            self.entryH = 10 + logfileschrift
            self["data"] = LogDataList([], 10 + logfileschrift)
        else:
            logout(data="LogDataScreen-FullFHD4")
            self.entryW = 698
            self.entryH = 10 + logfileschrift
            self["data"] = LogDataList([], 10 + logfileschrift)

        #if FULLHD:
            #self.entryW = 1878
            #self.entryH = 80
            #self["data"] = LogDataList([], 25)
        #elif LogDataScreen.w == 1280:
            #self.entryW = 1198
            #self.entryH = 50
            #self["data"] = LogDataList([], 18)
        #elif LogDataScreen.w == 1024:
            #self.entryW = 938
            #self.entryH = 16
            #self["data"] = LogDataList([], 16)
        #else:
            #self.entryW = 698
            #self.entryH = 14
            #self["data"] = LogDataList([], 14)

        self["actions"] = ActionMap(["OkCancelActions"],
        {
            "cancel": self.Close
        }, -1)

    def parseXML(self, dom):
        d = "n/a"
        for node in dom.getElementsByTagName("log"):
            d = str(node.firstChild.nodeValue.strip())
            # in the OScam is still a small bug, in the log is a "'",
            # Here the XML parser exits and is replaced by a "'" ...
        d = d.replace("\xb4","\x27")
        return d

    def dlAction(self):
        dom = xml.dom.minidom.parseString(self.data)
        log = self.parseXML(dom)

        self.setTitle(_("Logfile")+"@"+self.oServer.serverName)
        list = []
        for line in log.splitlines():
            if "rejected" in line or "invalid" in line: c = "0xff2222" # red
            elif "written" in line: c = "0xff8c00" # orange
            elif " r " in line: c = "0xffd700" # yellow
            elif " p " in line: c = "0xadff2f" # green
            else: c = "0xffffff" # blanc
            item = [line]
            item.append((eListboxPythonMultiContent.TYPE_TEXT, 1, 1, self.entryW, self.entryH, 0, RT_HALIGN_LEFT, line, int(c, 16)))
            list.append(item)
        self["data"].setList(list)
        self["data"].selectionEnabled(0)
        # always at the end of the list ...
        x = len(list)
        if x:
            self["data"].moveToIndex(x-1)

# ReaderlistScreen...  -------------------------- Screen 5 Zeige alle Reader -----------------------------------
class ReaderlistScreen(DownloadXMLScreen):
    if FULLHD:
        logout(data="ReaderlistScreen-5-FHD")
        skin = """
            <screen name="ReaderlistScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="5" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="label0" position=" 50,110" size="180,30" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label1" position="330,110" size="230,30" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label2" position="560,110" size=" 160,30" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget source="data" render="Listbox" position="20,153" size="800,400" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" transparent="1" scrollbarMode="showOnDemand">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryPixmapAlphaTest(pos = (5, 14), size = (16, 16), png = 0),
                            MultiContentEntryText(pos = ( 30, 2), size = (175, 44), font=0, flags = RT_HALIGN_LEFT, text = 1),
                            MultiContentEntryText(pos = (315, 2), size = (135, 44), font=0, flags = RT_HALIGN_LEFT, text = 2),
                            MultiContentEntryText(pos = (555, 2), size = ( 15, 44), font=0, flags = RT_HALIGN_LEFT, text = 3),
                        ],
                        "fonts": [gFont("Regular", 25)],
                        "itemHeight": 50
                        }
                    </convert>
                </widget>
                <widget name="ButtonRed" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/red.png" position="50,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonRedtext" position="50,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="ButtonGreen" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/green.png" position="50,670" size="250,40" zPosition="2" transparent="1" alphatest="on"/>
                <widget name="ButtonGreentext" position="50,660" size="250,40" valign="center" halign="center" zPosition="3" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <eLabel text=" press OK - toggle reader On/Off " zPosition="4" position="50,580" size="800,38" font="Regular; 30" transparent="1" backgroundColor="#000f1b2f" foregroundColor="#0000ff00" halign="center" />
            </screen>"""
    else:
        skin = """
           <screen name="ReaderlistScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="5" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="label0" position=" 50,110" size="180,30" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label1" position="330,110" size="230,30" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label2" position="560,110" size=" 160,30" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget source="data" render="Listbox" position="20,153" size="800,400" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" transparent="1" scrollbarMode="showOnDemand">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryPixmapAlphaTest(pos = (5, 14), size = (16, 16), png = 0),
                            MultiContentEntryText(pos = ( 30, 2), size = (175, 44), font=0, flags = RT_HALIGN_LEFT, text = 1),
                            MultiContentEntryText(pos = (315, 2), size = (135, 44), font=0, flags = RT_HALIGN_LEFT, text = 2),
                            MultiContentEntryText(pos = (555, 2), size = ( 15, 44), font=0, flags = RT_HALIGN_LEFT, text = 3),
                        ],
                        "fonts": [gFont("Regular", 25)],
                        "itemHeight": 50
                        }
                    </convert>
                </widget>
                <widget name="ButtonRed" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/red.png" position="50,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonRedtext" position="50,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="ButtonGreen" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/green.png" position="50,670" size="250,40" zPosition="2" transparent="1" alphatest="on"/>
                <widget name="ButtonGreentext" position="50,660" size="250,40" valign="center" halign="center" zPosition="3" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <eLabel text=" press OK - toggle reader On/Off " zPosition="4" position="50,580" size="800,38" font="Regular; 30" transparent="1" backgroundColor="#000f1b2f" foregroundColor="#0000ff00" halign="center" />
            
            
            </screen>"""


    def __init__(self, session, part, oServer):
        logout(data="ReaderlistScreen-5-init")
        self.oServer = oServer
        self.skin = ReaderlistScreen.skin
        self.session = session
        Screen.__init__(self, session)

        DownloadXMLScreen.__init__(self, session, part, oServer)

        self["label0"] = StaticText(_("Reader"))
        self["label1"] = StaticText(_("Protocol"))
        self["label2"] = StaticText(_("type"))

        self["data"] = List(list)
        self["ButtonRed"] = Pixmap()
        self["ButtonRedtext"] = Button(_("disable reader"))
        self["ButtonGreen"] = Pixmap()
        self["ButtonGreentext"] = Button(_("enable reader"))

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"],
        {
            "up": self.upPressed,
            "down": self.downPressed,



            "left": self.leftPressed,
            "right": self.rightPressed,

            "ok": self.toggleReader,

            "red": self.redPressed,
            "green": self.greenPressed,
            "cancel": self.Close
        }, -1)

        self.icondis = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_PLUGIN, 
                              "Extensions/OscamStatus/icons/disabled.png"))
        self.iconena = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_PLUGIN, 
                              "Extensions/OscamStatus/icons/enabled.png"))

        self.isReadonly = True
        self.index = 0

        self.onLayoutFinish.append(self.LayoutFinished)

    def LayoutFinished(self):
        logout(data="ReaderlistScreen-5-finish")
        pass


    def parseXML(self, dom):
        readers = []
        logout(data="ReaderlistScreen-5")
        # Querying if WebIf readonly...
        if runningcam == ('oscam'):
            cam = "oscam"
        else:
            cam = "ncam"
        logout(data="ReaderlistScreen-5-cam")
        logout(data=str(cam))
        for node in dom.getElementsByTagName(cam):
            readonly = str(node.getAttribute("readonly"))


        if not int(readonly):
            self.isReadonly = False
        for elem in dom.getElementsByTagName("readers"):
            for node in elem.getElementsByTagName("reader"):
                r = readerlist()
                r.label = str(node.getAttribute("label"))
                r.protocol = str(node.getAttribute("protocol"))
                r.type = str(node.getAttribute("type"))
                r.enabled = str(node.getAttribute("enabled"))
                readers.append(r)
        return readers

    def dlAction(self):
        if self.newurl:
            self.newurl = False
            self.url = self.oldurl
            self.downloadXML()
            self.timer.start(TIMERTICK)
            return
        dom = xml.dom.minidom.parseString(self.data)
        self.readers = self.parseXML(dom)
        self.setList()

    def setList(self):
        list = []
        self.setTitle(_("All Readers @")+self.oServer.serverName)
        for index, r in enumerate(self.readers):
            if r.enabled=="1":
                list.append((self.iconena, r.label, r.protocol, r.type, r.enabled, index))
            else:
                list.append((self.icondis, r.label, r.protocol, r.type, r.enabled, index))
        self["data"].setList(list)
        if self.index < len(list):
            self["data"].setIndex(self.index)

        if self.isReadonly:
            self["ButtonRed"].hide()
            self["ButtonRedtext"].hide()
            self["ButtonGreen"].hide()
            self["ButtonGreentext"].hide()
        self.setupButtons()

    def setupButtons(self):
        self.index = self["data"].getCurrent()[5]
        if not self.isReadonly:
            if self["data"].getCurrent()[4] == "0":
                self["ButtonRed"].hide()
                self["ButtonRedtext"].hide()
                self["ButtonGreen"].show()
                self["ButtonGreentext"].show()
            else:
                self["ButtonRed"].show()
                self["ButtonRedtext"].show()
                self["ButtonGreen"].hide()
                self["ButtonGreentext"].hide()

    def toggleReader(self):
        if self.download or \
            self["data"].count() == 0 or \
            self.isReadonly:
            return

        current_reader = self["data"].getCurrent()
        if current_reader[4] == "0":  # Wenn der Reader rot ist
            part = "readerlist&action=enable&label=" + current_reader[1]
        else:  # Wenn der Reader grün ist
            part = "readerlist&action=disable&label=" + current_reader[1]

        self.sendNewPart(part)

    def redPressed(self):
        if self.download or \
           self["data"].count()==0 or \
           self.isReadonly or \
           self["data"].getCurrent()[4] == "0":
            return
        part = "readerlist&action=disable&label="+self["data"].getCurrent()[1]
        self.sendNewPart(part)

    def greenPressed(self):
        if self.download or \
           self["data"].count()==0 or \
           self.isReadonly or \
           self["data"].getCurrent()[4] == "1":
            return
        part = "readerlist&action=enable&label="+self["data"].getCurrent()[1]
        self.sendNewPart(part)

    def upPressed(self):
        if self.download:
            return
        self["data"].selectPrevious()
        self.setupButtons()

    def downPressed(self):



        if self.download:
            return
        self["data"].selectNext()
        self.setupButtons()

    def leftPressed(self):
        pass

    def rightPressed(self):



        pass

# ReaderstatsScreen...
w = getDesktop(0).size().width()
    
class ReaderstatsScreen(DownloadXMLScreen):
    # w = getDesktop(0).size().width()
    if w >= 1920:
        # FHD picon skin...         -----------------  Screen 4  ist die Reader Statstik in alle Reader ----------------------------------
        skin1 = """
            <screen name="ReaderstatsScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="4a" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="lEMMerror"   position="  80,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="lEMMwritten" position="345,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="lEMMskipped" position="620,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="lEMMblocked" position="895,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMerror"   position="  100,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMwritten" position="375,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMskipped" position="650,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMblocked" position="925,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                
                <widget render="Label" source="label0" position=" 20,253" size=" 60,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label1" position=" 80,253" size="225,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label2" position="285,253" size="210,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label3" position="655,253" size="100,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label4" position="865,253" size=" 95,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label5" position="1110,253" size=" 90,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget source="data" render="Listbox" position="20,320" size="1080,300" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" backgroundColor="#00313040" transparent="1" scrollbarMode="showOnDemand">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryText(pos = (  5, 2), size = ( 50, 44), font=0, flags = RT_HALIGN_RIGHT, text = 0),
                            MultiContentEntryText(pos = ( 80, 2), size = (215, 44), font=0, flags = RT_HALIGN_LEFT, text = 1),
                            MultiContentEntryText(pos = (385, 2), size = (205, 44), font=0, flags = RT_HALIGN_LEFT, text = 2),
                            MultiContentEntryText(pos = (680, 2), size = ( 95, 44), font=0, flags = RT_HALIGN_LEFT, text = 3),
                            MultiContentEntryText(pos = (790, 2), size = ( 90, 44), font=0, flags = RT_HALIGN_LEFT, text = 4),
                            MultiContentEntryText(pos = (890, 2), size = ( 90, 44), font=0, flags = RT_HALIGN_LEFT, text = 5),
                            MultiContentEntryPixmapAlphaTest(pos = (65, 0), size = (50, 30), png = 6),
                        ],
                        "fonts": [gFont("Regular", 26)],
                        "itemHeight": 50
                        }
                    </convert>
                </widget>
            </screen>"""

        # FHD without picons...         -----------------  Screen 4  ist die Reader Statstik in alle Reader ----------------------------------
        skin2 = """
            <screen name="ReaderstatsScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="4b" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="lEMMerror"   position="  80,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="lEMMwritten" position="345,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="lEMMskipped" position="620,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="lEMMblocked" position="895,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMerror"   position="  100,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMwritten" position="375,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMskipped" position="650,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMblocked" position="925,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                
                <widget render="Label" source="label0" position=" 20,253" size=" 100,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label1" position=" 140,253" size="225,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label2" position="425,253" size="310,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label3" position="755,253" size="100,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label4" position="965,253" size=" 150,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label5" position="1110,253" size=" 90,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget source="data" render="Listbox" position="20,320" size="1080,300" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" backgroundColor="#00313040" transparent="1" scrollbarMode="showOnDemand">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryText(pos = (  5, 2), size = ( 50, 44), font=0, flags = RT_HALIGN_RIGHT, text = 0),
                            MultiContentEntryText(pos = ( 80, 2), size = (215, 44), font=0, flags = RT_HALIGN_LEFT, text = 1),
                            MultiContentEntryText(pos = (425, 2), size = (205, 44), font=0, flags = RT_HALIGN_LEFT, text = 2),
                            MultiContentEntryText(pos = (760, 2), size = ( 95, 44), font=0, flags = RT_HALIGN_LEFT, text = 3),
                            MultiContentEntryText(pos = (970, 2), size = ( 90, 44), font=0, flags = RT_HALIGN_LEFT, text = 4),
                            MultiContentEntryText(pos = (1110, 2), size = ( 90, 44), font=0, flags = RT_HALIGN_LEFT, text = 5),
                        ],
                        "fonts": [gFont("Regular", 26)],
                        "itemHeight": 50
                        }
                    </convert>
                </widget>
            </screen>"""

    else:
        #HD picon skin...          -----------------  Screen 4  ist die Reader Statstik in alle Reader ----------------------------------
        skin1 = """
            <screen name="ReaderstatsScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="4c" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="lEMMerror"   position="  80,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="lEMMwritten" position="345,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="lEMMskipped" position="620,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="lEMMblocked" position="895,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMerror"   position="  100,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMwritten" position="375,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMskipped" position="650,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMblocked" position="925,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                
                <widget render="Label" source="label0" position=" 20,253" size=" 60,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label1" position=" 80,253" size="225,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label2" position="285,253" size="210,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label3" position="655,253" size="100,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label4" position="865,253" size=" 95,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label5" position="1010,253" size=" 190,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget source="data" render="Listbox" position="20,320" size="1080,300" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" backgroundColor="#00313040" transparent="1" scrollbarMode="showOnDemand">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryText(pos = (  5, 2), size = ( 50, 44), font=0, flags = RT_HALIGN_RIGHT, text = 0),
                            MultiContentEntryText(pos = ( 80, 2), size = (215, 44), font=0, flags = RT_HALIGN_LEFT, text = 1),
                            MultiContentEntryText(pos = (385, 2), size = (205, 44), font=0, flags = RT_HALIGN_LEFT, text = 2),
                            MultiContentEntryText(pos = (680, 2), size = ( 95, 44), font=0, flags = RT_HALIGN_LEFT, text = 3),
                            MultiContentEntryText(pos = (790, 2), size = ( 90, 44), font=0, flags = RT_HALIGN_LEFT, text = 4),
                            MultiContentEntryText(pos = (890, 2), size = ( 90, 44), font=0, flags = RT_HALIGN_LEFT, text = 5),
                            MultiContentEntryPixmapAlphaTest(pos = (65, 0), size = (50, 30), png = 6),
                        ],
                        "fonts": [gFont("Regular", 26)],
                        "itemHeight": 50
                        }
                    </convert>
                </widget>
            </screen>"""
        # HD without picons...  -----------------  Screen 4  ist die Reader Statstik in alle Reader ----------------------------------
        skin2 = """
            <screen name="ReaderstatsScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="4d" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="lEMMerror"   position="  80,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="lEMMwritten" position="345,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="lEMMskipped" position="620,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="lEMMblocked" position="895,130" size="225,70" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMerror"   position="  100,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMwritten" position="375,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMskipped" position="650,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget name="EMMblocked" position="925,200" size="175,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                
                <widget render="Label" source="label0" position=" 20,253" size=" 60,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label1" position=" 80,253" size="225,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label2" position="285,253" size="210,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label3" position="655,253" size="100,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label4" position="865,253" size=" 95,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label5" position="1010,253" size=" 190,50" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;28"/>
                <widget source="data" render="Listbox" position="20,320" size="1080,300" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" backgroundColor="#00313040" transparent="1" scrollbarMode="showOnDemand">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryText(pos = (  5, 2), size = ( 50, 44), font=0, flags = RT_HALIGN_RIGHT, text = 0),
                            MultiContentEntryText(pos = ( 80, 2), size = (215, 44), font=0, flags = RT_HALIGN_LEFT, text = 1),
                            MultiContentEntryText(pos = (385, 2), size = (205, 44), font=0, flags = RT_HALIGN_LEFT, text = 2),
                            MultiContentEntryText(pos = (680, 2), size = ( 95, 44), font=0, flags = RT_HALIGN_LEFT, text = 3),
                            MultiContentEntryText(pos = (790, 2), size = ( 90, 44), font=0, flags = RT_HALIGN_LEFT, text = 4),
                            MultiContentEntryText(pos = (890, 2), size = ( 90, 44), font=0, flags = RT_HALIGN_LEFT, text = 5),
                        ],
                        "fonts": [gFont("Regular", 26)],
                        "itemHeight": 50
                        }
                    </convert>
                </widget>
            </screen>"""

    def __init__(self, session, reader, part, oServer):
        self.oServer = oServer
        self.reader = reader
        if USEPICONS.value:
            self.skin = ReaderstatsScreen.skin1
        else:
            self.skin = ReaderstatsScreen.skin2
        self.session = session
        Screen.__init__(self, session)

        DownloadXMLScreen.__init__(self, session, part, oServer)

        self["label0"] = StaticText(_("req."))
        self["label1"] = StaticText(_("channelname"))
        self["label2"] = StaticText(_("caid:provid:srvid"))
        self["label3"] = StaticText(_("status"))
        self["label4"] = StaticText(_("lasttime"))
        self["label5"] = StaticText(_("avgtime"))
        self["lEMMerror"]   = StaticText("EMM error\nUK / G / S / UQ")
        self["lEMMwritten"] = StaticText("EMM written\nUK / G / S / UQ")
        self["lEMMskipped"] = StaticText("EMM skipped\nUK / G / S / UQ")
        self["lEMMblocked"] = StaticText("EMM blocked\nUK / G / S / UQ")
        self["EMMerror"]   = Label("")
        self["EMMwritten"] = Label("")
        self["EMMskipped"] = Label("")
        self["EMMblocked"] = Label("")

        self["data"] = List(list)

        self["actions"] = ActionMap(["OkCancelActions"],
        {
            "cancel": self.Close
        }, -1)

        self.onLayoutFinish.append(self.LayoutFinished)

    def LayoutFinished(self):
        pass


    def parseXML(self, dom):
        emms = []
        ecms = []
        for elem in dom.getElementsByTagName("emmstats"):
            for node in elem.getElementsByTagName("emm"):
                em = emm()
                em.type = str(node.getAttribute("type"))
                em.result = str(node.getAttribute("result"))
                if node.firstChild and node.firstChild.nodeType == node.firstChild.TEXT_NODE:
                    em.val = str(node.firstChild.nodeValue.strip())
                emms.append(em)
        for elem in dom.getElementsByTagName("ecmstats"):
            for node in elem.getElementsByTagName("ecm"):
                ec = ecm()
                ec.caid = str(node.getAttribute("caid"))
                ec.provid = str(node.getAttribute("provid"))
                ec.srvid = str(node.getAttribute("srvid"))
                ec.channelname = str(node.getAttribute("channelname"))
                ec.avgtime = str(node.getAttribute("avgtime"))
                ec.lasttime = str(node.getAttribute("lasttime"))
                ec.rc = str(node.getAttribute("rc"))
                ec.rcs = str(node.getAttribute("rcs"))
                ec.lastrequest = str(node.getAttribute("lastrequest"))
                if node.firstChild and node.firstChild.nodeType == node.firstChild.TEXT_NODE:
                    ec.val = str(node.firstChild.nodeValue.strip())
                ecms.append(ec)
        return emms, ecms

    def dlAction(self):
        dom = xml.dom.minidom.parseString(self.data)
        self.emms, self.ecms = self.parseXML(dom)
        self.setList()

    def setList(self):
        EMMerror = EMMwritten = EMMskipped = EMMblocked = ""
        for r in ["error", "written", "skipped", "blocked"]:
            for t in ["unknown", "global", "shared", "unique"]:
                for e in self.emms:
                    if r==e.result and t==e.type:
                        if r == "error":
                            EMMerror += e.val+" / "
                        if r == "written":
                            EMMwritten += e.val+" / "
                        if r == "skipped":
                            EMMskipped += e.val+" / "
                        if r == "blocked":
                            EMMblocked += e.val+" / "
        self["EMMerror"].setText(EMMerror[:-3])
        self["EMMwritten"].setText(EMMwritten[:-3])
        self["EMMskipped"].setText(EMMskipped[:-3])
        self["EMMblocked"].setText(EMMblocked[:-3])

        list = []
        self.picon = ePicLoad()
        self.setTitle("Status Reader "+self.reader+" @"+self.oServer.serverName)
        for e in self.ecms:
            if USEPICONS.value:
                picon = getPicon(e.channelname)
                if picon != "":
                    psw = 50
                    psh = 30
                    if FULLHD:
                        psw = 110
                        psh = 55
                    self.picon.setPara((psw, psh, 1, 1, False, 1, '#000f0f0f'))
                    self.picon.startDecode(picon, 0, 0, False)
                    png = self.picon.getData()
                else:
                    png = None
                list.append((e.val, e.channelname, e.caid+":"+e.provid+":"+e.srvid, e.rcs, e.lasttime, e.avgtime, png))
            else:
                list.append((e.val, e.channelname, e.caid+":"+e.provid+":"+e.srvid, e.rcs, e.lasttime, e.avgtime))

        # Sort by number of requests...
        if sys.version_info[0] >= 3:
            list.sort(key=lambda x: int(x[0]), reverse=True)
        else:
            def compare(a, b):
                return cmp(int(b[0]), int(a[0]))
            list.sort(compare)
        self["data"].setList(list)
        self["data"].setIndex(self.oldIndex)

# UserstatsScreen...  ------------------------- Screen 3   zeige alle  Clients -----------------------------------------
class UserstatsScreen(DownloadXMLScreen):
    if FULLHD:
    # HD skin
        skin = """
            <screen name="UserstatsScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#000000ff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="3" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="label0" position=" 50,100" size="145,40" valign="Top" zPosition="5" transparent="1"  foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label1" position="195,100" size="195,40" valign="Top" zPosition="5" transparent="1"  foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label2" position="440,100" size="155,40" valign="Top" zPosition="5" transparent="1"  foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label3" position="695,100" size="205,40" valign="Top" zPosition="5" transparent="1"  foregroundColor="#00ffffff" font="Regular;28"/>
                <widget source="data" render="Listbox" position="20,150" size="1000,400" font="Regular; 25" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" backgroundColor="#00313040" transparent="1"  scrollbarMode="showOnDemand">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryPixmapAlphaTest(pos = (5, 14), size = (16, 16), png = 0),
                            MultiContentEntryText(pos = ( 30, 2), size = (140, 50), font=0, flags = RT_HALIGN_LEFT, text = 1),
                            MultiContentEntryText(pos = (175, 2), size = (140, 50), font=0, flags = RT_HALIGN_LEFT, text = 2),
                            MultiContentEntryText(pos = (420, 2), size = (250, 50), font=0, flags = RT_HALIGN_LEFT, text = 3),
                            MultiContentEntryText(pos = (675, 2), size = (205, 50), font=0, flags = RT_HALIGN_LEFT, text = 4),
                        ],
                        "fonts": [gFont("Regular", 25)],
                        "itemHeight": 50
                        }
                    </convert>
                </widget>
                <widget name="ButtonRed" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/red.png" position="50,670"  size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonRedtext" position="50,660"  size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonGreen" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/green.png" position="50,670"  size="250,40" zPosition="2" transparent="1" alphatest="on"/>
                <widget name="ButtonGreentext" position="50,660"  size="250,40" valign="center" halign="center" zPosition="3" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
            </screen>"""

    else:
        skin = """
            <screen name="UserstatsScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="3" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="label0" position=" 50,100" size="145,40" valign="Top" zPosition="5" transparent="1"  foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label1" position="195,100" size="195,40" valign="Top" zPosition="5" transparent="1"  foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label2" position="440,100" size="155,40" valign="Top" zPosition="5" transparent="1"  foregroundColor="#00ffffff" font="Regular;28"/>
                <widget render="Label" source="label3" position="695,100" size="205,40" valign="Top" zPosition="5" transparent="1"  foregroundColor="#00ffffff" font="Regular;28"/>
                <widget source="data" render="Listbox" position="20,130" size="1000,400" font="Regular; 25" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" backgroundColor="#00313040" transparent="1"  scrollbarMode="showOnDemand">
                    <convert type="TemplatedMultiContent">
                        {"template": [
                            MultiContentEntryPixmapAlphaTest(pos = (5, 14), size = (16, 16), png = 0),
                            MultiContentEntryText(pos = ( 30, 2), size = (140, 50), font=0, flags = RT_HALIGN_LEFT, text = 1),
                            MultiContentEntryText(pos = (175, 2), size = (140, 50), font=0, flags = RT_HALIGN_LEFT, text = 2),
                            MultiContentEntryText(pos = (420, 2), size = (250, 50), font=0, flags = RT_HALIGN_LEFT, text = 3),
                            MultiContentEntryText(pos = (675, 2), size = (205, 50), font=0, flags = RT_HALIGN_LEFT, text = 4),
                        ],
                        "fonts": [gFont("Regular", 25)],
                        "itemHeight": 50
                        }
                    </convert>
                </widget>
                <widget name="ButtonRed" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/red.png" position="50,670"  size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonRedtext" position="50,660"  size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonGreen" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/green.png" position="50,670"  size="250,40" zPosition="2" transparent="1" alphatest="on"/>
                <widget name="ButtonGreentext" position="50,660"  size="250,40" valign="center" halign="center" zPosition="3" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
            </screen>"""


    def __init__(self, session, part, oServer):
        self.oServer = oServer
        self.skin = UserstatsScreen.skin
        self.session = session
        Screen.__init__(self, session)

        DownloadXMLScreen.__init__(self, session, part, oServer)

        self["label0"] = StaticText(_("Client"))
        self["label1"] = StaticText(_("IP"))
        self["label2"] = StaticText(_("Status"))
        self["label3"] = StaticText(_("Protocol"))
        self["data"] = List(list, enableWrapAround = True)
        self["ButtonRed"] = Pixmap()
        self["ButtonRedtext"] = Button(_("disable client"))
        self["ButtonGreen"] = Pixmap()
        self["ButtonGreentext"] = Button(_("enable client"))

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"],
        {
            "up": self.upPressed,
            "down": self.downPressed,

            "left": self.leftPressed,
            "right": self.rightPressed,

            "red": self.redPressed,
            "green": self.greenPressed,
            "cancel": self.Close
        }, -1)

        self.icondis = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_PLUGIN, 
                              "Extensions/OscamStatus/icons/disabled.png"))
        self.iconena = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_PLUGIN, 
                              "Extensions/OscamStatus/icons/enabled.png"))

        self.isReadonly = True
        self.index = 0
        
        self.onLayoutFinish.append(self.LayoutFinished)

    def LayoutFinished(self):
        pass


    def parseXML(self, dom):
        d = []
        # Querying Oscam version and permission WebIf ...
        if runningcam == ('oscam'):
            cam = "oscam"
        else:
            cam = "ncam"
        for node in dom.getElementsByTagName(cam):
            revision = str(node.getAttribute("revision"))
            readonly = str(node.getAttribute("readonly"))
        self.isReadonly = False

        for elem in dom.getElementsByTagName("users"):
            for node in elem.getElementsByTagName("user"):
                u = user()
                u.name = str(node.getAttribute("name"))
                u.status = str(node.getAttribute("status"))
                u.ip = str(node.getAttribute("ip"))
                u.protocol = str(node.getAttribute("protocol"))
                for node2 in node.getElementsByTagName("stats"):
                    for snode in node2.childNodes:
                        if snode.nodeName == "timeonchannel":
                            if snode.firstChild and snode.firstChild.nodeType == snode.firstChild.TEXT_NODE:
                                u.timeonchannel = str(snode.firstChild.nodeValue.strip())
                d.append(u)
        return d

    def dlAction(self):
        if self.newurl:
            self.newurl = False
            self.url = self.oldurl
            self.downloadXML()
            self.timer.start(TIMERTICK)
            return
        dom = xml.dom.minidom.parseString(self.data)
        self.users = self.parseXML(dom)
        self.setList()

    def setList(self):
        list = []
        self.setTitle(_("All Clients")+"@"+self.oServer.serverName)
        for index, u in enumerate(self.users):
            if u.timeonchannel != "n/a":
                self["label1"].setText(_("time on channel"))
                u.ip = elapsedTime(u.timeonchannel, "%02d:%02d:%02d")
            if "disabled" in u.status:
                list.append((self.icondis, u.name, u.ip, u.status, u.protocol, index))        
            else:
                list.append((self.iconena, u.name, u.ip, u.status, u.protocol, index))        
        self["data"].setList(list)
        if self.index < len(list):
            self["data"].setIndex(self.index)

        if self.isReadonly:
            self["ButtonRed"].hide()
            self["ButtonRedtext"].hide()
            self["ButtonGreen"].hide()
            self["ButtonGreentext"].hide()
        self.setupButtons()

    def setupButtons(self):
        self.index = self["data"].getCurrent()[5]
        if not self.isReadonly:
            if "disabled" in self["data"].getCurrent()[3]:
                self["ButtonRed"].hide()
                self["ButtonRedtext"].hide()
                self["ButtonGreen"].show()
                self["ButtonGreentext"].show()
            else:
                self["ButtonRed"].show()
                self["ButtonRedtext"].show()
                self["ButtonGreen"].hide()
                self["ButtonGreentext"].hide()

    def redPressed(self):
        if self.download or \
           self["data"].count()==0 or \
           self.isReadonly or \
           "disabled" in self["data"].getCurrent()[3]:
            return
        part = "userconfig&user="+self["data"].getCurrent()[1]+"&disabled=1&action=Save"
        self.sendNewPart(part)

    def greenPressed(self):
        if self.download or \
           self["data"].count()==0 or \
           self.isReadonly or \
           not "disabled" in self["data"].getCurrent()[3]:
            return
        part = "userconfig&user="+self["data"].getCurrent()[1]+"&disabled=0&action=Save"
        self.sendNewPart(part)

    def upPressed(self):
        if self.download:
            return
        self["data"].selectPrevious()
        self.setupButtons()

    def downPressed(self):
        if self.download:
            return
        self["data"].selectNext()
        self.setupButtons()

    def leftPressed(self):
        pass

    def rightPressed(self):
        pass

# StatusDataScreen...  ------------------------------  Screen nummer 2 verbundene Clients und Reader ---------------------------------------------------
class StatusDataScreen(DownloadXMLScreen):
    if FULLHD:
        # FHD picon skin...
        skin1 = """
                <screen name="StatusDataScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="2" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="label0" position=" 20, 100" size=" 320, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label1" position="350, 100" size=" 250, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label2" position="610, 100" size="  50, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label3" position="670, 100" size=" 130, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label4" position="1000, 100" size=" 270, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label5" position="810,100" size="280, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>

                <widget source="data" render="Listbox" position=" 20,130" size="1160,400" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" backgroundColor="#00313040" scrollbarMode="showOnDemand" transparent="1">
                        <convert type="TemplatedMultiContent">
                            {"template": [
                                MultiContentEntryText(pos = (  2, 3), size = (320, 48), font=0, flags = RT_HALIGN_LEFT, text = 0),
                                MultiContentEntryText(pos = (332, 2), size = (250, 48), font=0, flags = RT_HALIGN_LEFT, text = 1),
                                MultiContentEntryPixmapAlphaTest(pos = (600, 14), size = (50, 28), png = 2),
                                MultiContentEntryText(pos = (652, 2), size = (130, 48), font=0, flags = RT_HALIGN_LEFT, text = 3),
                                MultiContentEntryPixmapAlphaTest(pos = (1005, 0), size = (50, 30), png = 6),
                                MultiContentEntryText(pos = (792, 2), size = (370, 48), font=0, flags = RT_HALIGN_LEFT, text = 4),
                            ],
                            "fonts": [gFont("Regular", 26)],
                            "itemHeight": 50
                            }
                        </convert>
                    </widget>
                <widget name="ButtonYellow" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/yellow.png" position="650,670" size="250,40" zPosition="4" alphatest="on"/>
                <widget name="ButtonYellowtext" position="650,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonBlue" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/blue.png" position="950,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonBluetext" position="950,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
            </screen>"""

        # FHD without picons...------------------------------  Screen nummer 2 verbundene Clients und Reader ---------------------------------------------------
        skin2 = """
                <screen name="StatusDataScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="2" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="label0" position=" 20, 100" size=" 320, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label1" position="350, 100" size=" 250, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label2" position="610, 100" size="  50, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label3" position="670, 100" size=" 130, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label4" position="810, 100" size=" 370, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                
                <widget source="data" render="Listbox" position=" 20,130" size="1160,400" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" backgroundColor="#00313040" scrollbarMode="showOnDemand" transparent="1">
                        <convert type="TemplatedMultiContent">
                            {"template": [
                                MultiContentEntryText(pos = (  2, 3), size = (320, 48), font=0, flags = RT_HALIGN_LEFT, text = 0),
                                MultiContentEntryText(pos = (332, 2), size = (250, 48), font=0, flags = RT_HALIGN_LEFT, text = 1),
                                MultiContentEntryPixmapAlphaTest(pos = (600, 14), size = (50, 28), png = 2),
                                MultiContentEntryText(pos = (652, 2), size = (130, 48), font=0, flags = RT_HALIGN_LEFT, text = 3),
                                MultiContentEntryText(pos = (792, 2), size = (370, 48), font=0, flags = RT_HALIGN_LEFT, text = 4),
                            ],
                            "fonts": [gFont("Regular", 26)],
                            "itemHeight": 50
                            }
                        </convert>
                    </widget>
                <widget name="ButtonYellow" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/yellow.png" position="650,670" size="250,40" zPosition="4" alphatest="on"/>
                <widget name="ButtonYellowtext" position="650,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonBlue" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/blue.png" position="950,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonBluetext" position="950,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
            </screen>"""

    else:
        # picon skin..HD ------------------------------  Screen nummer 2 verbundene Clients und Reader ---------------------------------------------------
        skin1 = """
            <screen name="StatusDataScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="2" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="label0" position=" 20, 100" size=" 320, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label1" position="350, 100" size=" 250, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label2" position="610, 100" size="  50, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label3" position="670, 100" size=" 130, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label4" position="1000, 100" size=" 270, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label5" position="810,100" size="280,28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>

                <widget source="data" render="Listbox" position=" 20,130" size="1160,400" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" backgroundColor="#00313040" scrollbarMode="showOnDemand" transparent="1">
                        <convert type="TemplatedMultiContent">
                            {"template": [
                                MultiContentEntryText(pos = (  2, 3), size = (320, 48), font=0, flags = RT_HALIGN_LEFT, text = 0),
                                MultiContentEntryText(pos = (332, 2), size = (250, 48), font=0, flags = RT_HALIGN_LEFT, text = 1),
                                MultiContentEntryPixmapAlphaTest(pos = (600, 14), size = (50, 28), png = 2),
                                MultiContentEntryText(pos = (652, 2), size = (130, 48), font=0, flags = RT_HALIGN_LEFT, text = 3),
                                MultiContentEntryPixmapAlphaTest(pos = (1005, 0), size = (50, 30), png = 6),
                                MultiContentEntryText(pos = (792, 2), size = (370, 48), font=0, flags = RT_HALIGN_LEFT, text = 4),
                            ],
                            "fonts": [gFont("Regular", 26)],
                            "itemHeight": 50
                            }
                        </convert>
                    </widget>
                <widget name="ButtonYellow" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/yellow.png" position="650,670" size="250,40" zPosition="4" alphatest="on"/>
                <widget name="ButtonYellowtext" position="650,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonBlue" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/blue.png" position="950,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonBluetext" position="950,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
            </screen>"""

        # without picons.HD..------------------------------  Screen nummer 2 verbundene Clients und Reader ---------------------------------------------------
        skin2 = """
            <screen name="StatusDataScreen"  position="center,center" size="1280,720" backgroundColor="#00000000" flags="wfNoBorder" title="">
                <!-- Balken oben -->
                <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <!-- Titel oben -->
                <widget render="Label" source="title" position="100,15" size="700,50"  valign="center"  zPosition="2" transparent="1" font="Regular; 30" foregroundColor="#00ffffff" backgroundColor="#00000000" halign="left" />
                <!-- UHR -->
                <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#003a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
                </widget>
                <!-- Hintergrung -->
                <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="-1" transparent="0" />
                <!-- Balken unten -->
                <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="#00ffffff" zPosition="0" />
                <eLabel text="2" name="nummer" position="1210,670" size="60,40" foregroundColor="#3a3998" backgroundColor="black" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
                
                <widget render="Label" source="label0" position=" 20, 100" size=" 320, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label1" position="350, 100" size=" 250, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label2" position="610, 100" size="  50, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label3" position="670, 100" size=" 130, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget render="Label" source="label4" position="810, 100" size=" 370, 28" valign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                
                <widget source="data" render="Listbox" position=" 20,130" size="1160,400" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" backgroundColor="#00313040" scrollbarMode="showOnDemand" transparent="1">
                        <convert type="TemplatedMultiContent">
                            {"template": [
                                MultiContentEntryText(pos = (  2, 3), size = (320, 48), font=0, flags = RT_HALIGN_LEFT, text = 0),
                                MultiContentEntryText(pos = (332, 2), size = (250, 48), font=0, flags = RT_HALIGN_LEFT, text = 1),
                                MultiContentEntryPixmapAlphaTest(pos = (600, 14), size = (50, 28), png = 2),
                                MultiContentEntryText(pos = (652, 2), size = (130, 48), font=0, flags = RT_HALIGN_LEFT, text = 3),
                                MultiContentEntryText(pos = (792, 2), size = (370, 48), font=0, flags = RT_HALIGN_LEFT, text = 4),
                            ],
                            "fonts": [gFont("Regular", 26)],
                            "itemHeight": 50
                            }
                        </convert>
                    </widget>
                <widget name="ButtonYellow" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/yellow.png" position="650,670" size="250,40" zPosition="4" alphatest="on"/>
                <widget name="ButtonYellowtext" position="650,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonBlue" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/blue.png" position="950,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonBluetext" position="950,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
            </screen>"""

    def __init__(self, session, type, part, oServer):
        self.type = type
        self.oServer = oServer
        if USEPICONS.value:
            self.skin = StatusDataScreen.skin1
        else:
            self.skin = StatusDataScreen.skin2
        self.session = session
        Screen.__init__(self, session)

        DownloadXMLScreen.__init__(self, session, part, oServer)

        self["data"] = List([])
        if self.type == "clients":
            self["label0"] = StaticText(_("Name"))
            self["label1"] = StaticText(_("Reader"))
            self["label2"] = StaticText(_("AU"))
            if USEECM.value:
                self["label3"] = StaticText(_("ECM Time"))
            else:
                self["label3"] = StaticText(_("Idle Time"))

            if USEPICONS.value:
                self["label4"] = StaticText(_("Picon"))
                self["label5"] = StaticText(_("Channel"))
            else:
                self["label4"] = StaticText(_("Channel"))

            self["ButtonYellow"] = Pixmap()
            self["ButtonYellowtext"] = Button(_("show client info"))
            self["ButtonBlue"] = Pixmap()
            self["ButtonBluetext"] = Button(_("hide idle clients"))
        else:
            self["label0"] = StaticText(_("Name"))
            self["label1"] = StaticText(_("Status"))
            self["label2"] = StaticText(_("AU"))
            if USEECM.value:
                self["label3"] = StaticText(_("ECM Time"))
            else:
                self["label3"] = StaticText(_("Idle Time"))

            if USEPICONS.value:
                self["label4"] = StaticText(_("Picon"))
                self["label5"] = StaticText(_("Protocol"))
            else:
                self["label4"] = StaticText(_("Protocol"))

            self["ButtonYellow"] = Pixmap()
            self["ButtonYellowtext"] = Button(_("show reader info"))
            self["ButtonBlue"] = Pixmap()
            self["ButtonBluetext"] = Button(_("show readerstats"))

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
        {
            "yellow": self.yellowPressed,
            "blue": self.bluePressed,
            "cancel": self.Close
        }, -1)

        auRed = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_PLUGIN, 
                              "Extensions/OscamStatus/icons/au_red.png"))
        auGreen = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_PLUGIN, 
                              "Extensions/OscamStatus/icons/au_green.png"))
        auYellow = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_PLUGIN, 
                              "Extensions/OscamStatus/icons/au_yellow.png"))
        # dict for Status AU
        self.auEntrys = {"1":auGreen, "0":auRed, "-1":auYellow}

        self.hideIdle = False

        self.onLayoutFinish.append(self.LayoutFinished)

    def LayoutFinished(self):
        pass



    def parseXML(self, dom):
        d = []
        for elem in dom.getElementsByTagName("status"):
            for node in elem.getElementsByTagName("client"):
                c = client()
                c.type = str(node.getAttribute("type"))
                c.name = str(node.getAttribute("name"))
                c.protocol = str(node.getAttribute("protocol"))
                c.protocolext = str(node.getAttribute("protocolext"))
                c.au = str(node.getAttribute("au"))

                for snode in node.childNodes:
                    if snode.nodeName == "request":
                        c.caid = str(snode.getAttribute("caid"))
                        c.provid = str(snode.getAttribute("provid"))
                        c.srvid = str(snode.getAttribute("srvid"))
                        c.ecmtime = str(snode.getAttribute("ecmtime"))
                        c.ecmhistory = str(snode.getAttribute("ecmhistory"))
                        c.answered = str(snode.getAttribute("answered"))
                        if snode.firstChild and snode.firstChild.nodeType == snode.firstChild.TEXT_NODE:
                            c.service = str(snode.firstChild.nodeValue.strip())

                    if snode.nodeName == "times":
                        c.login = str(snode.getAttribute("login"))
                        c.online = str(snode.getAttribute("online"))
                        c.idle = str(snode.getAttribute("idle"))

                    if snode.nodeName == "connection":
                        c.ip = str(snode.getAttribute("ip"))
                        c.port = str(snode.getAttribute("port"))
                        if snode.firstChild and snode.firstChild.nodeType == snode.firstChild.TEXT_NODE:
                            c.connection = str(snode.firstChild.nodeValue.strip())
                d.append(c)
        return d

    def dlAction(self):
        dom = xml.dom.minidom.parseString(self.data)
        self.status = self.parseXML(dom)
        self.setList()

    def setList(self):
        dlist = []
        self.picon = ePicLoad()
        if self.type == "clients":
            self.setTitle(_("Connected Clients")+"@"+self.oServer.serverName)
            for index, c in enumerate(self.status):
                if c.type == "c":
                    if USEECM.value:
                        idle = c.ecmtime
                    else:
                        idle = elapsedTime(c.idle, "%02d:%02d:%02d")
                    if USEPICONS.value:
                        picon = getPicon(c.service)
                        if picon != "":
                            psw = 50
                            psh = 30
                            if FULLHD:
                                psw = 110
                                psh = 55
                            self.picon.setPara((psw, psh, 1, 1, False, 1, '#000f0f0f'))
                            self.picon.startDecode(picon, 0, 0, False)
                            png = self.picon.getData()

                    if self.hideIdle:
                        if c.answered != "":
                            if USEPICONS.value:
                                dlist.append((c.name, c.answered, self.auEntrys[c.au], idle, png, c.service, index))
                            else:
                                dlist.append((c.name, c.answered, self.auEntrys[c.au], idle, c.service, index))
                    else:
                        if USEPICONS.value:
                            picon = getPicon(c.service)
                            if picon != "":
                                psw = 50
                                psh = 30
                                if FULLHD:
                                    psw = 110
                                    psh = 55
                                self.picon.setPara((psw, psh, 1, 1, False, 1, '#000f0f0f'))
                                self.picon.startDecode(picon, 0, 0, False)
                                png = self.picon.getData()
                            dlist.append((c.name, c.answered, self.auEntrys[c.au], idle, png, c.service, index))
                        else:
                            dlist.append((c.name, c.answered, self.auEntrys[c.au], idle, c.service, index))

        elif self.type == "readers":
            self.setTitle(_("Connected Readers")+"@"+self.oServer.serverName)
            for index, c in enumerate(self.status):
                if USEECM.value:
                    idle = c.ecmtime
                else:
                    idle = elapsedTime(c.idle, "%02d:%02d:%02d")

                if c.type == "r" or c.type == "p":
                    if USEPICONS.value:
                        picon = getPicon(c.protocol)
                        if picon != "":
                            psw = 50
                            psh = 30
                            if FULLHD:
                                psw = 110
                                psh = 55
                            self.picon.setPara((psw, psh, 1, 1, False, 1, '#000f0f0f'))
                            self.picon.startDecode(picon, 0, 0, False)
                            png = self.picon.getData()          
                        dlist.append((c.name, c.connection, self.auEntrys[c.au], idle, png, c.protocol, index))
                    else:
                        dlist.append((c.name, c.connection, self.auEntrys[c.au], idle, c.protocol, index))

        self["data"].setList(dlist)
        self["data"].setIndex(self.oldIndex)

    def yellowPressed(self):
        if self.download or self["data"].count()==0:
            return
        if USEPICONS.value:
            index = self["data"].getCurrent()[6]
        else:
            index = self["data"].getCurrent()[5]
        if index is not None:
            self.timer.stop()
            self.session.openWithCallback(self.backCB, ClientDataScreen, self.type, self.oServer, self.status[index])

    def bluePressed(self):
        logout(data="bluepsress_stat")
        if self.download:
            return
        if self.type == "readers" and self["data"].count():
            logout(data="bluepsress_stat1")
            reader = self["data"].getCurrent()[0]
            part = "readerstats&label="+reader
            self.session.openWithCallback(self.backCB, ReaderstatsScreen, reader, part, self.oServer)
            return
        if self.hideIdle:
            logout(data="bluepsress_stat2")
            self["ButtonBluetext"].setText(_("hide idle clients"))
        else:
            self["ButtonBluetext"].setText(_("show idle clients"))
            logout(data="bluepsress_stat3")
        self.hideIdle = not self.hideIdle
        self.setList()

    def backCB(self, retval):
        self.timer.start(TIMERTICK)

# mainScreen...  ------------------------------  Screen nummer 1 ---------------------------------------------------
class OscamStatus(Screen):




    skin = """
        <screen name="OscamStatus" position="center,center" size="1280,720" backgroundColor="#00000000" transparent="0" flags="wfNoBorder" title="Oscam Status">
            <!-- Balken oben -->
            <eLabel name="oben" position="0,80" size="1280,4" backgroundColor="#00ffffff" zPosition="2" transparent="0"  />
            <!-- Titel oben -->
            <widget render="Label" source="title" position="100,15" size="700,50" valign="center" zPosition="2" transparent="2" font="Regular; 30" foregroundColor="#00ffffff" halign="left" />
            <!-- UHR -->
            <widget render="Label" source="global.CurrentTime" position="1041,13" size="225,50" font="Regular;40" foregroundColor="#3a3998" backgroundColor="#00ffffff" halign="center" valign="center" zPosition="2">
                <convert type="ClockToText">Format:%H:%M:%S</convert>
            </widget>
            <!-- Hintergrung -->
            <eLabel name="mitte" position="0,80" size="1280,560" backgroundColor="#000f1b2f" zPosition="1" />
            <!-- Balken unten -->
            <eLabel name="unten" position="0,636" size="1280,4" backgroundColor="white" zPosition="2" transparent="0"  />
            <eLabel text="1" name="nummer" position="1210,670" size="60,40" foregroundColor="#001e53ff" backgroundColor="#00000000" zPosition="2" transparent="1" font="Regular; 25"  halign="center" />
            <!-- =====================================================================  -->
            <eLabel text="MENU" position="100,590" size="100,34" valign="center" halign="left" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;30" />

            <widget render="Label" source="KeyMenuText" position="276,590" size="300,34" valign="center" halign="left" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;30" />

            <widget source="menu" render="Listbox" position="100,110" size="600,500" zPosition="5" transparent="1" backgroundColorSelected="#001e53ff" foregroundColorSelected="white" foregroundColor="#00ffffff" backgroundColor="#00313040" scrollbarMode="showOnDemand">
                            <convert type="TemplatedMultiContent">
                                {"template": [
                                    MultiContentEntryPixmapAlphaTest(pos = (28, 6), size = (32, 32), png = 0),
                                    MultiContentEntryText(pos = (175, 0), size = (600, 50), font=0, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text = 1),
                                ],
                                "fonts": [gFont("Regular", 30)],
                                "itemHeight": 60
                                }
                            </convert>
                        </widget>                       

            <widget name="camversion" font="Regular; 35" position="900,340" size="250,100" transparent="1" backgroundColor="#00000000" foregroundColor="#0000ff00" zPosition="3" halign="center" valign="center" />
            <eLabel text="AKTIV Cam Version" position="800,300" size="450,50" font="Regular; 35" backgroundColor="#00000000"  foregroundColor="#00ffffff" halign="center" valign="center"  transparent="1" zPosition="5" />
            <ePixmap position="980,480" size="100,40" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/OscamStatus.png" transparent="1" alphatest="blend" />
            <ePixmap position="980,560" size="100,40" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/NcamStatus.png" transparent="1" alphatest="blend" />

            
            <widget name="ButtonRed" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/red.png" position="50,670" size="250,40" zPosition="2" transparent="1" alphatest="on"/>
                <widget name="ButtonRedtext" position="50,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>               
                <widget name="ButtonGreen" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/green.png" position="350,670" size="250,40" zPosition="2" transparent="1" alphatest="on"/>
                <widget name="ButtonGreentext" position="350,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonYellow" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/yellow.png" position="650,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonYellowtext" position="650,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>
                <widget name="ButtonBlue" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/blue.png" position="950,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>
                <widget name="ButtonBluetext" position="950,660" size="250,40" valign="center" halign="center" zPosition="5" transparent="1" foregroundColor="#00ffffff" font="Regular;26"/>




        </screen>"""
        #            <widget name="ButtonBlue" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/buttons/led/blue.png" position="950,670" size="250,40" zPosition="4" transparent="1" alphatest="on"/>


    def __init__(self, session):
        self.skin = OscamStatus.skin
        self.session = session



        Screen.__init__(self, session)
        picpath = "/usr/lib/enigma2/python/Plugins/Extensions/OscamStatus/icons/menu.png"
        # *****************************************************************************************
        self.camversion = runningcam

        logout(data="camversion_data")
        logout(data=str(runningcam))
        logout(data=str(self.camversion))
        self["camversion"] = Label()

        logout(data="--- camversion_data ------------")
        # ****************************************************************************************

        ipath = resolveFilename(SCOPE_CURRENT_PLUGIN, "Extensions/OscamStatus/icons/")
        icon = []
        for i in ["icon1", "icon2", "icon3", "icon4", "icon5", "icon6", "icon7", "icon8"]:
            icon.append(LoadPixmap(cached = True, path = ipath + i + ".png"))

        list = []
        list.append((icon[0], _("show connected clients"), "clients"))        
        list.append((icon[1], _("show all clients"), "allClients"))        
        list.append((icon[2], _("show connected readers"), "readers"))        
        list.append((icon[3], _("show all readers"), "allReaders"))        
        list.append((icon[4], _("show logfile"), "log"))        
        list.append((icon[5], _("server info"), "info"))        
        list.append((icon[6], _("server restart/shutdown"), "restart"))        
        list.append((icon[7], _("server setup"), "setup"))

        #self["ButtonBluetext"] = Button(_("Update Oscam"))
        #self["ButtonBluetext"] = StaticText(_("Update Oscam"))
        #self["key_yellow"] = Button(_("log File"))
        #self["key_green"] = Button(_("reader"))

        #self["ButtonRed"] = Pixmap()
        #self["ButtonRedtext"] = Button(_("update binary "))

        self["ButtonGreen"] = Pixmap()
        self["ButtonGreentext"] = Button(_("Reader"))
        self["ButtonYellow"] = Pixmap()
        self["ButtonYellowtext"] = Button(_("Log File"))
        self["ButtonBlue"] = Pixmap()
        self["ButtonBluetext"] = Button(_("Update Oscam"))


        self["title"] = StaticText("")
        self["menu"] = List(list)
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "MenuActions", "ColorActions"],
        {
            "ok": self.action,
            "cancel": self.close,
            'yellow': self.logfile,
            'green': self.reader,
            "blue": self.updateoscam,
            "menu": self.globalsDlg
        }, -2)
        self["KeyMenu"] = Pixmap()
        #self["ButtonBlue"] = Pixmap()
        self["KeyMenuText"] = StaticText(_("Configuration screen"))
        logout(data="--- screen_data ------------")


        oscamServers = readCFG()
        logout(data="--- oscamservers ------------")
        logout(data=str(oscamServers))





        index = LASTSERVER.value
        if index+1 > len(oscamServers):
            index = 0

        self.SetupCB(oscamServers[index])



    def action(self):
        returnValue = self["menu"].getCurrent()[2]
        self["title"].setText(_("Oscam Status ") + VERSION + " @" + self.oServer.serverName)
        if returnValue is not None:
            if returnValue == "clients":
                self.session.open(StatusDataScreen, "clients", "status", self.oServer)
            elif returnValue == "allClients":
                self.session.open(UserstatsScreen, "userstats", self.oServer)
            elif returnValue == "readers":
                self.session.open(StatusDataScreen, "readers", "status", self.oServer)
            elif returnValue == "allReaders":
                # part=readerlist erst ab 5773 ...
                self.session.open(ReaderlistScreen, "readerlist", self.oServer)
            elif returnValue == "log":
                self.session.open(LogDataScreen, "status&appendlog=1", self.oServer)
            elif returnValue == "info":
                self.session.open(OscamDataScreen, "status", self.oServer)
            elif returnValue == "setup":
                self.session.openWithCallback(self.SetupCB, OscamServerEntriesListConfigScreen)
            elif returnValue == "restart":
                self.session.open(OscamRestartScreen, "status", self.oServer)

    def SetupCB(self, entry):
        if entry:
            self.oServer = entry
            self["title"].setText(_("Oscam Status ")+VERSION+" @"+self.oServer.serverName)
            # ************************************************************************************************
            self["camversion"].setText("%s " % (self.camversion))

            # ***********************************************************************************************

    def globalsDlg(self):
#       self.oldpath = PICONPATH.value
        self.session.openWithCallback(self.globalsCB, globalsConfigScreen)

    def globalsCB(self):
       pass


    def updateoscam(self):
       self.session.open(UpdateOscamScreen, "status", self.oServer)

    def reader(self):
       self.session.open(ReaderlistScreen, "readerlist", self.oServer)


    def logfile(self):
       self.session.open(LogDataScreen, "status&appendlog=1", self.oServer)


    def findPicon(self, service=None):
        if service is not None:
            sname = ':'.join(service.split(':')[:11])
            pos = sname.rfind(':')
            if pos != -1:
                sname = sname[:pos].rstrip(':').replace(':','_')
                for path in self.searchPiconPaths:
                    pngname = path + sname + ".png"
                    if fileExists(pngname):
                        return pngname
        return ""

def main(session,**kwargs):
    global runningcam
    logout(data="main")



    #------------------  check oscam oder ncam ---------- File copieren -----------------------
    from shutil import copyfile




    destination ="/tmp/oscam.version"
    oscampath ="/tmp/.oscam/oscam.version"
    ncampath ="/tmp/.ncam/ncam.version"

    logout(data="camversion")
    if os.path.isfile(oscampath):
        logout(data="version oscam")
        copyfile(oscampath, destination)
        runningcam ="oscam"
        logout(data=str(runningcam))
    else:
        logout(data="keine oscam")


        if os.path.isfile(ncampath):
            logout(data="version ncam")
            runningcam = "ncam"
            logout(data=str(runningcam))


        else:
            logout(data="keine ncam")


# ---------------------------------------------------------------------------------------------


    logout(data="mainout")
    session.open(OscamStatus)


def Plugins(**kwargs):
    l = [PluginDescriptor(name= _("Oscam Ncam Status"), description=_("whats going on?"), where = PluginDescriptor.WHERE_PLUGINMENU, icon="OscamStatus.png", fnc=main)]
    if EXTMENU.value:
        l.append(PluginDescriptor(name=_("Oscam Ncam Status"), description=_("whats going on?"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="OscamStatus.png", fnc=main))
    return l

