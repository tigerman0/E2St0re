# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/IP_Checker/plugin.py
from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console

def main(session, **kwargs):
    import os
    if os.path.exists('/usr/lib/enigma2/python/Plugins/Extensions/IP_Checker/script/IP_Checker.sh'):
        os.chmod('/usr/lib/enigma2/python/Plugins/Extensions/IP_Checker/script/IP_Checker.sh', 420)
    session.open(Console, title='IP Checker', cmdlist=["sh '/usr/lib/enigma2/python/Plugins/Extensions/IP_Checker/script/IP_Checker.sh'"])


def Plugins(**kwargs):
    return [PluginDescriptor(name='IP Checker', description='Plugin to check the exteral IP adress of your box', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main, icon='plugin.png')]