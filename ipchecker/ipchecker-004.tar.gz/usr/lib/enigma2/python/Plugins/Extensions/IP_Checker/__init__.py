# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/IP_Checker/__init__.py
pass