echo
echo "LOCAL IP ADDRESS IS:"
echo
ip route get 8.8.8.8| grep src| sed 's/.*src \(.*\)$/\1/g'
echo
echo
echo
echo "EXTERNAL IP ADDRESS IS:"
echo
wget -qO- http://ipecho.net/plain;echo
echo
echo
echo
echo