from Screens.Screen import Screen
from Screens.Console import Console
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Plugins.Plugin import PluginDescriptor

from enigma import getDesktop
import os

DESKHEIGHT = getDesktop(0).size().height()
SKIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/Zoom/Skin/"

class SubMenu(Screen):
    def __init__(self, session, args = None):
        self.session = session
        skin_file = 'menuhd.xml' if DESKHEIGHT < 1000 else 'menufullhd.xml'
        skin = os.path.join(SKIN_PATH, skin_file)
        with open(skin, 'r') as f:
            self.skin = f.read()

        submenu_items = [
            (' (1) CLASSIC___(maybe slow, however all servers will be downloaded) ', 'com_1'),
            (' (2) SPEEDY___(fast,maybe some servers will not be downloaded) ', 'com_1_fast'),
        ]
        Screen.__init__(self, session)
        self['myMenu'] = MenuList(submenu_items)
        self['myActionMap'] = ActionMap(['SetupActions'], {'ok': self.go, 'cancel': self.cancel}, -1)

    def go(self):
        returnValue = self['myMenu'].l.getCurrentSelection()[1]
        if returnValue is not None:
            if returnValue == 'com_1':
                self.prompt('/bin/echo Downloading... ; /usr/script/server/tichestart1.sh')
            elif returnValue == 'com_1_fast':
                self.prompt('/bin/echo Downloading... ; /usr/script/server/tichestart2.sh')

    def prompt(self, com):
        self.session.open(Console, _('start shell com: %s') % com, ['%s' % com])

    def cancel(self):
        self.close(None)


class Zoom(Screen):
    def __init__(self, session, args = None):
        self.session = session
        skin_file = 'menuhd.xml' if DESKHEIGHT < 1000 else 'menufullhd.xml'
        skin = os.path.join(SKIN_PATH, skin_file)
        with open(skin, 'r') as f:
            self.skin = f.read()

        menu_items = [
            ('     (SERVERS)------------------------------------- ', 'separator'),
            (' (1) Download/Convert/Restart___ Servers ', 'com_1_submenu'),
            (' (2) Convert___/etc/CCCam.cfg --> /etc/tuxbox/config/OSCAM.server ', 'com_2'),
            (' (3) Restart___CAM ', 'com_3'),
            ('     (ADDONS)-------------------------------------- ', 'separator'),
            (' (1) Install___UltraCAM-Oscam + FIX ZOOM', 'com_5'),
            (' (2) Install___curl', 'com_6'),  # New item
            ('     (EXTRAS)--------------------------------------- ', 'separator'),
            (' (1) Uninstall___:( ', 'com_8'),
        ]
        Screen.__init__(self, session)
        self['myMenu'] = MenuList(menu_items)
        self['myActionMap'] = ActionMap(['SetupActions'], {'ok': self.go, 'cancel': self.cancel}, -1)

    def go(self):
        returnValue = self['myMenu'].l.getCurrentSelection()[1]
        if returnValue is not None and returnValue != 'separator':
            if returnValue == 'com_1_submenu':
                self.session.open(SubMenu)
            elif returnValue == 'com_2':
                self.prompt('/bin/echo Convert... ; /usr/script/server/conv.sh')
            elif returnValue == 'com_3':
                self.prompt('/bin/echo Restart... ; /usr/script/server/restart.sh')
            elif returnValue == 'com_5':
                self.prompt('/bin/echo installing... ; /usr/script/addons/cam.sh')
            elif returnValue == 'com_6':  # New command
                self.prompt('/bin/echo installing... ; /usr/script/addons/curl.sh')
            elif returnValue == 'com_8':
                self.prompt('opkg remove zoom && killall -9 enigma2 && exit')

    def prompt(self, com):
        self.session.open(Console, _('start shell com: %s') % com, ['%s' % com])

    def cancel(self):
        self.close(None)


def main(session, **kwargs):
    session.open(Zoom)


def Plugins(**kwargs):
    return [
        PluginDescriptor(name='Simple ZOOM Panel',
        description=_('Made from BextrH/E2Wizard/Zelda77 for You all.'),
        where=PluginDescriptor.WHERE_PLUGINMENU, icon='plugin.png', fnc=main),
    ]