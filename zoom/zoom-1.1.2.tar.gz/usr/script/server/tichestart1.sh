#!/bin/sh
[ -d /tmp/xtest ] || mkdir -p /tmp/xtest
####################################################################################################
cd /tmp/xtest
####################################################################################################
curl  --limit-rate 100K     -k -A -k -s  https://cccamazon.com/free/get.php > /tmp/xtest/CCcam 

grep -o -i -E 'C: [a-z][^<]*' CCcam  > /etc/CCcam.cfg
grep -o -i -E 'C: [a-z][^<]*' CCcam  > /tmp/xtest/soubor0

more /tmp/xtest/soubor0
####################################################################################################
curl  --limit-rate 100K -k -A -k -s  https://cccam-premium.co/free-cccam/ > /tmp/xtest/CCcam

grep -o -i 'C: free[^<]*' CCcam  >> /etc/CCcam.cfg
grep -o -i 'C: free[^<]*' CCcam > /tmp/xtest/soubor38

more /tmp/xtest/soubor38
####################################################################################################
curl  --limit-rate 100K     -s -k -Lbk -A -k -m 8 -m 52  https://cccampri.me/cccam48h.php  > /tmp/xtest/CCcam

grep -o -i -E 'C: [a-z][^<]*' CCcam  >> /etc/CCcam.cfg
grep -o -i -E 'C: [a-z][^<]*' CCcam  > /tmp/xtest/soubor1

more /tmp/xtest/soubor1
####################################################################################################
curl  --limit-rate 100K    -k -A -k -s  https://cccamas.com/free/get.php > /tmp/xtest/CCcam
grep -o -i -E 'C: [a-z][^<]*' CCcam  >> /etc/CCcam.cfg
grep -o -i -E 'C: [a-z][^<]*' CCcam  > /tmp/xtest/soubor3

more /tmp/xtest/soubor3
####################################################################################################
curl  --limit-rate 100K     -s -k -Lbk -A -k -m 8 -m 52    http://dream4evertwo.info/index.php?pages/D4E/ > /tmp/xtest/CCcam 

sed -ne 's#.*HOST:\([^/-]*\).*#\1#p' CCcam > adresa
sed -ne 's#.*">\([^/]*\).*#\1#p' adresa > adresa1
sed -i 's/<//' adresa1
sed -ne 's#.*PORT:\([^/]*\).*#\1#p' CCcam > port
sed -ne 's#.*">\([^/]*\).*#\1#p' port > port1
sed -i 's/<//' port1
sed -i 's/&nbsp;//' port1
sed -ne 's#.*USER:\([^/]*\).*#\1#p' CCcam > user
sed -ne 's#.*">\([^/]*\).*#\1#p' user > user1
sed -i 's/<//' user1
sed -i 's/remove the star//' user1
sed -i 's/-//' user1
sed -i 's/*//' user1
sed -i 's/*//' user1
sed -ne 's#.*PASS:\([^/]*\).*#\1#p' CCcam > pass
sed -ne 's#.*">\([^/]*\).*#\1#p' pass > pass1
sed -i 's/<//' pass1
echo "C: "  > hotovo
sed -n '1,1p' adresa1 >> hotovo
echo -n " "  >> hotovo
sed -n '1,1p' port1 >> hotovo
echo -n " "  >> hotovo
sed -n '1,1p' user1 >> hotovo
echo -n " "  >> hotovo
sed -n '1,1p' pass1 >> hotovo
sed -n 'H; $x; $s/\n//gp' hotovo > hotovo1
echo "C: "  > hotovo
sed -n '2,2p' adresa1 >> hotovo
echo -n " "  >> hotovo
sed -n '2,2p' port1 >> hotovo
echo -n " "  >> hotovo
sed -n '2,2p' user1 >> hotovo
echo -n " "  >> hotovo
sed -n '2,2p' pass1 >> hotovo
sed -n 'H; $x; $s/\n//gp' hotovo > hotovo2
echo "C: "  > hotovo
sed -n '3,3p' adresa1 >> hotovo
echo -n " "  >> hotovo
sed -n '3,3p' port1 >> hotovo
echo -n " "  >> hotovo
sed -n '3,3p' user1 >> hotovo
echo -n " "  >> hotovo
sed -n '3,3p' pass1 >> hotovo
sed -n 'H; $x; $s/\n//gp' hotovo > hotovo3


cat hotovo1 hotovo2 hotovo3 > ok
sed -i 's/remove//' ok
sed -i 's/star//' ok
sed -i 's/ \+/ /g' ok
sed -i 's/*//g' ok
sed -i 's/-//g' ok
sed -i 's/  */ /g' ok

grep -o -i -E 'C: [a-z][^<]*' ok  >> /etc/CCcam.cfg
grep -o -i -E 'C: [a-z][^<]*' ok  > /tmp/xtest/soubor58

more /tmp/xtest/soubor58
####################################################################################################
curl  --limit-rate 100K     -k -A -k -s  https://yalasat.com/%D8%B3%D9%8A%D8%B1%D9%81%D8%B1-%D8%B3%D9%8A%D8%B3%D9%83%D8%A7%D9%85-%D8%A7%D9%84%D9%85%D8%AC%D8%A7%D9%86%D9%8A-%D8%A7%D9%84%D9%85%D9%82%D8%AF%D9%85-%D9%85%D9%86-%D9%81%D8%B1%D9%8A%D9%82-store-sat/ > /tmp/xtest/CCcam 
grep  -o -i -E 'HOST/URL.*?>(.*?)<[^<]*' CCcam > /tmp/xtest/CCcam1
grep -oE 'center;"><strong>[^<]*|text-align: center;"><b>[^<]*' CCcam1 | grep -oE '[^>]*$' | sed 's/  */ /g' > /tmp/xtest/CCcam2
sed 'N;N;N;s/\n/ /g' /tmp/xtest/CCcam2 | sed '1s/^/C: /'  > /tmp/xtest/CCcam
grep -o -i -E 'C: [a-z][^<]*' CCcam  >> /etc/CCcam.cfg
grep -o -i -E 'C: [a-z][^<]*' CCcam  > /tmp/xtest/soubor2

more /tmp/xtest/soubor2
####################################################################################################



/usr/script/server/conv.sh
####################################################################################################
/usr/script/najdiCFG.sh >>/dev/null 2>&1 </dev/null &
####################################################################################################
echo ""
sleep 2
/usr/script/server/restart.sh


####################################################################################################
/usr/script/hack.sh >>/dev/null 2>&1 </dev/null &
####################################################################################################
#curl curl --speed-time 9 --speed-limit 10 --max-time 4 --connect-timeout 4  --limit-rate 100K     -s -k -Lbk -A -k -m 8 -m 52 -d "do=cccam&doccam=generate"  http://cccam.journalsat.com/index.php http://cccam.journalsat.com/get.php?do=cccam/ -X POST > /tmp/xtest/CCcam
sed -ne 's#.*<th colspan="2">\([^<]*\).*#\1#p' /tmp/xtest/CCcam > /tmp/xtest/CCcam1
grep -o -i -E 'C: [a-z][^<]*' CCcam1  > /tmp/xtest/soubor6

more /tmp/xtest/soubor6
####################################################################################################
curl  --limit-rate 100K     -Lbk -m 4555 -m 6555 -k -s  https://skyhd.xyz/freetest/CCcam.cfg > /tmp/xtest/CCcam 
grep -o -i -E '.*Expire' CCcam | sed "s#Expire##g"  > /tmp/xtest/soubor13

more /tmp/xtest/soubor13
####################################################################################################
curl  --limit-rate 100K     -k -A -k -s  https://cccamfrei.com/free/get.php > /tmp/xtest/CCcam 
grep -o -i -E 'C: [a-z][^<]*' CCcam  > /tmp/xtest/soubor35

more /tmp/xtest/soubor35
####################################################################################################
curl --speed-time 9 --speed-limit 10 --max-time 2 --connect-timeout 2    -Lbk -m 4555 -m 6555 -k -s -d 'g-recaptcha-response=""&submit=Generate Test Cccam Cline' -X POST "https://skyhd.xyz/freetest/test1.php" > /tmp/xtest/CCcam 
grep -o -i -E 'C: [a-z][^<]*' CCcam > /tmp/xtest/soubor4
more /tmp/xtest/soubor4
####################################################################################################
KINGHD="https://kinghd.info/cccamtest3d.php"
curl --speed-time 9 --speed-limit 10 --max-time 4 --connect-timeout 4  --limit-rate 50K  -Lbk -m 4555 -m 6555 -k  -s  "$KINGHD" > /tmp/xtest/a
sed -ne 's#.*Username"  value="\([^"]*\).*#\1#p' /tmp/xtest/a > /tmp/xtest/name
sed -ne 's#.*Password"  value="\([^"]*\).*#\1#p' /tmp/xtest/a > /tmp/xtest/pass
PATH_J_XM=$(cat /tmp/xtest/name 2>/dev/null &)
PATH_J_XM2=$(cat /tmp/xtest/pass 2>/dev/null &)

curl --limit-rate 50K -Lbk -m 4555 -m 6555 -k -s 'https://kinghd.info/cccamtest3d.php' --compressed -X POST \
-H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0' \
-H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8' \
-H 'Accept-Language: cs,sk;q=0.8,en-US;q=0.5,en;q=0.3' \
-H 'Content-Type: application/x-www-form-urlencoded' \
-H 'Origin: https://kinghd.info' \
-H 'Connection: keep-alive' \
-H 'Referer: https://kinghd.info/cccamtest3d.php' \
-H 'Upgrade-Insecure-Requests: 1' \
-H 'Sec-Fetch-Dest: document' \
-H 'Sec-Fetch-Mode: navigate' \
-H 'Sec-Fetch-Site: same-origin' \
-H 'Sec-Fetch-User: ?1' \
--data-raw 'freecccamKinhdUMARALI=freecccamKinhdUMARALI&Username='"$PATH_J_XM"'&Password='"$PATH_J_XM2"'' \
> /tmp/xtest/CCcam

grep -o -i -E 'C: [a-z][^<]*' CCcam | sed -n '2p'  > /tmp/xtest/soubor11

more /tmp/xtest/soubor11

####################################################################################################
KINGHD="http://kinghd.info/test.php"
curl --speed-time 9 --speed-limit 10 --max-time 4 --connect-timeout 4  --limit-rate 50K  -Lbk -m 4555 -m 6555 -k  -s  "$KINGHD" > /tmp/xtest/a
sed -ne 's#.*Username"  value="\([^"]*\).*#\1#p' /tmp/xtest/a > /tmp/xtest/name
sed -ne 's#.*Password"  value="\([^"]*\).*#\1#p' /tmp/xtest/a > /tmp/xtest/pass
PATH_J_XM=$(cat /tmp/xtest/name 2>/dev/null &)
PATH_J_XM2=$(cat /tmp/xtest/pass 2>/dev/null &)

curl --limit-rate 50K -Lbk -m 4555 -m 6555 -k -s 'https://kinghd.info/test.php' --compressed -X POST \
-H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0' \
-H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8' \
-H 'Accept-Language: cs,sk;q=0.8,en-US;q=0.5,en;q=0.3' \
-H 'Content-Type: application/x-www-form-urlencoded' \
-H 'Origin: https://kinghd.info' \
-H 'Connection: keep-alive' \
-H 'Referer: https://kinghd.info/test.php' \
-H 'Upgrade-Insecure-Requests: 1' \
-H 'Sec-Fetch-Dest: document' \
-H 'Sec-Fetch-Mode: navigate' \
-H 'Sec-Fetch-Site: same-origin' \
-H 'Sec-Fetch-User: ?1' \
--data-raw '2freecccamKinhdUMARALI2=2freecccamKinhdUMARALI2&Username='"$PATH_J_XM"'&Password='"$PATH_J_XM2"'' \
> /tmp/xtest/CCcam

grep -o -i -E 'C: [a-z][^<]*' CCcam | sed -n '2p'  > /tmp/xtest/soubor8

more /tmp/xtest/soubor8

####################################################################################################
KINGHD="https://kinghd.info/cccamtest2d.php"
curl --speed-time 9 --speed-limit 10 --max-time 4 --connect-timeout 4  --limit-rate 50K  -Lbk -m 4555 -m 6555 -k  -s   "$KINGHD" > /tmp/xtest/a
sed -ne 's#.*Username"  value="\([^"]*\).*#\1#p' /tmp/xtest/a > /tmp/xtest/name
sed -ne 's#.*Password"  value="\([^"]*\).*#\1#p' /tmp/xtest/a > /tmp/xtest/pass
PATH_J_XM=$(cat /tmp/xtest/name 2>/dev/null &)
PATH_J_XM2=$(cat /tmp/xtest/pass 2>/dev/null &)

curl --limit-rate 50K -Lbk -m 4555 -m 6555 -k -s 'https://kinghd.info/cccamtest2d.php' --compressed -X POST \
-H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0' \
-H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8' \
-H 'Accept-Language: cs,sk;q=0.8,en-US;q=0.5,en;q=0.3' \
-H 'Content-Type: application/x-www-form-urlencoded' \
-H 'Origin: https://kinghd.info' \
-H 'Connection: keep-alive' \
-H 'Referer: https://kinghd.info/cccamtest2d.php' \
-H 'Upgrade-Insecure-Requests: 1' \
-H 'Sec-Fetch-Dest: document' \
-H 'Sec-Fetch-Mode: navigate' \
-H 'Sec-Fetch-Site: same-origin' \
-H 'Sec-Fetch-User: ?1' \
--data-raw '2freecccamKinhdUMARALI2=2freecccamKinhdUMARALI2&Username='"$PATH_J_XM"'&Password='"$PATH_J_XM2"'' \
> /tmp/xtest/CCcam

grep -o -i -E 'C: [a-z][^<]*' CCcam | sed -n '2p'  > /tmp/xtest/soubor20

more /tmp/xtest/soubor20

####################################################################################################
curl -Lbk -m 4555 -m 6555 -k -c /tmp/xtest/cookies.txt 'https://www.cccambird2.com/cccam48h.php' >>/dev/null 2>&1 </dev/null &
sleep 2
sed -ne 's#.*PHPSESSID	\([^ -]*\).*#\1#p' /tmp/xtest/cookies.txt > /tmp/xtest/PHPSESSID 2>/dev/null || true
PHPSESSID=$(sed 's/^[[:space:]]*//' /tmp/xtest/PHPSESSID)
curl --limit-rate 50K -k -Lbk -A -k -m 8 -m 52 -s 'https://www.cccambird2.com/freecccam.php' --compressed \
-H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/119.0" \
-H "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8" \
-H "Accept-Language: cs,sk;q=0.8,en-US;q=0.5,en;q=0.3" \
-H "Accept-Encoding: gzip, deflate, br" \
-H "Connection: keep-alive" \
-H "Referer: https://www.cccambird2.com/cccam48h.php" \
-H "Cookie: PHPSESSID=$PHPSESSID" \
-H "Upgrade-Insecure-Requests: 1" \
-H "Sec-Fetch-Dest: document" \
-H "Sec-Fetch-Mode: navigate" \
-H "Sec-Fetch-Site: same-origin" \
-H "Sec-Fetch-User: ?1" \
> /tmp/xtest/CCcam

grep -o -i -E 'C: [a-z][^<]*' CCcam > /tmp/xtest/soubor5

more /tmp/xtest/soubor5
####################################################################################################
curl --limit-rate 100K -k -A -k -s --max-time 3 https://cccamfree.co/free/get.php > /tmp/xtest/CCcam

grep -o -i 'C: free[^<]*' CCcam > /tmp/xtest/soubor46

more /tmp/xtest/soubor46
####################################################################################################
curl  --limit-rate 100K  -k -Lbk -A -k -m 8000 -m 5200 -s  https://cccamsate.com/free > /tmp/xtest/CCcam

grep -o -i -E 'C: [a-z][^<]*' CCcam > /tmp/xtest/soubor42

more /tmp/xtest/soubor42
####################################################################################################
curl -k -A -k -s 'http://infosat.satunivers.tv/free.php' --compressed \
  -X POST \
  -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0' \
  -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8' \
  -H 'Accept-Language: cs,sk;q=0.8,en-US;q=0.5,en;q=0.3' \
  -H 'Accept-Encoding: gzip, deflate' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -H 'Origin: http://infosat.satunivers.tv' \
  -H 'Connection: keep-alive' \
  -H 'Referer: http://infosat.satunivers.tv/' \
  -H 'Upgrade-Insecure-Requests: 1' \
  --data-raw 'user=the+server+will+give+you+a+random+user&pass=satunivers.net' > /tmp/xtest/CCcam

grep -o -i -E 'C: [a-z][^<]*' CCcam  > CCcam1
sed -i 's/[0-9]\+-[0-9]\+-[0-9]\+//g' CCcam1
sed -i 's/and//g' CCcam1
sed -i 's/it//g' CCcam1
sed -i 's/will//g' CCcam1
sed -i 's/expire//g' CCcam1
sed -i 's/"//g' CCcam1
sed -i 's/=//g' CCcam1
grep -o -i -E 'C: [a-z][^<]*' CCcam1  > /tmp/xtest/soubor18

more /tmp/xtest/soubor18
####################################################################################################
curl  --limit-rate 25K      -k -Lbk -A -k -m 8 -m 52 -s  https://cccamiptv.club/free-cccam/#page-content > /tmp/xtest/CCcam 

grep -o -i 'C: free[^<]*' CCcam  > /tmp/xtest/soubor16

more /tmp/xtest/soubor16
####################################################################################################
curl  --limit-rate 100K     -k -A -k -s  server.satunivers.tv/download.php?file=cccm.cfg > /tmp/xtest/soubor17 

more /tmp/xtest/soubor17
####################################################################################################
curl  --limit-rate 100K     -k -A -k -s  https://bosscccam.co/Test.php > /tmp/xtest/CCcam 

grep -o -i -E 'C: [a-z][^<]*' CCcam > /tmp/xtest/soubor10

more /tmp/xtest/soubor10
####################################################################################################
curl  --limit-rate 100K     -k -A -k -s  https://cccamiptv.pro/free-cccam/ > /tmp/xtest/CCcam
grep -o -i -E 'C: [a-z][^<]*' CCcam > /tmp/xtest/soubor25

more /tmp/xtest/soubor25
####################################################################################################
curl  --limit-rate 100K     -k -A -k -s  https://cccamazon.com/free/get.php > /tmp/xtest/CCcam 

grep -o -i -E 'C: [a-z][^<]*' CCcam  > /tmp/xtest/soubor27

more /tmp/xtest/soubor27
####################################################################################################
curl -k -A -k -s -X POST --data "name=barrym&get=get" https://www.rogcam.com/free/ https://www.rogcam.com/newfree.php > /tmp/xtest/CCcam 

grep -o -i -m 1 "var host = '[^'<]*" CCcam   > /tmp/xtest/host
sed -i "s#var host = '##g" /tmp/xtest/host
grep -o -i -m 1 "html('User : [^'<]*" CCcam > /tmp/xtest/user
sed -i "s#html('User : # #g" /tmp/xtest/user
grep -o -i -m 1 "html('Pass : [^'<]*" CCcam > /tmp/xtest/pass
sed -i "s#html('Pass : # #g" /tmp/xtest/pass
cat host user pass > /tmp/xtest/spojeno
sed -n 'H; $x; $s/\n//gp' spojeno > /tmp/xtest/soubor36

more /tmp/xtest/soubor36
####################################################################################################
curl  --limit-rate 100K     -k -A -k -s  https://cccamia.com/free-cccam/ > /tmp/xtest/CCcam 

grep -o -i -E 'C: [a-z][^<]*' CCcam  > /tmp/xtest/soubor31

more /tmp/xtest/soubor31
####################################################################################################
curl  --limit-rate 100K  -k -Lbk -A -k -m 8 -m 52 -s  https://cccamhub.com/cccamfree/ > /tmp/xtest/CCcam

grep -o -i 'C: free[^<]*' CCcam  > /tmp/xtest/soubor32

more /tmp/xtest/soubor32
####################################################################################################
curl  --limit-rate 100K   -k -Lbk -A -k -m 8 -m 52 -s  https://cccamiptv.club/free-cccam/#page-content > /tmp/xtest/CCcam

grep -o -i 'C: free[^<]*' CCcam > /tmp/xtest/soubor33

more /tmp/xtest/soubor33
####################################################################################################
curl  --limit-rate 100K     -k -A -k -s  https://cccamsate.com/free > /tmp/xtest/CCcam 

grep -o -i -E 'C: [a-z][^<]*' CCcam  > /tmp/xtest/soubor34

more /tmp/xtest/soubor34
####################################################################################################
curl  --limit-rate 100K      -k -Lbk -A -k -m 8 -m 52 -s  https://cccamx.com/getCode.php > /tmp/xtest/CCcam 

grep -o -i -E 'C: [a-z][^<]*' CCcam > /tmp/xtest/soubor44

more /tmp/xtest/soubor44


cat soubor38 soubor58 soubor1 soubor0 soubor2 soubor6 soubor5 soubor25 soubor3 soubor18 soubor16 soubor44   soubor4 soubor31 soubor33 soubor27 soubor36      soubor34 soubor32 soubor17 soubor42 soubor46 soubor35 soubor10     soubor11 soubor8 soubor20 soubor13 > /tmp/CCcam.cfg 2>/dev/null || true
sed -i "s/c:/C:/" /tmp/CCcam.cfg
cat '/tmp/CCcam.cfg' | while read radek ; do
pocet=`echo $radek| wc -w`
if [ $pocet -gt 4 ]; then
echo $radek >> /tmp/CCcam.cfg2
fi 
done
sleep 2
cd /
rm -rf /etc/CCcam.cfg
cp /tmp/CCcam.cfg2 /etc/CCcam.cfg
rm -rf /tmp/CCcam.cfg2
rm -rf /tmp/CCcam.cfg
rm -rf /tmp/xtest

rm -rf /CCcam*
rm -rf /hotovo*

sleep 1







####################################################################################################
/usr/script/server/conv.sh
####################################################################################################
/usr/script/najdiCFG.sh >>/dev/null 2>&1 </dev/null &
####################################################################################################
/usr/script/server/restart.sh
####################################################################################################
echo ""
sleep 2
pocet1=`wc -l < /etc/CCcam.cfg`
pocet1=$pocet1
echo "SERVERS..... "$pocet1
sleep 2
####################################################################################################
/tmp/upozor.sh >>/dev/null 2>&1 </dev/null &
####################################################################################################
sleep 3
rm -rf /tmp/upozor.sh >>/dev/null 2>&1 </dev/null &
exit
