#!/bin/sh

cd /tmp

curl -k -L -o enigma2-plugin-softcams-ultracam-oscam_11734-emu-r799_all.ipk "https://github.com/MOHAMED19OS/Enigma2_Store/raw/main/Cam_Emulator/enigma2-plugin-softcams-ultracam-oscam_11734-emu-r799_all.ipk"

opkg install enigma2-plugin-softcams-ultracam-oscam_11734-emu-r799_all.ipk

CONFIG_DIR="/etc/tuxbox/config"
CONFIG_DIR_OLD="/etc/tuxbox/config_old"

if [ -d "$CONFIG_DIR" ]; then
    if [ -d "$CONFIG_DIR_OLD" ]; then
        rm -rf "$CONFIG_DIR_OLD"
    fi
    mv "$CONFIG_DIR" "$CONFIG_DIR_OLD"
fi

src="/usr/script/ZOOM_CAM/config"
dst="/etc/tuxbox/"

cp -r "$src" "$dst"

exit 0
