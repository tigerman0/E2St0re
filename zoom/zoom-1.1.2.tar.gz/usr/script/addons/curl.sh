#!/bin/sh
echo "Installing curl..."
opkg update
opkg install curl