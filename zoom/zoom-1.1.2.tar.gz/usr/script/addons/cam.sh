#!/bin/sh
echo "Instaling OSCAM_ULTRACAM"
sleep 1
echo "Only for ALL!!"
cd /tmp
/usr/script/ZOOM_CAM/install.sh
sleep 1
echo "instaling Oscam-Ultracam...."
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/enigma2-plugin-softcams-ultracam-oscam_11734-emu-r799_all.ipk
sleep 2
killall -9 enigma2
exit
