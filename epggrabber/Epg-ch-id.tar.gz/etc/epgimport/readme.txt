XMLTV Importer

This software is released under the GPLv2 license.

Providers should check out the .xml files in the /etc/epgimport
directory for information on creating your own source.

Users need not read this, just configure it from the plugins.

Special thanks go to:

'rytec' for providing the XMLTV data
'oudeis' and 'arnoldd' for the initial plugin
'Panagiotis Malakoudis' for his tips for UTF-8
The PLi team for putting up with me
All the sat4all.com folks who contributed

