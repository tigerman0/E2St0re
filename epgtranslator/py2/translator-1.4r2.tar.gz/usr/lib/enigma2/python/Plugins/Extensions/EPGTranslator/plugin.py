from Components.ActionMap import ActionMap, NumberActionMap
from Components.config import config, configfile, ConfigSubsection, ConfigSelection, ConfigInteger, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Components.Input import Input
from Components.Label import Label
from Components.Language import language
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from Components.Pixmap import Pixmap, MovingPixmap
from Components.ScrollLabel import ScrollLabel
from Components.Slider import Slider
from enigma import eConsoleAppContainer, eListboxPythonMultiContent, eTimer, eEPGCache, eServiceReference, getDesktop, gFont, loadPic, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_WRAP
from Plugins.Plugin import PluginDescriptor
from re import findall, match, search, split, sub
from Screens.EventView import EventViewBase
from Screens.EpgSelection import EPGSelection
from Screens.InfoBar import InfoBar, MoviePlayer
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Screens.VirtualKeyBoard import VirtualKeyBoard
from string import find
from Tools.Directories import fileExists
from twisted.web import client, error
from twisted.web.client import getPage, downloadPage
import os, re, socket, sys, time, urllib
from os import path
from urllib import unquote_plus, quote
from urllib2 import Request, urlopen, URLError, HTTPError
from urlparse import parse_qs

screenwidth = getDesktop(0).size()

config.plugins.translator = ConfigSubsection()

config.plugins.translator.source = ConfigSelection(default='auto', choices=[
 ('auto', _('Detect Language')),
 ('af', _('Afrikaans')),
 ('sq', _('Albanian')),
 ('ar', _('Arabic')),
 ('az', _('Azerbaijani')),
 ('eu', _('Basque')),
 ('be', _('Belarusian')),
 ('bs', _('Bosnian')),
 ('bg', _('Bulgarian')),
 ('ca', _('Catalan')),
 ('ceb', _('Cebuano')),
 ('hr', _('Croatian')),
 ('cs', _('Czech')),
 ('da', _('Danish')),
 ('nl', _('Dutch')),
 ('en', _('English')),
 ('et', _('Estonian')),
 ('tl', _('Filipino')),
 ('fi', _('Finnish')),
 ('fr', _('French')),
 ('gl', _('Galician')),
 ('de', _('German')),
 ('el', _('Greek')),
 ('ht', _('Haitian Creole')),
 ('hu', _('Hungarian')),
 ('is', _('Icelandic')),
 ('id', _('Indonesian')),
 ('ga', _('Irish')),
 ('it', _('Italian')),
 ('jw', _('Javanese')),
 ('lv', _('Latvian')),
 ('lt', _('Lithuanian')),
 ('mk', _('Macedonian')),
 ('ms', _('Malay')),
 ('mt', _('Maltese')),
 ('no', _('Norwegian')),
 ('fa', _('Persian')),
 ('pl', _('Polish')),
 ('pt', _('Portuguese')),
 ('ro', _('Romanian')),
 ('ru', _('Russian')),
 ('sr', _('Serbian')),
 ('sk', _('Slovak')),
 ('sl', _('Slovenian')),
 ('es', _('Spanish')),
 ('sw', _('Swahili')),
 ('sv', _('Swedish')),
 ('tr', _('Turkish')),
 ('uk', _('Ukrainian')),
 ('ur', _('Urdu')),
 ('vi', _('Vietnamese')),
 ('cy', _('Welsh'))
 ])
 
config.plugins.translator.destination = ConfigSelection(default='en', choices=[
 ('af', _('Afrikaans')),
 ('sq', _('Albanian')),
 ('ar', _('Arabic')),
 ('az', _('Azerbaijani')),
 ('eu', _('Basque')),
 ('be', _('Belarusian')),
 ('bs', _('Bosnian')),
 ('bg', _('Bulgarian')),
 ('ca', _('Catalan')),
 ('ceb', _('Cebuano')),
 ('hr', _('Croatian')),
 ('cs', _('Czech')),
 ('da', _('Danish')),
 ('nl', _('Dutch')),
 ('en', _('English')),
 ('et', _('Estonian')),
 ('tl', _('Filipino')),
 ('fi', _('Finnish')),
 ('fr', _('French')),
 ('gl', _('Galician')),
 ('de', _('German')),
 ('el', _('Greek')),
 ('ht', _('Haitian Creole')),
 ('hu', _('Hungarian')),
 ('is', _('Icelandic')),
 ('id', _('Indonesian')),
 ('ga', _('Irish')),
 ('it', _('Italian')),
 ('jw', _('Javanese')),
 ('lv', _('Latvian')),
 ('lt', _('Lithuanian')),
 ('mk', _('Macedonian')),
 ('ms', _('Malay')),
 ('mt', _('Maltese')),
 ('no', _('Norwegian')),
 ('fa', _('Persian')),
 ('pl', _('Polish')),
 ('pt', _('Portuguese')),
 ('ro', _('Romanian')),
 ('ru', _('Russian')),
 ('sr', _('Serbian')),
 ('sk', _('Slovak')),
 ('sl', _('Slovenian')),
 ('es', _('Spanish')),
 ('sw', _('Swahili')),
 ('sv', _('Swedish')),
 ('tr', _('Turkish')),
 ('uk', _('Ukrainian')),
 ('ur', _('Urdu')),
 ('vi', _('Vietnamese')),
 ('cy', _('Welsh'))
 ])
 
config.plugins.translator.maxevents = ConfigInteger(20, (2, 999))
config.plugins.translator.showsource = ConfigSelection(default='yes', choices=[('yes', _('Yes')), ('no', _('No'))])

    
config.plugins.translator.color = ConfigSelection(default='0x00000000', choices=[
 ('0x00000000', _('Skin Default')),
 ('0x00F0A30A', _('Amber')),
 ('0x007895BC', _('Blue')),
 ('0x00825A2C', _('Brown')),
 ('0x000050EF', _('Cobalt')),
 ('0x00911D10', _('Crimson')),
 ('0x001BA1E2', _('Cyan')),
 ('0x00008A00', _('Emerald')),
 ('0x0070AD11', _('Green')),
 ('0x006A00FF', _('Indigo')),
 ('0x00BB0048', _('Magenta')),
 ('0x0076608A', _('Mauve')),
 ('0x006D8764', _('Olive')),
 ('0x00C3461B', _('Orange')),
 ('0x00F472D0', _('Pink')),
 ('0x00E51400', _('Red')),
 ('0x007A3B3F', _('Sienna')),
 ('0x00647687', _('Steel')),
 ('0x00149BAF', _('Teal')),
 ('0x004176B6', _('Tufts')),
 ('0x006C0AAB', _('Violet')),
 ('0x00BF9217', _('Yellow'))
 ])

def applySkinVars(skin, dict):
    for key in dict.keys():
        try:
            skin = skin.replace('{' + key + '}', dict[key])
        except Exception as e:
            print e, '@key=', key

    return skin


def transHTML(text):
    text = text.replace('&nbsp;', ' ').replace('&szlig;', 'ss').replace('&quot;', '"').replace('&ndash;', '-').replace('&Oslash;', '').replace('&bdquo;', '"').replace('&ldquo;', '"').replace('&rsquo;', "'").replace('&gt;', '>').replace('&lt;', '<').replace('&shy;', '').replace('&copy;.*', ' ').replace('&amp;', '&').replace('&eacute;', '\xc3\xa9').replace('&hellip;', '...').replace('&egrave;', '\xc3\xa8').replace('&agrave;', '\xc3\xa0')
    text = text.replace('&#034;', '"').replace('&#039;', "'").replace('&#34;', '"').replace('&#38;', 'und').replace('&#39;', "'").replace('&#133;', '...')
    text = text.replace('\xc3\x83 \xe2\x80\x9e ', '\xc3\x84').replace('\xc3\x83 - ', '\xc3\x96').replace('\xc3\x83 \xc5\x93 ', '\xc3\x9c').replace('\xc3\x83 \xc5\xb8 ', '\xc3\x9f').replace('\xc3\x83 \xc2\xa4 ', '\xc3\xa4').replace('\xc3\x83 \xc2\xb6 ', '\xc3\xb6').replace('\xc3\x83 \xc2\xbc ', '\xc3\xbc')
    text = text.replace('\xc3\x83 \xe2\x80\x9e', '\xc3\x84').replace('\xc3\x83 -', '\xc3\x96').replace('\xc3\x83 \xc5\x93', '\xc3\x9c').replace('\xc3\x83 \xc5\xb8', '\xc3\x9f').replace('\xc3\x83 \xc2\xa4', '\xc3\xa4').replace('\xc3\x83 \xc2\xb6', '\xc3\xb6').replace('\xc3\x83 \xc2\xbc', '\xc3\xbc')
    text = text.replace('\xc3\x83\xe2\x80\x9e', '\xc3\x84').replace('\xc3\x83\xe2\x80\x93', '\xc3\x96').replace('\xc3\x83\xc5\x93', '\xc3\x9c').replace('\xc3\x83\xc5\xb8', '\xc3\x9f').replace('\xc3\x83\xc2\xa4', '\xc3\xa4').replace('\xc3\x83\xc2\xb6', '\xc3\xb6').replace('\xc3\x83\xc2\xbc', '\xc3\xbc').replace('\xc3\x82\xc5\xa0', '\n').replace('\xc3\x82', '\n').replace('\xc3\x83 ', '').replace('AS', '').replace('\xc2\xb6 ', '').replace('\xc2\xb6', '').replace('\xc2\xbc ', '').replace('\xc2\xbc', '').replace('\xc2\xa4 ', '').replace('\xc2\xa4', '')
    return text


class translatorConfig(ConfigListScreen, Screen):
    skin = """
    <screen position="center,center" size="545,525" backgroundColor="#20000000" title="EPG Translator Setup">
        <ePixmap position="0,0" size="545,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/translatorConfig.png" alphatest="blend" zPosition="1" />
        <ePixmap position="10,59" size="525,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/seperator.png" alphatest="off" zPosition="1" />
        <widget name="config" position="10,60" size="525,125" itemHeight="25" scrollbarMode="showOnDemand" font="Regular;18" secondfont="Regular;18" zPosition="1" />
        <ePixmap position="10,186" size="525,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/seperator.png" alphatest="off" zPosition="1" />
        <ePixmap position="125,196" size="18,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/green.png" alphatest="blend" zPosition="1" />
        <ePixmap position="350,196" size="18,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/red.png" alphatest="blend" zPosition="1" />
        <eLabel position="150,195" size="180,20" font="Regular;18" halign="left" text="Save" transparent="1" zPosition="1" />
        <eLabel position="375,195" size="180,20" font="Regular;18" halign="left" text="Cancel" transparent="1" zPosition="1" />
        <widget name="flag" position="128,225" size="288,288" alphatest="blend" zPosition="1" />
    </screen>
    """
    
    if screenwidth.width() > 1280:
        skin = """
        <screen position="center,center" size="818,788" backgroundColor="#20000000" title="EPG Translator Setup">
            <ePixmap position="0,0" size="818,75" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/fhd-translatorConfig.png" alphatest="blend" zPosition="1" />
            <ePixmap position="15,89" size="788,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/seperator.png" alphatest="off" zPosition="1" />
            <widget name="config" position="15,90" size="788,188" itemHeight="38" scrollbarMode="showOnDemand" font="Regular;27" secondfont="Regular;27" zPosition="1" />
            <ePixmap position="15,279" size="788,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/seperator.png" alphatest="off" zPosition="1" />
            <ePixmap position="188,294" size="27,27" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/fhd-green.png" alphatest="blend" zPosition="1" />
            <ePixmap position="525,294" size="27,27" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/fhd-red.png" alphatest="blend" zPosition="1" />
            <eLabel position="225,293" size="270,30" font="Regular;27" halign="left" text="Save" transparent="1" zPosition="1" />
            <eLabel position="563,293" size="270,30" font="Regular;27" halign="left" text="Cancel" transparent="1" zPosition="1" />
            <widget name="flag" position="264,410" size="288,288" alphatest="blend" zPosition="1" />
        </screen>
        """
   
    def __init__(self, session):
        Screen.__init__(self, session)
        self['flag'] = Pixmap()
        list = []
        list.append(getConfigListEntry(_('Source Language:'), config.plugins.translator.source))
        list.append(getConfigListEntry(_('Destination Language:'), config.plugins.translator.destination))
        list.append(getConfigListEntry(_('Maximum EPG Events:'), config.plugins.translator.maxevents))
        list.append(getConfigListEntry(_('Show Source EPG:'), config.plugins.translator.showsource))
       
        ConfigListScreen.__init__(self, list, on_change=self.UpdateComponents)
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'ok': self.save,
         'cancel': self.cancel,
         'red': self.cancel,
         'green': self.save}, -1)
        self.onLayoutFinish.append(self.UpdateComponents)

    def UpdateComponents(self):
        png = '/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/flag/' + str(config.plugins.translator.destination.value) + '.png'
        if fileExists(png):
            self['flag'].instance.setPixmapFromFile(png)
        current = self['config'].getCurrent()
        

    def save(self):
        for x in self['config'].list:
            x[1].save()
            configfile.save()

        self.exit()

    def cancel(self):
        for x in self['config'].list:
            x[1].cancel()

        self.exit()

    def exit(self):
        self.session.openWithCallback(self.close, translatorMain, None)
        return


class youtubeConfig(ConfigListScreen, Screen):
    skin = """
    <screen position="center,center" size="400,145" backgroundColor="#000000" title="EPG YouTube Trailer Setup">
        <ePixmap position="0,0" size="400,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/youtubeConfig.png" alphatest="blend" zPosition="1" />
        <widget name="config" position="10,60" size="380,50" itemHeight="25" scrollbarMode="showNever" font="Regular;18" secondfont="Regular;18" zPosition="1" />
        <ePixmap position="45,120" size="18,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/green.png" alphatest="blend" zPosition="1" />
        <ePixmap position="280,120" size="18,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/red.png" alphatest="blend" zPosition="1" />
        <eLabel position="70,119" size="80,20" font="Regular;18" halign="left" text="Save" transparent="1" zPosition="1" />
        <eLabel position="305,119" size="80,20" font="Regular;18" halign="left" text="Cancel" transparent="1" zPosition="1" />
    </screen>   
    """
    
    if screenwidth.width() > 1280:
        skin = """
        <screen position="center,center" size="600,218" backgroundColor="#000000" title="EPG YouTube Trailer Setup">
            <ePixmap position="0,0" size="600,75" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/fhd-youtubeConfig.png" alphatest="blend" zPosition="1" />
            <widget name="config" position="15,90" size="570,75" itemHeight="38" scrollbarMode="showNever" font="Regular;27" secondfont="Regular;27" zPosition="1" />
            <ePixmap position="68,180" size="27,27" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/fhd-green.png" alphatest="blend" zPosition="1" />
            <ePixmap position="420,180" size="27,27" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/fhd-red.png" alphatest="blend" zPosition="1" />
            <eLabel position="105,179" size="120,30" font="Regular;27" halign="left" text="Save" transparent="1" zPosition="1" />
            <eLabel position="458,179" size="120,30" font="Regular;27" halign="left" text="Cancel" transparent="1" zPosition="1" />
        </screen>
        
        """
        
    def __init__(self, session):
        Screen.__init__(self, session)
        self['flag'] = Pixmap()
        list = []
        list.append(getConfigListEntry('YouTube Color Selection:', config.plugins.translator.color))
        ConfigListScreen.__init__(self, list)
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {
         'ok': self.save,
         'cancel': self.cancel,
         'red': self.cancel,
         'green': self.save}, -1)

    def save(self):
        for x in self['config'].list:
            x[1].save()
            configfile.save()

        self.exit()

    def cancel(self):
        for x in self['config'].list:
            x[1].cancel()

        self.exit()

    def exit(self):
        self.session.openWithCallback(self.close, YouTubeMain)


class infoTranslator(Screen):
    skin = """
    <screen position="center,center" size="425,425" title=" " >
        <ePixmap position="0,0" size="425,425" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/info.png" zPosition="1"/>
     </screen>
    """
    
    if screenwidth.width() > 1280:
        skin = """
        <screen position="center,center" size="638,638" title=" " >
            <ePixmap position="0,0" size="638,638" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/fhd-info.png" zPosition="1"/>
          </screen>
        
        """
        
   
    def __init__(self, session, check):
        self.skin = infoTranslator.skin
        Screen.__init__(self, session)
      
        self['actions'] = ActionMap(['OkCancelActions'], {'ok': self.close,
         'cancel': self.close}, -1)
        self.version = '1.1rc1'

        self.setTitle('EPG YouTube & Translator %s' % self.version)
        
        




    def download(self, link, name):
        getPage(link).addCallback(name).addErrback(self.downloadError)

    def downloadError(self, output):
        pass


class searchYouTube(Screen):
    skin = """
    <screen position="center,80" size="1000,560" title=" ">
        <ePixmap position="0,0" size="1000,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/youtube.png" alphatest="blend" zPosition="1" />
        <ePixmap position="10,6" size="18,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/blue.png" alphatest="blend" zPosition="2" />
        <ePixmap position="10,26" size="18,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/yellow.png" alphatest="blend" zPosition="2" />
        <widget name="label" position="34,6" size="200,20" font="Regular;16" foregroundColor="#697178" backgroundColor="#FFFFFF" halign="left" transparent="1" zPosition="2" />
        <widget name="label2" position="34,26" size="200,20" font="Regular;16" foregroundColor="#697178" backgroundColor="#FFFFFF" halign="left" transparent="1" zPosition="2" />
        <widget render="Label" source="global.CurrentTime" position="740,0" size="240,50" font="Regular;24" foregroundColor="#697279" backgroundColor="#FFFFFF" halign="right" valign="center" zPosition="2">
        <convert type="ClockToText">Format:%H:%M:%S</convert>
        </widget>
        <widget name="poster1" position="10,55" size="215,120" alphatest="blend" zPosition="1" />
        <widget name="poster2" position="10,180" size="215,120" alphatest="blend" zPosition="1" />
        <widget name="poster3" position="10,305" size="215,120" alphatest="blend" zPosition="1" />
        <widget name="poster4" position="10,430" size="215,120" alphatest="blend" zPosition="1" />
        <widget name="list" position="235,55" size="755,500" scrollbarMode="showOnDemand" zPosition="1" />
    </screen>
    """
    
    if screenwidth.width() > 1280:
        skin = """
        <screen position="center,120" size="1500,840" title=" ">
            <ePixmap position="0,0" size="1500,75" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/fhd-youtube.png" alphatest="blend" zPosition="1" />
            <ePixmap position="15,9" size="27,27" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/fhd-blue.png" alphatest="blend" zPosition="2" />
            <ePixmap position="15,39" size="27,27" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/fhd-yellow.png" alphatest="blend" zPosition="2" />
            <widget name="label" position="51,9" size="300,30" font="Regular;24" foregroundColor="#697178" backgroundColor="#FFFFFF" halign="left" transparent="1" zPosition="2" />
            <widget name="label2" position="51,39" size="300,30" font="Regular;24" foregroundColor="#697178" backgroundColor="#FFFFFF" halign="left" transparent="1" zPosition="2" />
            <widget render="Label" source="global.CurrentTime" position="1110,0" size="360,75" font="Regular;36" foregroundColor="#697279" backgroundColor="#FFFFFF" halign="right" valign="center" zPosition="2">
            <convert type="ClockToText">Format:%H:%M:%S</convert>
            </widget>
            <widget name="poster1" position="15,83" size="323,180" alphatest="blend" zPosition="1" />
            <widget name="poster2" position="15,270" size="323,180" alphatest="blend" zPosition="1" />
            <widget name="poster3" position="15,458" size="323,180" alphatest="blend" zPosition="1" />
            <widget name="poster4" position="15,645" size="323,180" alphatest="blend" zPosition="1" />
            <widget name="list" position="353,83" size="1133,752" scrollbarMode="showOnDemand" zPosition="1" />
        </screen>
        
        """
    
    def __init__(self, session, name):
        Screen.__init__(self, session)

        self.name = name
        name = self.name.replace(' ', '+').replace(':', '+').replace('_', '+').replace('\xc3\x83\xe2\x80\x9e', 'Ae').replace('\xc3\x83\xe2\x80\x93', 'Oe').replace('\xc3\x83\xc5\x93', 'Ue').replace('\xc3\x83\xc5\xb8', 'ss').replace('\xc3\x83\xc2\xa4', 'ae').replace('\xc3\x83\xc2\xb6', 'oe').replace('\xc3\x83\xc2\xbc', 'ue').replace('\xc3\x84', 'Ae').replace('\xc3\x96', 'Oe').replace('\xc3\x9c', 'Ue').replace('\xc3\xa4', 'ae').replace('\xc3\xb6', 'oe').replace('\xc3\xbc', 'ue')
        self.link = 'http://www.youtube.com/results?filters=video&search_query=' + name
        self.titel = 'YouTube Trailer Search | Page '
        self.poster = []
        self.trailer_id = []
        self.trailer_list = []
        self.localhtml = '/tmp/youtube.html'
        self.poster1 = '/tmp/youtube1.jpg'
        self.poster2 = '/tmp/youtube2.jpg'
        self.poster3 = '/tmp/youtube3.jpg'
        self.poster4 = '/tmp/youtube4.jpg'
        self['poster1'] = Pixmap()
        self['poster2'] = Pixmap()
        self['poster3'] = Pixmap()
        self['poster4'] = Pixmap()
        self.ready = False
        self.hideflag = True
        self.count = 1
        self['list'] = ItemList([])
        self['label'] = Label('= Hide')
        self['label2'] = Label('= YouTube Search')
        
        self['actions'] = ActionMap(['OkCancelActions', 'DirectionActions', 'ColorActions', 'ChannelSelectBaseActions', 'HelpActions', 'NumberActions', 'MovieSelectionActions'], {
         'ok': self.ok,
         'cancel': self.exit,
         'right': self.rightDown,
         'left': self.leftUp,
         'down': self.down,
         'up': self.up,
         'nextBouquet': self.nextPage,
         'prevBouquet': self.prevPage,
         'yellow': self.search,
         'green': self.showHelp,
         'blue': self.hideScreen,
         '0': self.gotoEnd,
         'contextMenu': self.config,
         'bluelong': self.showHelp,
         'showEventInfo': self.showHelp,
         'displayHelp': self.infoScreen
         }, -1)
         
        self.movie_stop = config.usage.on_movie_stop.value
        self.movie_eof = config.usage.on_movie_eof.value
        config.usage.on_movie_stop.value = 'quit'
        config.usage.on_movie_eof.value = 'quit'
        
        if config.plugins.translator.color.value == '0x00000000':
            self.backcolor = False
        else:
            self.backcolor = True
            self.back_color = int(config.plugins.translator.color.value, 16)
            
        self.makeTrailerTimer = eTimer()
        self.makeTrailerTimer.callback.append(self.downloadFullPage(self.link, self.makeTrailerList))
        self.makeTrailerTimer.start(500, True)

    def makeTrailerList(self, string):
        self.setTitle(self.titel + str(self.count))
        output = open(self.localhtml, 'r').read()
        startpos = output.find('class="section-list">')
        endpos = output.find('\n</ol>\n\n')
        bereich = output[startpos:endpos]
        bereich = sub('</a>', '', bereich)
        bereich = sub('<b>', '', bereich)
        bereich = sub('</b>', '', bereich)
        bereich = sub('<wbr>', '', bereich)
        bereich = sub('</li><li>', ' \xc2\xb7 ', bereich)
        bereich = sub('&quot;', "'", bereich)
        bereich = transHTML(bereich)
        self.poster = re.findall('i.ytimg.com/(.*?)default.jpg', bereich)
        self.trailer_id = re.findall('<h3 class="yt-lockup-title.*?"><a href="/watch.v=(.*?)"', bereich)
      
        self.trailer_titel = re.findall('<h3 class="yt-lockup-title.*?"><a.*?"><span.*?">(.*?)<', bereich)
    
        trailer_time = re.findall('<span class="accessible-description" id="description-id.*?: (.*?)</span>', bereich)
   
        trailer_info = re.findall('<ul class="yt-lockup-meta-info">(.*?)</div>(.*?)</div>', bereich)

        
        for x in range(len(self.trailer_id)):
            res = ['']
            
            if screenwidth.width() <= 1280:
                if self.backcolor == True:
                    res.append(MultiContentEntryText(pos=(0, 0), size=(755, 125), font=-2, backcolor_sel=self.back_color, text=''))
                 
                    
                try:
                    res.append(MultiContentEntryText(pos=(5, 13), size=(730, 30), font=-2, color=16777215, flags=RT_HALIGN_LEFT, text=self.trailer_titel[x]))
                
                except IndexError:
                    pass

                try:
                    res.append(MultiContentEntryText(pos=(5, 48), size=(75, 25), font=0, color=16777215, flags=RT_HALIGN_RIGHT, text=trailer_time[x] + ' \xc2\xb7 '))
                except IndexError:
                    pass

                try:
                    info = sub('<.*?>', '', trailer_info[x][0])
                    res.append(MultiContentEntryText(pos=(85, 48), size=(650, 25), font=0, color=16777215, flags=RT_HALIGN_LEFT, text=info))
                except IndexError:
                    pass

                try:
                    desc = sub('<.*?>', '', trailer_info[x][1])
                    res.append(MultiContentEntryText(pos=(5, 75), size=(730, 50), font=0, color=16777215, flags=RT_HALIGN_LEFT | RT_WRAP, text=desc))
                except IndexError:
                    pass
            

            if screenwidth.width() > 1280:
                if self.backcolor == True:
                    res.append(MultiContentEntryText(pos=(0, 0), size=(1136, 188), font=-2, backcolor_sel=self.back_color, text=''))
                try:
                    res.append(MultiContentEntryText(pos=(8, 20), size=(1095, 45), font=-2, color=16777215, flags=RT_HALIGN_LEFT, text=self.trailer_titel[x]))
                except IndexError:
                    pass

                try:
                    res.append(MultiContentEntryText(pos=(8, 72), size=(113, 38), font=0, color=16777215, flags=RT_HALIGN_RIGHT, text=trailer_time[x] + ' \xc2\xb7 '))
                except IndexError:
                    pass

                try:
                    info = sub('<.*?>', '', trailer_info[x][0])
                    res.append(MultiContentEntryText(pos=(128, 72), size=(975, 38), font=0, color=16777215, flags=RT_HALIGN_LEFT, text=info))
                except IndexError:
                    pass

                try:
                    desc = sub('<.*?>', '', trailer_info[x][1])
                    res.append(MultiContentEntryText(pos=(8, 113), size=(1095, 75), font=0, color=16777215, flags=RT_HALIGN_LEFT | RT_WRAP, text=desc))
                except IndexError:
                    pass

            

            self.trailer_list.append(res)

        self['list'].l.setList(self.trailer_list)
        self['list'].l.setItemHeight(125)
        if screenwidth.width() > 1280:
            self['list'].l.setItemHeight(188)
            
        
        self['list'].moveToIndex(0)
        self.ready = True
        try:
            poster1 = 'https://i.ytimg.com/' + self.poster[0] + 'default.jpg'
            self.download(poster1, self.getPoster1)
            self['poster1'].show()
        except IndexError:
            self['poster1'].hide()

        try:
            poster2 = 'https://i.ytimg.com/' + self.poster[1] + 'default.jpg'
            self.download(poster2, self.getPoster2)
            self['poster2'].show()
        except IndexError:
            self['poster2'].hide()

        try:
            poster3 = 'https://i.ytimg.com/' + self.poster[2] + 'default.jpg'
            self.download(poster3, self.getPoster3)
            self['poster3'].show()
        except IndexError:
            self['poster3'].hide()

        try:
            poster4 = 'https://i.ytimg.com/' + self.poster[3] + 'default.jpg'
            self.download(poster4, self.getPoster4)
            self['poster4'].show()
        except IndexError:
            self['poster4'].hide()

    def ok(self):
        if self.ready == True:
            try:
                c = self['list'].getSelectedIndex()
                trailer_id = self.trailer_id[c]
                print "trailer_id %s" % trailer_id
                
                trailer_titel = self.trailer_titel[c]
                print "trailer_titel %s" % trailer_titel
                
                trailer_url = self.getTrailerURL(trailer_id)
                print "trailer_url %s" % trailer_url
                
                if trailer_url is not None:
                    sref = eServiceReference(4097, 0, trailer_url)
                    sref.setName(trailer_titel)
                    self.session.open(MoviePlayer, sref)
                else:
                    self.session.open(MessageBox, '\nVideo not available', MessageBox.TYPE_ERROR)
            except IndexError:
                pass

        return

    def getTrailerURL(self, trailer_id):
        header = {'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
         'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
         'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
         'Accept-Language': 'en-us,en;q=0.5'}
        VIDEO_FMT_PRIORITY_MAP = {
         '38': 3,
         '37': 1,
         '22': 2,
         '35': 5,
         '18': 4,
         '34': 6}
        trailer_url = None
        watch_url = 'http://www.youtube.com/watch?v=%s&gl=US&hl=en' % trailer_id
        
        if screenwidth.width() > 1280:
            watch_url = 'https://www.youtube.com/watch?v=%s&gl=US&hl=en&vq=hd1080&hd=1' % trailer_id
            


        watchrequest = Request(watch_url, None, header)
        

        try:
            watchvideopage = urlopen(watchrequest).read()
        except URLError:
            return trailer_url

        
        for el in ['&el=detailpage', '&el=embedded', '&el=vevo','']:
            info_url = 'https://www.youtube.com/get_video_info?&video_id=%s%s&ps=default&eurl=&gl=US&hl=en' % (trailer_id, el)
            request = Request(info_url, None, header)
            try:
                infopage = urlopen(request).read()
                videoinfo = parse_qs(infopage)
                
                print "videoinfo: %s" % videoinfo
                
                if ('url_encoded_fmt_stream_map' or 'fmt_url_map') in videoinfo:
                    break
            except URLError:
                print "URL error"
                return trailer_url

        if ('url_encoded_fmt_stream_map' or 'fmt_url_map') not in videoinfo:
            return trailer_url
            
        else:
            video_fmt_map = {}
            fmt_infomap = {}
            if videoinfo.has_key('url_encoded_fmt_stream_map'):
      
                tmp_fmtUrlDATA = videoinfo['url_encoded_fmt_stream_map'][0].split(',')
            else:

                tmp_fmtUrlDATA = videoinfo['fmt_url_map'][0].split(',')
            for fmtstring in tmp_fmtUrlDATA:
                fmturl = fmtid = ''
                if videoinfo.has_key('url_encoded_fmt_stream_map'):
                    try:
                        for arg in fmtstring.split('&'):
                            if arg.find('=') >= 0:
                                key, value = arg.split('=')
                                if key == 'itag':
                                    if len(value) > 3:
                                        value = value[:2]
                                    fmtid = value
                                elif key == 'url':
                                    fmturl = value

                        if fmtid != '' and fmturl != '' and VIDEO_FMT_PRIORITY_MAP.has_key(fmtid):
                            video_fmt_map[VIDEO_FMT_PRIORITY_MAP[fmtid]] = {'fmtid': fmtid,
                             'fmturl': unquote_plus(fmturl)}
                            fmt_infomap[int(fmtid)] = '%s' % unquote_plus(fmturl)
                        fmturl = fmtid = ''
                    except:
                        return trailer_url

                else:
                    fmtid, fmturl = fmtstring.split('|')
                if VIDEO_FMT_PRIORITY_MAP.has_key(fmtid) and fmtid != '':
                    video_fmt_map[VIDEO_FMT_PRIORITY_MAP[fmtid]] = {'fmtid': fmtid,
                     'fmturl': unquote_plus(fmturl)}
                    fmt_infomap[int(fmtid)] = unquote_plus(fmturl)

            if video_fmt_map and len(video_fmt_map):
                best_video = video_fmt_map[sorted(video_fmt_map.iterkeys())[0]]
                trailer_url = '%s' % best_video['fmturl'].split(';')[0]
                
            return trailer_url
    


    def search(self):
        if self.ready == True:
            self.session.openWithCallback(self.searchReturn, VirtualKeyBoard, title='YouTube Trailer Search:', text=self.name)

    def searchReturn(self, name):
        if name and name != '':
            self.name = name
            name = name.replace(' ', '+').replace(':', '+').replace('_', '+').replace('\xc3\x84', 'Ae').replace('\xc3\x96', 'Oe').replace('\xc3\x9c', 'Ue').replace('\xc3\xa4', 'ae').replace('\xc3\xb6', 'oe').replace('\xc3\xbc', 'ue')
            self.link = 'http://www.youtube.com/results?filters=video&search_query=' + name
            self.count = 1
            self.poster = []
            self.trailer_id = []
            self.trailer_list = []
            self.makeTrailerTimer.callback.append(self.downloadFullPage(self.link, self.makeTrailerList))

    def nextPage(self):
        if self.ready == True:
            self.count += 1
            if self.count >= 10:
                self.count = 9
            link = self.link + '&page=' + str(self.count)
            self.poster = []
            self.trailer_id = []
            self.trailer_list = []
            self.makeTrailerTimer.callback.append(self.downloadFullPage(link, self.makeTrailerList))

    def prevPage(self):
        if self.ready == True:
            self.count -= 1
            if self.count <= 0:
                self.count = 1
            link = self.link + '&page=' + str(self.count)
            self.poster = []
            self.trailer_id = []
            self.trailer_list = []
            self.makeTrailerTimer.callback.append(self.downloadFullPage(link, self.makeTrailerList))

    def down(self):
        if self.ready == True:
            try:
                c = self['list'].getSelectedIndex()
            except IndexError:
                return

            self['list'].down()
            if c + 1 == len(self.trailer_id):
                try:
                    poster1 = 'https://i.ytimg.com/' + self.poster[0] + 'default.jpg'
                    self.download(poster1, self.getPoster1)
                    self['poster1'].show()
                except IndexError:
                    self['poster1'].hide()

                try:
                    poster2 = 'https://i.ytimg.com/' + self.poster[1] + 'default.jpg'
                    self.download(poster2, self.getPoster2)
                    self['poster2'].show()
                except IndexError:
                    self['poster2'].hide()

                try:
                    poster3 = 'https://i.ytimg.com/' + self.poster[2] + 'default.jpg'
                    self.download(poster3, self.getPoster3)
                    self['poster3'].show()
                except IndexError:
                    self['poster3'].hide()

                try:
                    poster4 = 'https://i.ytimg.com/' + self.poster[3] + 'default.jpg'
                    self.download(poster4, self.getPoster4)
                    self['poster4'].show()
                except IndexError:
                    self['poster4'].hide()

            elif c % 4 == 3:
                try:
                    poster1 = 'https://i.ytimg.com/' + self.poster[c + 1] + 'default.jpg'
                    self.download(poster1, self.getPoster1)
                    self['poster1'].show()
                except IndexError:
                    self['poster1'].hide()

                try:
                    poster2 = 'https://i.ytimg.com/' + self.poster[c + 2] + 'default.jpg'
                    self.download(poster2, self.getPoster2)
                    self['poster2'].show()
                except IndexError:
                    self['poster2'].hide()

                try:
                    poster3 = 'https://i.ytimg.com/' + self.poster[c + 3] + 'default.jpg'
                    self.download(poster3, self.getPoster3)
                    self['poster3'].show()
                except IndexError:
                    self['poster3'].hide()

                try:
                    poster4 = 'https://i.ytimg.com/' + self.poster[c + 4] + 'default.jpg'
                    self.download(poster4, self.getPoster4)
                    self['poster4'].show()
                except IndexError:
                    self['poster4'].hide()

    def up(self):
        if self.ready == True:
            try:
                c = self['list'].getSelectedIndex()
            except IndexError:
                return

            self['list'].up()
            if c == 0:
                l = len(self.trailer_list)
                d = l % 4
                if d == 0:
                    d = 4
                try:
                    poster1 = 'https://i.ytimg.com/' + self.poster[l - d] + 'default.jpg'
                    self.download(poster1, self.getPoster1)
                    self['poster1'].show()
                except IndexError:
                    self['poster1'].hide()

                try:
                    poster2 = 'https://i.ytimg.com/' + self.poster[l - d + 1] + 'default.jpg'
                    self.download(poster2, self.getPoster2)
                    self['poster2'].show()
                except IndexError:
                    self['poster2'].hide()

                try:
                    poster3 = 'https://i.ytimg.com/' + self.poster[l - d + 2] + 'default.jpg'
                    self.download(poster3, self.getPoster3)
                    self['poster3'].show()
                except IndexError:
                    self['poster3'].hide()

                try:
                    poster4 = 'https://i.ytimg.com/' + self.poster[l - d + 3] + 'default.jpg'
                    self.download(poster4, self.getPoster4)
                    self['poster4'].show()
                except IndexError:
                    self['poster4'].hide()

            elif c % 4 == 0:
                try:
                    poster1 = 'https://i.ytimg.com/' + self.poster[c - 4] + 'default.jpg'
                    self.download(poster1, self.getPoster1)
                    self['poster1'].show()
                except IndexError:
                    self['poster1'].hide()

                try:
                    poster2 = 'https://i.ytimg.com/' + self.poster[c - 3] + 'default.jpg'
                    self.download(poster2, self.getPoster2)
                    self['poster2'].show()
                except IndexError:
                    self['poster2'].hide()

                try:
                    poster3 = 'https://i.ytimg.com/' + self.poster[c - 2] + 'default.jpg'
                    self.download(poster3, self.getPoster3)
                    self['poster3'].show()
                except IndexError:
                    self['poster3'].hide()

                try:
                    poster4 = 'https://i.ytimg.com/' + self.poster[c - 1] + 'default.jpg'
                    self.download(poster4, self.getPoster4)
                    self['poster4'].show()
                except IndexError:
                    self['poster4'].hide()

    def rightDown(self):
        if self.ready == True:
            try:
                c = self['list'].getSelectedIndex()
            except IndexError:
                return

            self['list'].pageDown()
            l = len(self.trailer_list)
            d = c % 4
            e = l % 4
            if e == 0:
                e = 4
            if c + e >= l:
                pass
            elif d == 0:
                try:
                    poster1 = 'https://i.ytimg.com/' + self.poster[c + 4] + 'default.jpg'
                    self.download(poster1, self.getPoster1)
                except IndexError:
                    self['poster1'].hide()

                try:
                    poster2 = 'https://i.ytimg.com/' + self.poster[c + 5] + 'default.jpg'
                    self.download(poster2, self.getPoster2)
                except IndexError:
                    self['poster2'].hide()

                try:
                    poster3 = 'https://i.ytimg.com/' + self.poster[c + 6] + 'default.jpg'
                    self.download(poster3, self.getPoster3)
                except IndexError:
                    self['poster3'].hide()

                try:
                    poster4 = 'https://i.ytimg.com/' + self.poster[c + 7] + 'default.jpg'
                    self.download(poster4, self.getPoster4)
                except IndexError:
                    self['poster4'].hide()

            elif d == 1:
                try:
                    poster1 = 'https://i.ytimg.com/' + self.poster[c + 3] + 'default.jpg'
                    self.download(poster1, self.getPoster1)
                except IndexError:
                    self['poster1'].hide()

                try:
                    poster2 = 'https://i.ytimg.com/' + self.poster[c + 4] + 'default.jpg'
                    self.download(poster2, self.getPoster2)
                except IndexError:
                    self['poster2'].hide()

                try:
                    poster3 = 'https://i.ytimg.com/' + self.poster[c + 5] + 'default.jpg'
                    self.download(poster3, self.getPoster3)
                except IndexError:
                    self['poster3'].hide()

                try:
                    poster4 = 'https://i.ytimg.com/' + self.poster[c + 6] + 'default.jpg'
                    self.download(poster4, self.getPoster4)
                except IndexError:
                    self['poster4'].hide()

            elif d == 2:
                try:
                    poster1 = 'https://i.ytimg.com/' + self.poster[c + 2] + 'default.jpg'
                    self.download(poster1, self.getPoster1)
                except IndexError:
                    self['poster1'].hide()

                try:
                    poster2 = 'https://i.ytimg.com/' + self.poster[c + 3] + 'default.jpg'
                    self.download(poster2, self.getPoster2)
                except IndexError:
                    self['poster2'].hide()

                try:
                    poster3 = 'https://i.ytimg.com/' + self.poster[c + 4] + 'default.jpg'
                    self.download(poster3, self.getPoster3)
                except IndexError:
                    self['poster3'].hide()

                try:
                    poster4 = 'https://i.ytimg.com/' + self.poster[c + 5] + 'default.jpg'
                    self.download(poster4, self.getPoster4)
                except IndexError:
                    self['poster4'].hide()

            elif d == 3:
                try:
                    poster1 = 'https://i.ytimg.com/' + self.poster[c + 1] + 'default.jpg'
                    self.download(poster1, self.getPoster1)
                except IndexError:
                    self['poster1'].hide()

                try:
                    poster2 = 'https://i.ytimg.com/' + self.poster[c + 2] + 'default.jpg'
                    self.download(poster2, self.getPoster2)
                except IndexError:
                    self['poster2'].hide()

                try:
                    poster3 = 'https://i.ytimg.com/' + self.poster[c + 3] + 'default.jpg'
                    self.download(poster3, self.getPoster3)
                except IndexError:
                    self['poster3'].hide()

                try:
                    poster4 = 'https://i.ytimg.com/' + self.poster[c + 4] + 'default.jpg'
                    self.download(poster4, self.getPoster4)
                except IndexError:
                    self['poster4'].hide()

    def leftUp(self):
        if self.ready == True:
            try:
                c = self['list'].getSelectedIndex()
            except IndexError:
                return

            self['list'].pageUp()
            d = c % 4
            if c < 4:
                return
            if d == 0:
                try:
                    poster1 = 'https://i.ytimg.com/' + self.poster[c - 4] + 'default.jpg'
                    self.download(poster1, self.getPoster1)
                    poster2 = 'https://i.ytimg.com/' + self.poster[c - 3] + 'default.jpg'
                    self.download(poster2, self.getPoster2)
                    poster3 = 'https://i.ytimg.com/' + self.poster[c - 2] + 'default.jpg'
                    self.download(poster3, self.getPoster3)
                    poster4 = 'https://i.ytimg.com/' + self.poster[c - 1] + 'default.jpg'
                    self.download(poster4, self.getPoster4)
                except IndexError:
                    pass

            elif d == 1:
                try:
                    poster1 = 'https://i.ytimg.com/' + self.poster[c - 5] + 'default.jpg'
                    self.download(poster1, self.getPoster1)
                    poster2 = 'https://i.ytimg.com/' + self.poster[c - 4] + 'default.jpg'
                    self.download(poster2, self.getPoster2)
                    poster3 = 'https://i.ytimg.com/' + self.poster[c - 3] + 'default.jpg'
                    self.download(poster3, self.getPoster3)
                    poster4 = 'https://i.ytimg.com/' + self.poster[c - 2] + 'default.jpg'
                    self.download(poster4, self.getPoster4)
                except IndexError:
                    pass

            elif d == 2:
                try:
                    poster1 = 'https://i.ytimg.com/' + self.poster[c - 6] + 'default.jpg'
                    self.download(poster1, self.getPoster1)
                    poster2 = 'https://i.ytimg.com/' + self.poster[c - 5] + 'default.jpg'
                    self.download(poster2, self.getPoster2)
                    poster3 = 'https://i.ytimg.com/' + self.poster[c - 4] + 'default.jpg'
                    self.download(poster3, self.getPoster3)
                    poster4 = 'https://i.ytimg.com/' + self.poster[c - 3] + 'default.jpg'
                    self.download(poster4, self.getPoster4)
                except IndexError:
                    pass

            elif d == 3:
                try:
                    poster1 = 'https://i.ytimg.com/' + self.poster[c - 7] + 'default.jpg'
                    self.download(poster1, self.getPoster1)
                    poster2 = 'https://i.ytimg.com/' + self.poster[c - 6] + 'default.jpg'
                    self.download(poster2, self.getPoster2)
                    poster3 = 'https://i.ytimg.com/' + self.poster[c - 5] + 'default.jpg'
                    self.download(poster3, self.getPoster3)
                    poster4 = 'https://i.ytimg.com/' + self.poster[c - 4] + 'default.jpg'
                    self.download(poster4, self.getPoster4)
                except IndexError:
                    pass

            self['poster1'].show()
            self['poster2'].show()
            self['poster3'].show()
            self['poster4'].show()

    def gotoEnd(self):
        if self.ready == True:
            end = len(self.trailer_list) - 1
            if end > 4:
                self['list'].moveToIndex(end)
                self.leftUp()
                self.rightDown()

    def getPoster1(self, output):
        f = open(self.poster1, 'wb')
        f.write(output)
        f.close()
        self.showPoster1(self.poster1)

    def showPoster1(self, poster1):
        currPic = loadPic(poster1, 215, 120, 3, 0, 0, 0)
        if screenwidth.width() > 1280:
            currPic = loadPic(poster1, 322, 180, 5, 0, 0, 0)
            
        
        if currPic != None:
            self['poster1'].instance.setPixmap(currPic)
        return

    def getPoster2(self, output):
        f = open(self.poster2, 'wb')
        f.write(output)
        f.close()
        self.showPoster2(self.poster2)

    def showPoster2(self, poster2):
        currPic = loadPic(poster2, 215, 120, 3, 0, 0, 0)
        if screenwidth.width() > 1280:
            currPic = loadPic(poster2, 322, 180, 5, 0, 0, 0)
        
        if currPic != None:
            self['poster2'].instance.setPixmap(currPic)
        return

    def getPoster3(self, output):
        f = open(self.poster3, 'wb')
        f.write(output)
        f.close()
        self.showPoster3(self.poster3)

    def showPoster3(self, poster3):
        currPic = loadPic(poster3, 215, 120, 3, 0, 0, 0)
        if screenwidth.width() > 1280:
            currPic = loadPic(poster3, 322, 180, 5, 0, 0, 0)
            
        if currPic != None:
            self['poster3'].instance.setPixmap(currPic)
        return

    def getPoster4(self, output):
        f = open(self.poster4, 'wb')
        f.write(output)
        f.close()
        self.showPoster4(self.poster4)

    def showPoster4(self, poster4):
        currPic = loadPic(poster4, 215, 120, 3, 0, 0, 0)
        if screenwidth.width() > 1280:
            currPic = loadPic(poster4, 322, 180, 5, 0, 0, 0)
        if currPic != None:
            self['poster4'].instance.setPixmap(currPic)
        return



    def download(self, link, name):
        getPage(link).addCallback(name).addErrback(self.downloadError)

    def downloadError(self, output):
        pass

    def downloadFullPage(self, link, name):
        downloadPage(link, self.localhtml).addCallback(name).addErrback(self.downloadPageError)

    def downloadPageError(self, output):
        try:
            error = output.getErrorMessage()
            self.session.open(MessageBox, 'The YouTube Server is not reachable:\n%s' % error, MessageBox.TYPE_ERROR)
        except AttributeError:
            self.session.open(MessageBox, '\nThe YouTube Server is not reachable.', MessageBox.TYPE_ERROR)

        self.close()

    def showHelp(self):
        lang = language.getLanguage()[:2]
        if lang == 'de':
            self.session.open(MessageBox, '\n%s' % 'Bouquet : +- Seite\nGelb : neue YouTube Suche\nMen\xc3\xbc : Setup', MessageBox.TYPE_INFO, close_on_any_key=True)
        else:
            self.session.open(MessageBox, '\n%s' % 'Bouquet : +- Page\nYellow : new YouTube Search\nMenu : Setup', MessageBox.TYPE_INFO, close_on_any_key=True)

    def config(self):
        config.usage.on_movie_stop.value = self.movie_stop
        config.usage.on_movie_eof.value = self.movie_eof
        self.session.openWithCallback(self.exit, youtubeConfig)

    def infoScreen(self):
        self.session.open(infoTranslator, True)

    def hideScreen(self):
        if self.hideflag == True:
            self.hideflag = False
            count = 40
            while count > 0:
                count -= 1
                f = open('/proc/stb/video/alpha', 'w')
                f.write('%i' % (config.av.osd_alpha.value * count / 40))
                f.close()

        else:
            self.hideflag = True
            count = 0
            while count < 40:
                count += 1
                f = open('/proc/stb/video/alpha', 'w')
                f.write('%i' % (config.av.osd_alpha.value * count / 40))
                f.close()

    def exit(self):
        if self.hideflag == False:
            f = open('/proc/stb/video/alpha', 'w')
            f.write('%i' % config.av.osd_alpha.value)
            f.close()
        if fileExists(self.localhtml):
            os.remove(self.localhtml)
        if fileExists(self.poster1):
            os.remove(self.poster1)
        if fileExists(self.poster2):
            os.remove(self.poster2)
        if fileExists(self.poster3):
            os.remove(self.poster3)
        if fileExists(self.poster4):
            os.remove(self.poster4)
        config.usage.on_movie_stop.value = self.movie_stop
        config.usage.on_movie_eof.value = self.movie_eof

        self.close()


class ItemList(MenuList):

    def __init__(self, items, enableWrapAround = True):
        MenuList.__init__(self, items, enableWrapAround, eListboxPythonMultiContent)
        self.l.setFont(-2, gFont('Bold', 24))
        self.l.setFont(-1, gFont('Regular', 24))
        self.l.setFont(0, gFont('Regular', 22))
        self.l.setFont(1, gFont('Regular', 20))
        self.l.setFont(2, gFont('Regular', 18))
        
        if screenwidth.width() > 1280:
            self.l.setFont(-2, gFont('Bold', 36))
            self.l.setFont(-1, gFont('Regular', 36))
            self.l.setFont(0, gFont('Regular', 33))
            self.l.setFont(1, gFont('Regular', 30))
            self.l.setFont(2, gFont('Regular', 27))

class YouTubeMain(Screen):
    skin = """
    <screen position="0,0" size="0,0" ></screen>
    """

    def __init__(self, session):
        self.skin = YouTubeMain.skin
        self.session = session
        Screen.__init__(self, session)
        self.YouTubeTimer = eTimer()
        self.YouTubeTimer.callback.append(self.makeYouTube)
        self.YouTubeTimer.start(100, True)

    def makeYouTube(self):
        service = self.session.nav.getCurrentService()
        info = service.info()
        curEvent = info.getEvent(0)
        try:
            eventName = curEvent.getEventName()
            self.session.openWithCallback(self.close, searchYouTube, eventName)
        except AttributeError:
            self.session.open(MessageBox, '\nNo EPG found', MessageBox.TYPE_ERROR)
            self.close()


class translatorMain(Screen):
    skin = """
    <screen position="center,80" size="1000,610" title="EPG Translator">
        <ePixmap position="0,0" size="1000,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/translator.png" alphatest="blend" zPosition="1" />
        <ePixmap position="10,6" size="18,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/blue.png" alphatest="blend" zPosition="2" />
        <ePixmap position="10,26" size="18,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/yellow.png" alphatest="blend" zPosition="2" />
        <widget name="label" position="34,6" size="200,20" font="Regular;16" foregroundColor="#697178" backgroundColor="#FFFFFF" halign="left" transparent="1" zPosition="2" />
        <widget name="label2" position="34,26" size="200,20" font="Regular;16" foregroundColor="#697178" backgroundColor="#FFFFFF" halign="left" transparent="1" zPosition="2" />
        <widget render="Label" source="global.CurrentTime" position="740,0" size="240,50" font="Regular;24" foregroundColor="#697178" backgroundColor="#FFFFFF" halign="right" valign="center" zPosition="2">
        <convert type="ClockToText">Format:%H:%M:%S</convert>
        </widget>
        <widget name="flag" position="10,40" size="288,288" alphatest="blend" zPosition="1" />
        <widget name="flag2" position="10,325" size="288,288" alphatest="blend" zPosition="1" />
        <widget name="text" position="308,60" size="682,{size}" font="Regular;24" halign="left" zPosition="2" />
        <widget name="text2" position="308,345" size="682,270" font="Regular;24" halign="left" zPosition="1" />
    </screen>
    """
    
    if screenwidth.width() > 1280:
        skin = """
        <screen position="center,120" size="1500,915" title="EPG Translator">
            <ePixmap position="0,0" size="1500,75" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/fhd-translator.png" alphatest="blend" zPosition="1" />
            <ePixmap position="15,9" size="27,27" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/fhd-blue.png" alphatest="blend" zPosition="2" />
            <ePixmap position="15,39" size="27,27" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/buttons/fhd-yellow.png" alphatest="blend" zPosition="2" />
            <widget name="label" position="51,9" size="300,30" font="Regular;24" foregroundColor="#697178" backgroundColor="#FFFFFF" halign="left" transparent="1" zPosition="2" />
            <widget name="label2" position="51,39" size="300,30" font="Regular;24" foregroundColor="#697178" backgroundColor="#FFFFFF" halign="left" transparent="1" zPosition="2" />
            <widget render="Label" source="global.CurrentTime" position="1110,0" size="360,75" font="Regular;36" foregroundColor="#697178" backgroundColor="#FFFFFF" halign="right" valign="center" zPosition="2">
            <convert type="ClockToText">Format:%H:%M:%S</convert>
            </widget>
            <widget name="flag" position="15,60" size="288,288" alphatest="blend" zPosition="1" />
            <widget name="flag2" position="15,488" size="288,288" alphatest="blend" zPosition="1" />
            <widget name="text" position="462,90" size="1023,{size}" font="Regular;36" halign="left" zPosition="2" />
            <widget name="text2" position="462,518" size="1023,405" font="Regular;36" halign="left" zPosition="1" />
        </screen>
        """
        
    def __init__(self, session, text):
        self.showsource = config.plugins.translator.showsource.value
        
        if self.showsource == 'yes':
            size = '270'
        else:
            size = '555'
            
        if screenwidth.width() > 1280:
            if self.showsource == 'yes':
                size = '405'
            else:
                size = '832'
            
        self.dict = {'size': size}
        self.skin = applySkinVars(translatorMain.skin, self.dict)
        self.session = session
        Screen.__init__(self, session)

        self.source = str(config.plugins.translator.source.value)
        self.destination = str(config.plugins.translator.destination.value)
        self.text = text
        self.hideflag = True
        self.refresh = False
        self.max = 1
        self.count = 0
        self.list = []
        self.eventName = ''
        self['flag'] = Pixmap()
        self['flag2'] = Pixmap()
        self['text'] = ScrollLabel('')
        self['text2'] = ScrollLabel('')
        self['label'] = Label('= Hide')
        self['label2'] = Label('= YouTube Trailer')
        self['actions'] = ActionMap(['OkCancelActions',
         'DirectionActions',
         'ChannelSelectBaseActions',
         'ColorActions',
         'MoviePlayerActions',
         'MovieSelectionActions',
         'HelpActions'], {'ok': self.ok,
         'cancel': self.exit,
         'right': self.rightDown,
         'left': self.leftUp,
         'down': self.down,
         'up': self.up,
         'nextBouquet': self.zapDown,
         'prevBouquet': self.zapUp,
         'red': self.getEPG,
         'yellow': self.youTube,
         'green': self.showHelp,
         'blue': self.hideScreen,
         'leavePlayer': self.youTube,
         'contextMenu': self.config,
         'bluelong': self.showHelp,
         'showEventInfo': self.showHelp,
         'displayHelp': self.infoScreen}, -1)
        self.onLayoutFinish.append(self.onLayoutFinished)

    def onLayoutFinished(self):
        
        source = '/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/flag/' + self.source + '.png'
        destination = '/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslator/pic/flag/' + self.destination + '.png'
        if self.showsource == 'yes':
            if fileExists(source):
                self['flag'].instance.setPixmapFromFile(source)
            if fileExists(destination):
                self['flag2'].instance.setPixmapFromFile(destination)
        elif fileExists(destination):
            self['flag'].instance.setPixmapFromFile(destination)
        if self.text is None:
            self.getEPG()
        else:
            self.translateEPG(self.text)
        return

    def ok(self):
        self.session.openWithCallback(self.translateText, VirtualKeyBoard, title='Text Translator:', text='')

    def translateText(self, text):
        if text and text != '':
            self.setTitle('Text Translator')
            if self.showsource == 'yes':
                self['text'].setText(text)
# We need to url-encode this text (so "quote" is a misnamed function).
#
            text = quote(text)
            if len(text) > 2000:
                text = text[0:2000]
            url = 'http://translate.google.com/m?hl=%s&sl=%s&q=%s' % (self.destination, self.source, text)
            agents = {'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6'}
# We'll extract the result from the returned web-page
# This is currently (07 Dec 2020) in a div with its last item making it
# a result-container...
#
            before_trans = 'class="result-container">'
            request = Request(url, headers=agents)
            try:
                output = urlopen(request, timeout=20).read()
                data = output[output.find(before_trans) + len(before_trans):]
# ...and we want to keep going to the end of the div
#
                newtext = data.split('</div>')[0]
                newtext = transHTML(newtext)
                if self.showsource == 'yes':
                    self['text2'].setText(newtext)
                else:
                    self['text'].setText(newtext)
                    self['text2'].hide()
            except URLError as e:
                error = 'URL Error: ' + str(e.reason)
                if self.showsource == 'yes':
                    self['text2'].setText(error)
                else:
                    self['text'].setText(error)
                    self['text2'].hide()
            except HTTPError as e:
                error = 'HTTP Error: ' + str(e.code)
                if self.showsource == 'yes':
                    self['text2'].setText(error)
                else:
                    self['text'].setText(error)
                    self['text2'].hide()
            except socket.error as e:
                error = 'Socket Error: ' + str(e)
                if self.showsource == 'yes':
                    self['text2'].setText(error)
                else:
                    self['text'].setText(error)
                    self['text2'].hide()

    def translateEPG(self, text):
        if text and text != '':
            self.setTitle('EPG Translator')
            try:
                begin = self.event.getBeginTimeString()
                duration = '%d min' % (self.event.getDuration() / 60)
            except:
                begin = ''
                duration = ''

            if self.showsource == 'yes':
                if self.refresh == False:
                    self['text'].setText(begin + '\n\n' + text + '\n\n' + duration)
                else:
                    self['text'].setText(text)
# We need to url-encode this text (so "quote" is a misnamed function).
#
            text = quote(text)
            if len(text) > 2000:
                text = text[0:2000]
            url = 'http://translate.google.com/m?hl=%s&sl=%s&q=%s' % (self.destination, self.source, text)
            agents = {'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6'}
# We'll extract the result from the returned web-page
# This is currently (07 Dec 2020) in a div with its last item making it
# a result-container...
#
            before_trans = 'class="result-container">'
            request = Request(url, headers=agents)
            try:
                output = urlopen(request, timeout=20).read()
                data = output[output.find(before_trans) + len(before_trans):]
# ...and we want to keep going to the end of the div
#
                newtext = data.split('</div>')[0]
                newtext = sub('\n ', '\n', newtext)
                newtext = transHTML(newtext)
                if self.refresh == False:
                    newtext = begin + '\n\n' + newtext + '\n\n' + duration
                    newtext = sub('\n\n\n\n', '\n\n', newtext)
                if self.showsource == 'yes':
                    self['text2'].setText(newtext)
                else:
                    self['text'].setText(newtext)
                    self['text2'].hide()
            except URLError as e:
                error = 'URL Error: ' + str(e.reason)
                if self.showsource == 'yes':
                    self['text2'].setText(error)
                else:
                    self['text'].setText(error)
                    self['text2'].hide()
            except HTTPError as e:
                error = 'HTTP Error: ' + str(e.code)
                if self.showsource == 'yes':
                    self['text2'].setText(error)
                else:
                    self['text'].setText(error)
                    self['text2'].hide()
            except socket.error as e:
                error = 'Socket Error: ' + str(e)
                if self.showsource == 'yes':
                    self['text2'].setText(error)
                else:
                    self['text'].setText(error)
                    self['text2'].hide()

    def getEPG(self):
        self.max = 1
        self.count = 0
        self.list = []
        self.epgcache = eEPGCache.getInstance()
        ref = self.session.nav.getCurrentlyPlayingServiceReference()
        service = self.session.nav.getCurrentService()
        info = service.info()
        curEvent = info.getEvent(0)
        if curEvent:
            self.list.append(curEvent)
            self.epgcache.startTimeQuery(eServiceReference(ref.toString()), curEvent.getBeginTime() + curEvent.getDuration())
            i = 1
            while i <= int(config.plugins.translator.maxevents.value):
                event = self.epgcache.getNextTimeEntry()
                if event is not None:
                    self.list.append(event)
                i += 1

            self.max = len(self.list)
        self.showEPG()
        return

    def showEPG(self):
        try:
            self.event = self.list[self.count]
            self.eventName = self.event.getEventName()
            text = self.eventName
            short = self.event.getShortDescription()
            ext = self.event.getExtendedDescription()
            self.refresh = False
        except:
            text = 'Press red button to refresh EPG'
            short = ''
            ext = ''
            self.refresh = True

        if short and short != text:
            text += '\n\n' + short
        if ext:
            if text:
                text += '\n\n'
            text += ext
        self.translateEPG(str(text))

    def leftUp(self):
        self.count -= 1
        if self.count == -1:
            self.count = self.max - 1
        self.showEPG()

    def rightDown(self):
        self.count += 1
        if self.count == self.max:
            self.count = 0
        self.showEPG()

    def up(self):
        self['text'].pageUp()
        self['text2'].pageUp()

    def down(self):
        self['text'].pageDown()
        self['text2'].pageDown()



    def download(self, link, name):
        getPage(link).addCallback(name).addErrback(self.downloadError)

    def downloadError(self, output):
        pass

    def zapUp(self):
        if InfoBar and InfoBar.instance:
            InfoBar.zapUp(InfoBar.instance)
            self.getEPG()

    def zapDown(self):
        if InfoBar and InfoBar.instance:
            InfoBar.zapDown(InfoBar.instance)
            self.getEPG()

    def youTube(self):
        self.session.open(searchYouTube, self.eventName)

    def showHelp(self):
        lang = language.getLanguage()[:2]
        if lang == 'de':
            self.session.open(MessageBox, '%s' % 'EPG:\nStop : suche YouTube Trailer\nPfeil rechts : EPG \xc3\xbcbersetzen\n\nTranslator Plugin:\nLinks <-> Rechts : +- EPG Event\nGelb : suche YouTube Trailer\nOk : Text \xc3\xbcbersetzen\nBouquet : +- Zap\nMen\xc3\xbc : Setup\n\nYouTube Plugin:\nBouquet : +- Seite\nGelb : neue YouTube Suche\nMen\xc3\xbc : Setup', MessageBox.TYPE_INFO, close_on_any_key=True)
        else:
            self.session.open(MessageBox, '%s' % 'Inside EPG:\nStop : search YouTube Trailer\nRight Arrow : translate EPG\n\nInside Plugin:\nLeft <-> Right : <-> +- EPG Event\nYellow : search YouTube Trailer\nOk : translate Text\nBouquet : +- Zap\nMenu : Setup\n\nYouTube Plugin:\nBouquet : +- Page\nYellow : new YouTube Search\nMenu : Setup', MessageBox.TYPE_INFO, close_on_any_key=True)

    def config(self):
        self.session.openWithCallback(self.exit, translatorConfig)

    def infoScreen(self):
        self.session.open(infoTranslator, True)

    def hideScreen(self):
        if self.hideflag == True:
            self.hideflag = False
            count = 40
            while count > 0:
                count -= 1
                f = open('/proc/stb/video/alpha', 'w')
                f.write('%i' % (config.av.osd_alpha.value * count / 40))
                f.close()

        else:
            self.hideflag = True
            count = 0
            while count < 40:
                count += 1
                f = open('/proc/stb/video/alpha', 'w')
                f.write('%i' % (config.av.osd_alpha.value * count / 40))
                f.close()

    def exit(self):
        if self.hideflag == False:
            f = open('/proc/stb/video/alpha', 'w')
            f.write('%i' % config.av.osd_alpha.value)
            f.close()
        self.close()


def autostart(reason, **kwargs):
    global newEventViewBase__init__
    global newEPGSelection__init__
    newEventViewBase__init__ = EventViewBase.__init__
    EventViewBase.__init__ = EventViewBase__init__
    EventViewBase.showYouTube = showYouTube
    EventViewBase.translateEPG = translateEPG
    newEPGSelection__init__ = EPGSelection.__init__
    try:
        check = EPGSelection.setPiPService
        EPGSelection.__init__ = EPGSelectionVTi__init__
    except AttributeError:
        try:
            check = EPGSelection.togglePIG
            EPGSelection.__init__ = EPGSelectionATV__init__
        except AttributeError:
            try:
                check = EPGSelection.runPlugin
                EPGSelection.__init__ = EPGSelectionPLI__init__
            except AttributeError:
                EPGSelection.__init__ = EPGSelection__init__

    EPGSelection.showYouTube = showYouTube


def EventViewBase__init__(self, Event, Ref, callback = None, similarEPGCB = None):
    newEventViewBase__init__(self, Event, Ref, callback, similarEPGCB)
    self['youTubeAction'] = ActionMap(['MoviePlayerActions', 'ChannelSelectBaseActions'], {'leavePlayer': self.showYouTube,
     'nextMarker': self.translateEPG})


def EPGSelection__init__(self, session, service, zapFunc = None, eventid = None, bouquetChangeCB = None, serviceChangeCB = None):
    newEPGSelection__init__(self, session, service, zapFunc, eventid, bouquetChangeCB, serviceChangeCB)
    self['youTubeAction'] = ActionMap(['MoviePlayerActions'], {'leavePlayer': self.showYouTube})


def EPGSelectionVTi__init__(self, session, service, zapFunc = None, eventid = None, bouquetChangeCB = None, serviceChangeCB = None, isEPGBar = None, switchBouquet = None, EPGNumberZap = None, togglePiP = None):
    newEPGSelection__init__(self, session, service, zapFunc, eventid, bouquetChangeCB, serviceChangeCB, isEPGBar, switchBouquet, EPGNumberZap, togglePiP)
    self['youTubeAction'] = ActionMap(['MoviePlayerActions'], {'leavePlayer': self.showYouTube})


def EPGSelectionATV__init__(self, session, service = None, zapFunc = None, eventid = None, bouquetChangeCB = None, serviceChangeCB = None, EPGtype = None, StartBouquet = None, StartRef = None, bouquets = None):
    newEPGSelection__init__(self, session, service, zapFunc, eventid, bouquetChangeCB, serviceChangeCB, EPGtype, StartBouquet, StartRef, bouquets)
    self['youTubeAction'] = ActionMap(['MoviePlayerActions'], {'leavePlayer': self.showYouTube})


def EPGSelectionPLI__init__(self, session, service = None, zapFunc = None, eventid = None, bouquetChangeCB = None, serviceChangeCB = None, parent = None):
    newEPGSelection__init__(self, session, service, zapFunc, eventid, bouquetChangeCB, serviceChangeCB, parent)
    self['youTubeAction'] = ActionMap(['MoviePlayerActions'], {'leavePlayer': self.showYouTube})


def showYouTube(self):
    eventName = ''
    if isinstance(self, EventViewBase):
        if self.event:
            eventName = self.event.getEventName()
    else:
        cur = self['list'].getCurrent()
        event = cur[0]
        if event is not None:
            eventName = event.getEventName()
    self.session.open(searchYouTube, eventName)
    return


def translateEPG(self):
    if self.event:
        text = self.event.getEventName()
        short = self.event.getShortDescription()
        ext = self.event.getExtendedDescription()
        if short and short != text:
            text += '\n\n' + short
        if ext:
            if text:
                text += '\n\n'
            text += ext
        self.session.open(translatorMain, text)


def main(session, **kwargs):
    session.open(translatorMain, None)
    return


def mainyoutube(session, **kwargs):
    session.open(YouTubeMain)


def Plugins(**kwargs):
    return [PluginDescriptor(name='EPG Translator', description='Translate your EPG', where=[PluginDescriptor.WHERE_PLUGINMENU], icon='plugin.png', fnc=main),
     PluginDescriptor(name='EPG Translator', description='Translate your EPG', where=[PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main),
     PluginDescriptor(name='EPG Translator', description='Translate your EPG', where=[PluginDescriptor.WHERE_EVENTINFO], fnc=main),
     PluginDescriptor(name='EPG YouTube Trailer', description='Search YouTube EPG Trailer', where=[PluginDescriptor.WHERE_PLUGINMENU], icon='youtube.png', fnc=mainyoutube),
     PluginDescriptor(name='EPG YouTube Trailer', description='Search YouTube EPG Trailer', where=[PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=mainyoutube),
     PluginDescriptor(name='EPG YouTube Trailer', description='Search YouTube EPG Trailer', where=[PluginDescriptor.WHERE_EVENTINFO], fnc=mainyoutube),
     PluginDescriptor(name='EPG YouTube Trailer', description='Search YouTube EPG Trailer', where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=autostart)]
