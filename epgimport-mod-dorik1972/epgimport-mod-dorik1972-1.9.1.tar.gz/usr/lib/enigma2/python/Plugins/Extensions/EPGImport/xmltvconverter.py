# -*- coding: utf-8 -*-
#
# The code is completely modified and optimized by Dorik1972
#
from __future__ import print_function, division
import calendar, time
from . import log, isDreamOS
import re
from Components.Language import language
from Components.config import config
from .EPGConfig import xml_unescape, enumerateXML
from .EPGImport import ISO639_associations

LANG = language.getLanguage()[:2]
PATTERN = re.compile(r'\s+(?=(?:[,.?!:;…]))')
EVENTCOUNTER = 0

class Timer(object):
	def __enter__(self):
		global EVENTCOUNTER
		self.start = time.time()
		EVENTCOUNTER = 0
		return self
	def __exit__(self, *args):
		elapsed = time.time()-self.start
		print('Processed {} events in {} or ~{:.0f} per second'.format(EVENTCOUNTER, time.strftime("%H:%M:%S", time.gmtime(elapsed)), EVENTCOUNTER/elapsed), file=log)

class XMLTVConverter(object):
	def __init__(self, channels_dict, dateformat='%Y%m%d%H%M%S %Z'):
		self.channels = channels_dict
		self.dateParser = lambda x: time.struct_time(tuple(map(int, (x[:4], x[4:6], x[6:8], x[8:10], x[10:], 0, -1, -1, 0)))) if dateformat.startswith('%Y%m%d%H%M%S') else time.strptime(x, dateformat)

	def get_xml_string(self, elem, name):
		r = ''
		try:
			for node in elem.iter(name):
				value = node.text
				if value:
					value = xml_unescape(value)
					if LANG == node.get('lang', None):   #Priority is given to the Enigma2 interface language
						r = value
						break
					elif not r:
						r = value
		except Exception as e:
			print("[XMLTVConverter] get_xml_string error:", e)

		# Now returning UTF-8 by default and normalizing pinning marks, the epgdat/oudeis must be adjusted to make this work.
		return PATTERN.sub('', r) if r else ''

	def get_timestamp_utc(self, xmltv_date):
		try:
			if xmltv_date:
				return calendar.timegm(self.dateParser(xmltv_date[:12])) - ((3600 * int(xmltv_date[-5:]) // 100) if len(xmltv_date)>14 else 0)
			else:
				raise
		except Exception as e:
			print("[XMLTVConverter] get_time_utc error:", e)
			return 0

	def enumFile(self, fileobj):
		global EVENTCOUNTER
		if not self.channels:
			print("[XMLTVConverter] There is nothing no enumerate. There are no channels loaded", file=log)
			return
		histseconds = 10800  # 3 hours
		try:
			histseconds = int(config.epg.histminutes.value) * 60
		except:
			if isDreamOS:
				try:
					histseconds = int(config.misc.epgcache_outdated_timespan.value) * 3600
				except:
					pass

		now_timestamp_utc = int(time.time()) - histseconds
		print("[XMLTVConverter] Enumerating XMLTV event information", file=log)
		print("[XMLTVConverter] Keep outdated EPG set to: %s" % time.strftime("%H:%M:%S", time.gmtime(histseconds)), file=log)
		with Timer() as timer:
			for elem in enumerateXML(fileobj, 'programme'):
				EVENTCOUNTER+=1
				try:
					data_tuple = None
					channel = xml_unescape(elem.get('channel', '').lower())
					if channel in self.channels:
						t = [ self.get_timestamp_utc(elem.get(x, '').strip()) for x in ('start', 'stop') ]
						if all(t) and (now_timestamp_utc <= t[1] >= t[0]):
							l = [ self.get_xml_string(elem, x) for x in ('title', 'sub-title', 'desc') ] + [0]
							if l[1]: l[1] += '\n'
							if isDreamOS:
								l.append(ISO639_associations.get(LANG, 'eng'))
							t[1] -= t[0]
							data_tuple = (self.channels[channel], tuple(t+l))
				except Exception as e:
					print("[XMLTVConverter] parsing event error:", e)
				finally:
					# here we get a tuple of tuples ;) or None
					# return a None object to give up time to the reactor.
					# 1. start time (long)
					# 2. duration (int)
					# 3. event title (string)
					# 4. short description (string)
					# 5. extended description (string)
					# 6. event type (byte)
					# 7. ISO639_2 three-letter abbreviation langguage code (string)  !!! For DreamOS onnly !!!
					t = int(time.time()) - histseconds
					if t - now_timestamp_utc >= 10:
						print("[XMLTVConverter] Processed: %s events" % EVENTCOUNTER, file=log)
						now_timestamp_utc = t

					yield data_tuple
