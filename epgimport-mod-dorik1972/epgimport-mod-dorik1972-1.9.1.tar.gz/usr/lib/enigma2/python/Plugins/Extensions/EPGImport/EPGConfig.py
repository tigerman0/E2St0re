# -*- coding: utf-8 -*-
#
# The code is completely modified and optimized by Dorik1972
#
from __future__ import print_function
import os, sys, glob, zipfile
import gzip, time, random, re
from . import log, isDreamOS
try:
	from xml.etree.cElementTree import iterparse
except ImportError:
	from xml.etree.ElementTree import iterparse
from xml.sax.saxutils import unescape
from collections import defaultdict
try:
	import cPickle as pickle
except ImportError:
	import pickle

PY3 = (sys.version_info[0] == 3)
try:
	from backports import lzma
except ImportError:
	try:
		import lzma
	except ImportError:
		import subprocess
		try:
			subprocess.call(["apt" if isDreamOS else "opkg", "install", "python3-lzma" if PY3 else "python-lzma"])
			import lzma
		except:
			subprocess.call(["apt" if isDreamOS else "opkg", "install", "python3-backports-lzma" if PY3 else "python-backports-lzma"])
			from backports import lzma
if PY3:
	from urllib.parse import urlparse
	from io import BytesIO
else:
	from urlparse import urlparse
	from StringIO import StringIO as BytesIO

# User selection stored here
SETTINGS_FILE = '/etc/epgimport/epgimport.conf'
channelCache = {}

def isLocalFile(filename):
	url_parsed = urlparse(filename)
	if url_parsed.scheme in ('file', ''): # Possibly a local file
		return os.path.exists(url_parsed.path)
	return False

def xml_unescape(text):
	"""
	:param text: The text that needs to be unescaped.
	:type text: str
	:rtype: str
	"""
	return re.sub(r'&#160;|&nbsp;|\s+', ' ', unescape((text if PY3 else text.encode('utf-8')).strip(),
						entities={
								"&laquo;": "«",
								"&#171;": "«",
								"&raquo;": "»",
								"&#187;": "»",
								"&apos;": "'",
							})
				) if isinstance(text, str if PY3 else basestring) else ''


def getChannels(path, name=None):
	global channelCache
	if name in channelCache:
		return channelCache[name]
	dirname, filename = os.path.split(path)
	if name:
		channelfile = os.path.join(dirname, name) if isLocalFile(name) else name
	else:
		channelfile = os.path.join(dirname, filename.split('.', 1)[0] + '.channels.xml')
	try:
		return channelCache[channelfile]
	except KeyError:
		channelCache[channelfile] = EPGChannel(channelfile)
		return channelCache[channelfile]

def getFiletype(fp):
	"""
	Attempts to detect file or file like object format from the content by reading the first 10 bytes.
	Returns None if no format could be detected.
	https://en.wikipedia.org/wiki/List_of_file_signatures
	"""
	if hasattr(fp, 'seek'):
		bs = fp.read(10)
		fp.seek(0, 0)
	else:
		with open(fp, "rb") as f:
			bs = f.read(10)

	if bs[:2] == b"\x1f\x8b":
		return "GZ"
	elif bs[:6] == b"\xfd\x37\x7a\x58\x5a\x00":
		return "XZ"
	elif bs[:4] == b"\x50\x4b\x03\x04":
		return "ZIP"
	elif bs[:6] == b"\x3c\x3f\x78\x6d\x6c\x20":
		return "XML"
	elif bs[:9] == b"\xef\xbb\xbf\x3c\x3f\x78\x6d\x6c\x20":
		return "XML"  # utf-8-bom
	return None

def openStream(filename):
	try:
		if not os.path.getsize(filename):
			raise Exception("EPGConfig] %s file is empty" % filename)
	except Exception as e:
		raise Exception("[EPGConfig] Unexpected error occurred with file: %s" % filename)

	ftype = getFiletype(filename)
	try:
		if ftype == 'GZ':
			fd = gzip.open(filename, 'rb')
		elif ftype == 'XZ':
			fd = lzma.open(filename, 'rb')
		elif ftype == 'ZIP':
			zip_obj = zipfile.ZipFile(filename, 'r')
			fd = BytesIO(zip_obj.open(zip_obj.namelist()[0]).read())
		elif ftype == 'XML':
			fd = open(filename, 'rb')
		else:
			raise KeyError(ftype)
	except KeyError:
		raise("[EPGConfig] unsupported file type: %s" % filename)
	except Exception:
		raise Exception("[EPGConfig] file %s is not a valid %s" % (filename, ftype))

	if ftype != 'XML' and getFiletype(fd) != 'XML':
		raise Exception("[EPGConfig] %s file is not a valid XML" % filename)
	else:
		return fd

def enumerateXML(fp, tag=None):
	"""Enumerates ElementTree nodes from file object 'fp'"""
	doc = iterparse(fp, events=('start', 'end'))
	_, root = next(doc)
	depth = 0
	for event, element in doc:
		if element.tag == tag:
			if event == 'start':
				depth += 1
			else:
				depth -= 1
				if depth == 0:
					yield element
					element.clear()
		if event == 'end' and element.tag != tag:
			root.clear()

class EPGChannel(object):
	def __init__(self, filename, urls=None):
		self.mtime = None
		self.name = filename
		self.urls = [filename] if urls is None else urls
		self.items = defaultdict(set)

	def parse(self, filterCallback, downloadedFile):
		""" parse  *****_cahnnels.xml lookup table file """
		print("[EPGConfig] Enumerating channels lookup table XML file", file=log)
		self.items = defaultdict(set) # set make the reference unique to avoid loading twice the same EPG data.
		count = 0
		try:
			for elem in enumerateXML(openStream(downloadedFile), 'channel'):
				count += 1
				id, ref = list(map(xml_unescape, [elem.get('id').lower(), elem.text]))
				if id and ref and filterCallback(ref):
					self.items[id].add(ref)

			print("[EPGConfig] Processed: %s channels" % count, file=log)
		except Exception as e:
			print("[EPGConfig] failed to parse", self.name, "Error:", e, file=log)
		else:
			print("[EPGConfig] Formed lookup table for: %s channels id" % len(self.items), file=log)

	def update(self, filterCallback, downloadedFile=None):
		if downloadedFile is not None:
			self.mtime = time.time()
			return self.parse(filterCallback, downloadedFile)
		elif len(self.urls) == 1 and isLocalFile(self.urls[0]):
			mtime = os.path.getmtime(self.urls[0])
			if (not self.mtime) or (self.mtime < mtime):
				self.parse(filterCallback, self.urls[0])
				self.mtime = mtime

	def downloadables(self):
		if not (len(self.urls) == 1 and isLocalFile(self.urls[0])):
			# Check at most once a day
			now = time.time()
			if (not self.mtime) or (time.time() - self.mtime <= 86400):
				return self.urls
		return []

	def __repr__(self):
		return "EPGChannel(urls=%s, channels=%s, mtime=%s)" % (self.urls, self.items and len(self.items), self.mtime)


class EPGSource(object):
	def __init__(self, path, elem, category=None):
		self.parser = elem.get('type', 'gen_xmltv')
		self.nocheck = int(elem.get('nocheck', 0))
		self.urls = [xml_unescape(e.text) for e in elem.findall('url')]
		self.url = random.choice(self.urls)
		self.description = xml_unescape(elem.findtext('description', self.url))
		self.category = category
		self.format = elem.get('format', 'xml')
		self.channels = getChannels(path, elem.get('channels'))


def enumSourcesFile(sourcefile, filter=None, categories=False):
	""" parse  /etc/epgimport/*****.sources.xml|.gz|.xz|.zip """
	global channelCache
	category = None
	try:
		for event, elem in iterparse(openStream(sourcefile), events=("start", "end")):
			if event == 'end':
				if elem.tag == 'source':
					s = EPGSource(sourcefile, elem, category)
					elem.clear()
					if (filter is None) or (s.description in filter):
						yield s
				elif elem.tag == 'channel':
					name = xml_unescape(elem.get('name'))
					urls = [xml_unescape(e.text) for e in elem.findall('url')]
					try:
						channelCache[name].urls = urls
					except:
						channelCache[name] = EPGChannel(name, urls)
				elif elem.tag == 'sourcecat':
					category = None
			elif event == 'start':
				# Need the category name sooner than the contents, hence "start"
				if elem.tag == 'sourcecat':
					category = xml_unescape(elem.get('sourcecatname'))
					if categories:
						yield category
	except Exception as e:
		print("[EPGConfig] EPGConfig enumSourcesFile Error:", e, file=log)

def enumSources(path, filter=None, categories=False):
	try:
		for file in glob.iglob(os.path.join(path, '*.sources.*')):
			for s in enumSourcesFile(file, filter, categories):
				yield s
	except Exception as e:
		print("[EPGConfig] EPGConfig enumSources Error:", e, file=log)

def loadUserSettings(filename=SETTINGS_FILE):
	try:
		return pickle.load(open(filename, 'rb'))
	except Exception as e:
		print("[EPGConfig] No settings", e, file=log)
		return {"sources": []}

def storeUserSettings(filename=SETTINGS_FILE, sources=[]):
	container = {"sources": sources}
	pickle.dump(container, open(filename, 'wb'), pickle.HIGHEST_PROTOCOL)
