# -*- coding: utf-8 -*-
#
# This file no longer has a direct link to Enigma2, allowing its use anywhere
# you can supply a similar interface. See plugin.py and OfflineImport.py for
# the contract.
#
#
# The code is completely modified and optimized by Dorik1972
#

from __future__ import print_function
import os, time, random
from datetime import datetime
from .EPGConfig import isLocalFile, PY3, openStream
from . import log, isDreamOS
from twisted.internet import reactor, threads, ssl, _sslverify
from twisted.web.client import Agent, BrowserLikeRedirectAgent, readBody, HTTPConnectionPool
if isDreamOS:
	from enigma import cachestate
try:
	from twisted.web.client import BrowserLikePolicyForHTTPS as IgnoreHTTPSContextFactory
except:
	# for twisted < 14 backward compatibility
	from twisted.web.client import WebClientContextFactory as IgnoreHTTPSContextFactory
from twisted.internet.defer import setDebugging
from twisted.web.http_headers import Headers
import twisted.python.runtime
try:
	import lzma
except ImportError:
	from backports import lzma

class IgnoreHTTPS(IgnoreHTTPSContextFactory):
	def creatorForNetloc(self, hostname, port):
		options = ssl.CertificateOptions(verify=False)
		return _sslverify.ClientTLSOptions(hostname if PY3 else hostname.encode('utf-8'), options.getContext())

setDebugging(False)
HDD_EPG_DAT = "/etc/enigma2/epg.dat"
ISO639_associations = {}
headers = Headers({'User-Agent': ['Mozilla/5.0 (SmartHub; SMART-TV; U; Linux/SmartTV; Maple2012) AppleWebKit/534.7 (KHTML, like Gecko) SmartTV Safari/534.7']})
# Use a persistent connection pool.
pool = HTTPConnectionPool(reactor, persistent=True)
pool.maxPersistentPerHost = 1
pool.cachedConnectionTimeout = 600
agent = BrowserLikeRedirectAgent(Agent(reactor, pool=pool, contextFactory=IgnoreHTTPS()))
# Used to check server validity
date_format = "%Y-%m-%d"
now = datetime.now()
alloweddelta = 2
CheckFile = "LastUpdate.txt"

PARSERS = {
	'xmltv': 'gen_xmltv',
	'gen_xmltv': 'gen_xmltv',
	}

def completed(passthrough):
	if timeoutCall.active():
		timeoutCall.cancel()
	return passthrough

def doRead(response):
	d = readBody(response)
	d.addCallback(getISO639)

def getISO639(text):
	for l in text.decode('UTF-8').split('\n'):
		l = l.split('|')
		if l[2]: ISO639_associations[l[2]] = l[0]

d = agent.request(b'GET', b'http://loc.gov/standards/iso639-2/ISO-639-2_utf-8.txt', headers, None)
d.addCallback(doRead).addErrback(lambda e: print("[EPGImport] Failed to load ISO639 codes: %s" % e))
#set a 3 min timeout for all request. If unsuccessfull then call the errback
timeoutCall = reactor.callLater(3*60, d.cancel)
d.addBoth(completed)


def getParser(name):
	name = PARSERS.get(name, name)
	return getattr(__import__(__name__[:__name__.rfind('.')+1] + name, fromlist=[None]), name)

def bigStorage(minFree, default, *candidates):

	def free_space_available(dirname):
		try:
			st = os.statvfs(dirname)
			return st.f_bavail * st.f_frsize
		except:
			return 0

	candidates = list(filter(os.path.isdir, candidates))
	candidates.append(default)
	try:
		candidate = sorted(candidates, key=lambda x: free_space_available(x), reverse=True)[0]
		free = free_space_available(candidate)
		if (free > minFree) or (free > free_space_available(default)):
			return candidate
		raise Exception("Free space is critically small")
	except Exception as e:
		print("[EPGImport] An error occurred in bigStorage detection:", repr(e), file=log)
		return default


class OudeisImporter(object):
	'Wrapper to convert original patch to new one that accepts multiple services'
	def __init__(self, epgcache):
		self.epgcache = epgcache
	# difference with old patch is that services is a list or tuple, this
	# wrapper works around it.
	def importEvents(self, services, events):
		for service in services:
			self.epgcache.importEvent(service, events)

def unlink_if_exists(filename):
	try:
		os.unlink(filename)
	except Exception as e:
		print("[EPGImport] warning: Could not remove '%s' intermediate" % filename, repr(e), file=log)


class EPGImport(object):
	"""Simple Class to import EPGData"""

	def __init__(self, epgcache, channelFilter):
		self.eventCount = None
		self.startTime = None
		self.storage = None
		self.sources = []
		self.source = None
		self.fd = None
		self.iterator = None
		self.onDone = None
		self.epgcache = epgcache
		self.channelFilter = channelFilter

	def cacheStateChanged(self, state):
		#  0 = started, 1 = stopped, 2 = aborted, 3 = deferred, 4 = load_finished, 5 = save_finished 
		if state.state == cachestate.save_finished:
			print("[EPGImport] EPGCache save finished")
			self.nextImport()
		elif state.state == cachestate.load_finished:
			print("[EPGImport] EPGCache load finished")
			print("[EPGImport] #### Finished ####", file=log) 
			del self.cacheState_conn

	def saveEPGCache(self):
		if isDreamOS:
			self.cacheState_conn = self.epgcache.cacheState.connect(self.cacheStateChanged)
		print("[EPGImport] Save the EPGchache to database file %s ..." % HDD_EPG_DAT, file=log)
		self.epgcache.save()

	def beginImport(self, longDescUntil=None):
		'''Starts importing using Enigma reactor. Set self.sources before calling this.'''
		# default to 7 days ahead
		self.longDescUntil = time.time() + 24 * 3600 * 7 if longDescUntil is None else longDescUntil
		self.eventCount = 0                                                                                                     
		self.startTime = datetime.now()
		if hasattr(self.epgcache, 'importEvents'):
			self.storage = self.epgcache
		elif hasattr(self.epgcache, 'importEvent'):
			self.storage = OudeisImporter(self.epgcache)
		elif hasattr(self.epgcache, 'load'):
			print("[EPGImport] Oudeis patch not detected, using eEPGCache.load")
			import epgdat_importer
			self.storage = epgdat_importer.epgdatclass()
			if isDreamOS:
				self.saveEPGCache()
				return
		else:
			print("[EPGImport] No supported EPG import methods found. EPG import not possible", file=log)
			return
		self.nextImport()

	def nextImport(self):
		self.closeReader()
		try:
			self.source = self.sources.pop()
		except:
			self.closeImport()
			return
		else:
			print('[EPGImport] ### start import, source = "%s"' % self.source.description)
			self.fetchUrl(self.source.url)

	def fetchUrl(self, filename):
		if isLocalFile(filename):
			print("[EPGImport] Local file used: %s" % filename, file=log)
			self.afterDownload(None, filename, deleteFile=False)
		else:
			self.do_download(filename, self.afterDownload, self.downloadFail)

	def createIterator(self, filename):
		self.source.channels.update(self.channelFilter, filename)
		return getParser(self.source.parser).iterator(self.fd, self.source.channels.items)

	def readEpgDatFile(self, filename, deleteFile=False):
		if not hasattr(self.epgcache, 'load'):
			print("[EPGImport] Cannot load EPG.DAT files on unpatched enigma, eEPGCache.load required", file=log)
			return
		unlink_if_exists(HDD_EPG_DAT)
		try:
			fd = openStream(filename)
			import shutil
			with fd as fsrc, open(HDD_EPG_DAT, 'wb') as fdst:
				shutil.copyfileobj(fsrc, fdst)
			print("[EPGImport] Importing", HDD_EPG_DAT, file=log)
			self.epgcache.load()
			if deleteFile:
				unlink_if_exists(filename)
		except Exception as e:
			print("[EPGImport] Failed to import %s:" % filename, repr(e), file=log)

	def afterDownload(self, result, filename, deleteFile=False):
		print("[EPGImport] afterDownload", filename, file=log)

		if self.source.parser == 'epg.dat':
			if twisted.python.runtime.platform.supportsThreads():
				print("[EPGImport] Using twisted thread for DAT file", file=log)
				threads.deferToThread(self.readEpgDatFile, filename, deleteFile).addCallback(lambda ignore: self.nextImport())
			else:
				self.readEpgDatFile(filename, deleteFile)
				return
		try:
			self.fd = openStream(filename)
		except Exception as e:
			self.downloadFail("%s" % repr(e))
			return

		if deleteFile and self.source.parser != 'epg.dat':
			print("[EPGImport] unlink", filename, file=log)
			unlink_if_exists(filename)

		self.channelFiles = self.source.channels.downloadables()
		if not self.channelFiles:
			self.afterChannelDownload(None, None, deleteFile=False)
		else:
			filename = self.channelFiles.pop()
			self.do_download(filename, self.afterChannelDownload, self.channelDownloadFail)

	def afterChannelDownload(self, result, filename, deleteFile=True):
		print("[EPGImport] afterChannelDownload", filename, file=log)
		if filename is not None:
			try:
				if not os.path.getsize(filename):
					raise Exception("File is empty")
			except Exception as e:
				self.channelDownloadFail(repr(e))
				return

		if twisted.python.runtime.platform.supportsThreads():
			print("[EPGImport] ### using twisted thread, yay!", file=log)
			threads.deferToThread(self.doThreadRead, filename).addCallback(lambda ignore: self.nextImport())
			deleteFile = False
		else:
			print("[EPGImport] ### twisted thread not supported, sadly :(", file=log)
			self.iterator = self.createIterator(filename)
			reactor.addReader(self)

		if deleteFile and filename is not None:
			unlink_if_exists(filename)

	def fileno(self):
		if self.fd is not None:
			return self.fd.fileno()

	def importEvents(self, data):
		if data is not None:
			self.eventCount += 1
			try:
				r, d = data
				# Remove long description (save RAM memory)
				self.storage.importEvents(list(r), (d[:4] + ('',) + d[5:] if d[0] > self.longDescUntil else d,))
			except Exception as e:
				print("[EPGImport] ### importEvents exception:", repr(e), file=log)

	def doThreadRead(self, filename):
		'This is used on PLi with threading'
		for data in self.createIterator(filename):
			self.importEvents(data)
		print('### thread finished, source = "%s", events imported: %s' % (self.source.description, self.eventCount), file=log)
		if filename is not None:
			unlink_if_exists(filename)

	def doRead(self):
		'called from reactor to read some data'
		try:
			# returns tuple (ref, data) or None when nothing available yet.
			data = self.iterator.__next__() if PY3 else self.iterator.next()
			self.importEvents(data)
		except StopIteration:
			print('[EPGImport] ### iterator finished, source = "%s", events imported: %s' % (self.source.description, self.eventCount))
			self.nextImport()

	def connectionLost(self, failure):
		'called from reactor on lost connection'
		# This happens because enigma calls us after removeReader
		print("[EPGImport] connectionLost", failure, file=log)

	def channelDownloadFail(self, failure):
		print("[EPGImport] download channel failed:", failure, file=log)
		if self.channelFiles:
			filename = self.channelFiles.pop()
			self.do_download(filename, self.afterChannelDownload, self.channelDownloadFail)
		else:
			print("[EPGImport] no more alternatives for channels", file=log)
			self.nextImport()

	def downloadFail(self, failure):
		print("[EPGImport] download failed:", failure, file=log)
		self.source.urls.remove(self.source.url)
		if self.source.urls:
			print("[EPGImport] Attempting alternative URL", file=log)
			self.source.url = random.choice(self.source.urls)
			self.fetchUrl(self.source.url)
		else:
			self.nextImport()

	def logPrefix(self):
		return '[EPGImport]'

	def closeReader(self):
		if self.fd is not None:
			reactor.removeReader(self)
			self.fd.close()
			self.fd = None
			self.iterator = None

	def closeImport(self):
		self.iterator = None
		self.source = None
		if hasattr(self.storage, 'epgfile'):
			needLoad = self.storage.epgfile
		else:
			needLoad = None
		self.storage = None
		if self.eventCount is not None:
			reboot = False
			if needLoad:
				if isDreamOS:
					if hasattr(self.epgcache, 'createUpdateTriggers'):
						print("[EPGImport] EPG cache time updated ...", file=log)
						self.epgcache.createUpdateTriggers()
					if hasattr(self.epgcache, 'load'):
						print("[EPGImport] Load the database file %s to EPG cache ..." % needLoad, file=log)
						self.epgcache.load()
				else:
					reboot = True
					try:
						if needLoad != HDD_EPG_DAT:
							os.symlink(needLoad, HDD_EPG_DAT)
						print("[EPGImport] eEPGCache.load() importing: %s" % HDD_EPG_DAT, file=log)
						self.epgcache.load()
						reboot = False
						unlink_if_exists(needLoad)
					except Exception as e:
						print("[EPGImport] eEPGCache.load() failed: ", repr(e), file=log)

			if hasattr(self.epgcache, 'save') and not (isDreamOS or needLoad):
				self.saveEPGCache()
			if hasattr(self.epgcache, 'timeUpdated'):
				print("[EPGImport] EPG cache time updated ...", file=log)
				self.epgcache.timeUpdated()
			if self.onDone:
				self.onDone(reboot=reboot, epgfile=needLoad)

		print("[EPGImport] Total imported %d events per %s" % (self.eventCount, (datetime.now()-self.startTime)), file=log) 

		self.eventCount = None
		if not isDreamOS:
			print("[EPGImport] #### Finished ####", file=log)

	def isImportRunning(self):
		return self.source is not None

	def do_download(self, sourcefile, afterDownload, downloadFail):
		global timeoutCall
		scheme = sourcefile.split('/')[0]
		if scheme not in ('http:', 'https:', 'ftp:', 'file:'):
			self.downloadFail("Unsupported scheme: %s" % scheme)
			return
		path = bigStorage(9000000, '/tmp', '/media/cf', '/media/mmc', '/media/usb', '/media/hdd')
		filename = os.path.join(path, 'epgimport.tmp')
		dirname, _ = os.path.split(sourcefile)
		print("[EPGImport] Downloading: %s to local path: %s" % (sourcefile, filename), file=log)
		if self.source.nocheck == 1:
			print("[EPGImport] Not checking the server since nocheck is set for: %s" % sourcefile, file=log)
			d = agent.request(b'GET', sourcefile.encode('utf-8'), headers, None)
			d.addCallback(self.getContent, filename, afterDownload, downloadFail)
		else:
			print("[EPGImport] checkValidServer server url: %s" % sourcefile, file=log)
			FullString = dirname + "/" + CheckFile
			d = agent.request(b'GET', FullString.encode('utf-8'), headers, None)
			d.addCallback(self.getContent, dirname, sourcefile, filename, afterDownload, downloadFail)

		d.addErrback(lambda e: downloadFail(repr(e)))
		#set a 3 min timeout for all request. If unsuccessfull then call the errback
		timeoutCall = reactor.callLater(3*60, d.cancel)
		d.addBoth(completed)

	def getContent(self, response, *args):
		if response.code !=200:
			raise Exception("Invalid server response code received: %s" % response.code)
		d = readBody(response)
		d.addCallback(self.writeFile if len(args) < 4 else self.checkValidServer, *args)
		d.addErrback(lambda e: args[-1](repr(e)))
		return d

	def writeFile(self, data, filename, afterDownload, downloadFail):
		try:
			with open(filename, 'wb') as fd:
				fd.write(data)
		except Exception as e:
			raise Exception("unable write data to %s: %s" % (filename, repr(e)))
		else:
			afterDownload(None, filename, True)

	def checkValidServer(self, LastTime, dirname, sourcefile, filename, afterDownload, downloadFail):
		try:
			FileDate = datetime.strptime(LastTime.decode('utf-8').strip('\n'), date_format)
		except ValueError:
			raise Exception("checkValidServer: wrong date format in LastUpdate.txt. Rejecting server: %s" % dirname)
		else:
			delta = (now - FileDate).days
			if delta <= alloweddelta:
				# OK the delta is in the foreseen windows
				print("[EPGImport] checkValidServer accept server: %s" % dirname, file=log)
				d = agent.request(b'GET', sourcefile.encode('utf-8'), headers, None)
				d.addCallback(self.getContent, filename, afterDownload, downloadFail)
				self.source.nocheck = 1
				return d
			else:
				# Sorry the delta is too small removing this site
				raise Exception("checkValidServer: invalid delta days. Rejecting server: %s" % dirname)
