# -*- coding: utf-8 -*-

# New Permanent Clock

# Mod by Evg77734 2023

from Components.config import config, ConfigInteger, ConfigSubsection, ConfigYesNo
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
from enigma import ePoint, eTimer, getDesktop
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Screens.Screen import Screen
from threading import Thread
from .screens.myskin import *
from os import environ
import time
import sys
import os

global digits
digits = 1

version = '1.0'

xy = 5

config.plugins.NewPermanentClock = ConfigSubsection()
config.plugins.NewPermanentClock.enabled = ConfigYesNo(default=False)
config.plugins.NewPermanentClock.position_x = ConfigInteger(default=50)
config.plugins.NewPermanentClock.position_y = ConfigInteger(default=50)

SKIN = FHDNewPermanentClock2

class NewPermanentClockScreen(Screen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skin = SKIN

		self["pic6"] = Pixmap()
		self["pic5"] = Pixmap()
		self["pic4"] = Pixmap()
		self["pic3"] = Pixmap()
		self["pic2"] = Pixmap()
		self["pic1"] = Pixmap()
		self["points"] = Pixmap()
		self["points1"] = Pixmap()

		self.onShow.append(self.movePosition)

		Thread8 = Thread(target=self.mypic8)
		Thread8.start()

	def mypic8(self):
		self.moveTimer8 = eTimer()
		self.moveTimer8.callback.append(self.movePosition8)
		self.moveTimer8.start(10, 1)

	def movePosition8(self):
		global digits
		self.moveTimer8.start(1000, 1)
		s0 =  time.strftime('%S', time.localtime(time.time()))
		s = str(s0)
		if len(s) > 0:
			s1 = s[0]
			s2 = s[1]
			self["pic5"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/" + str(s1) + ".png")
			self["pic5"].instance.show()
			self["pic6"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/" + str(s2) + ".png")
			self["pic6"].instance.show()
		else:
			s1 = '0'
			s2 = s[0]
			self["pic5"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/" + str(s1) + ".png")
			self["pic5"].instance.show()
			self["pic6"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/" + str(s2) + ".png")
			self["pic6"].instance.show()
		#---------------------------------------------------------------
		m0 =  time.strftime('%M', time.localtime(time.time()))
		m = str(m0)
		if len(m) > 0:
			s1 = m[0]
			s2 = m[1]
			self["pic3"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/" + str(s1) + ".png")
			self["pic3"].instance.show()
			self["pic4"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/" + str(s2) + ".png")
			self["pic4"].instance.show()
		else:
			s1 = '0'
			s2 = m[0]
			self["pic3"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/" + str(s1) + ".png")
			self["pic3"].instance.show()
			self["pic4"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/" + str(s2) + ".png")
			self["pic4"].instance.show()
		#---------------------------------------------------------------
		h0 =  time.strftime('%H', time.localtime(time.time()))
		h = str(h0)
		if len(h) > 0:
			s1 = h[0]
			s2 = h[1]
			self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/" + str(s1) + ".png")
			self["pic1"].instance.show()
			self["pic2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/" + str(s2) + ".png")
			self["pic2"].instance.show()
		else:
			s1 = '0'
			s2 = h[0]
			self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/" + str(s1) + ".png")
			self["pic1"].instance.show()
			self["pic2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/" + str(s2) + ".png")
			self["pic2"].instance.show()
		#---------------------------------------------------------------

	def movePosition(self):
		global digits
		self["pic6"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/8.png")
		self["pic6"].instance.show()
		self["pic5"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/8.png")
		self["pic5"].instance.show()
		self["pic4"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/8.png")
		self["pic4"].instance.show()
		self["pic3"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/8.png")
		self["pic3"].instance.show()
		self["pic2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/8.png")
		self["pic2"].instance.show()
		self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/8.png")
		self["pic1"].instance.show()
		self["points"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/points.png")
		self["points"].instance.show()
		self["points1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/points.png")
		self["points1"].instance.show()

		if self.instance:
			self.instance.move(ePoint(config.plugins.NewPermanentClock.position_x.value, config.plugins.NewPermanentClock.position_y.value))

class NewPermanentClock():
	def __init__(self):
		self.dialog = None

	def gotSession(self, session):
		self.dialog = session.instantiateDialog(NewPermanentClockScreen)
		self.showHide()

	def changeVisibility(self):
		if config.plugins.NewPermanentClock.enabled.value:
			config.plugins.NewPermanentClock.enabled.value = False
		else:
			config.plugins.NewPermanentClock.enabled.value = True
		config.plugins.NewPermanentClock.enabled.save()
		self.showHide()

	def showHide(self):
		if config.plugins.NewPermanentClock.enabled.value:
			self.dialog.show()
		else:
			self.dialog.hide()

pInfo = NewPermanentClock()

class NewPermanentClockPositioner(Screen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skin = SKIN

		self["pic6"] = Pixmap()
		self["pic5"] = Pixmap()
		self["pic4"] = Pixmap()
		self["pic3"] = Pixmap()
		self["pic2"] = Pixmap()
		self["pic1"] = Pixmap()
		self["points"] = Pixmap()
		self["points1"] = Pixmap()

		self["actions"] = ActionMap(["WizardActions"],
		{
			"left": self.left,
			"up": self.up,
			"right": self.right,
			"down": self.down,
			"ok": self.ok,
			"back": self.exit
		}, -1)

		self.onShow.append(self.startw)

		desktop = getDesktop(0)
		self.desktopWidth = desktop.size().width()
		self.desktopHeight = desktop.size().height()

		self.moveTimer = eTimer()
		self.moveTimer.callback.append(self.movePosition)
		self.moveTimer.start(50, 1)

	def startw(self):
		global digits
		self["pic6"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/8.png")
		self["pic6"].instance.show()
		self["pic5"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/8.png")
		self["pic5"].instance.show()
		self["pic4"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/8.png")
		self["pic4"].instance.show()
		self["pic3"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/8.png")
		self["pic3"].instance.show()
		self["pic2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/8.png")
		self["pic2"].instance.show()
		self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/8.png")
		self["pic1"].instance.show()
		self["points"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/points.png")
		self["points"].instance.show()
		self["points1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/NewPermanentClock/numbers" + str(digits) + "/points.png")
		self["points1"].instance.show()

	def movePosition(self):
		self.instance.move(ePoint(config.plugins.NewPermanentClock.position_x.value, config.plugins.NewPermanentClock.position_y.value))
		self.moveTimer.start(50, 1)

	def left(self):
		value = config.plugins.NewPermanentClock.position_x.value
		value -= xy
		if value < 0:
			value = 0
		config.plugins.NewPermanentClock.position_x.value = value

	def up(self):
		value = config.plugins.NewPermanentClock.position_y.value
		value -= xy
		if value < 0:
			value = 0
		config.plugins.NewPermanentClock.position_y.value = value

	def right(self):
		value = config.plugins.NewPermanentClock.position_x.value
		value += xy
		if value > self.desktopWidth:
			value = self.desktopWidth
		config.plugins.NewPermanentClock.position_x.value = value

	def down(self):
		value = config.plugins.NewPermanentClock.position_y.value
		value += xy
		if value > self.desktopHeight:
			value = self.desktopHeight
		config.plugins.NewPermanentClock.position_y.value = value

	def ok(self):
		config.plugins.NewPermanentClock.position_x.save()
		config.plugins.NewPermanentClock.position_y.save()
		self.close()

	def exit(self):
		config.plugins.NewPermanentClock.position_x.cancel()
		config.plugins.NewPermanentClock.position_y.cancel()
		self.close()

class NewPermanentClockMenu(Screen):
	skin = """
	<screen position="650,430" size="620,220" backgroundColor="Background">
		<widget name="list" position="10,10" size="600,200" itemHeight="42" valign="center" font="Regular;32"/>
	</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)
		self.session = session
		self["list"] = MenuList([])
		self.setTitle(_('New Permanent Clock' + ' ver. ' + str(version)))
		self["actions"] = ActionMap(["OkCancelActions", "NumberActions"], {"ok": self.okClicked, "cancel": self.close, "1": self.numberPressed1, "2": self.numberPressed2, "3": self.numberPressed3}, -1)
		self.onLayoutFinish.append(self.showMenu)

	def numberPressed1(self):
		global digits
		digits = 1

	def numberPressed2(self):
		global digits
		digits = 2

	def numberPressed3(self):
		global digits
		digits = 3

	def showMenu(self):
		list = []
		if config.plugins.NewPermanentClock.enabled.value:
			list.append(_("Deactivate New Permanent Clock"))
		else:
			list.append(_("Activate New Permanent Clock"))
		list.append(_("Changing Information position"))
		self["list"].setList(list)

	def okClicked(self):
		sel = self["list"].getCurrent()
		if pInfo.dialog is None:
			pInfo.gotSession(self.session)
		if sel == _("Deactivate New Permanent Clock") or sel == _("Activate New Permanent Clock"):
			pInfo.changeVisibility()
			self.showMenu()
		else:
			pInfo.dialog.hide()
			self.session.openWithCallback(self.positionerCallback, NewPermanentClockPositioner)

	def positionerCallback(self, callback=None):
		pInfo.showHide()

def sessionstart(reason, **kwargs):
	if reason == 0:
		pInfo.gotSession(kwargs["session"])

def main(session, **kwargs):
	session.open(NewPermanentClockMenu)

def Plugins(**kwargs):
	return [
		PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart),
 	        PluginDescriptor(name=_("New Permanent Clock ver. " + version), description=_("The clock on your TV screen"), icon="info.png", where=[PluginDescriptor.WHERE_EXTENSIONSMENU, PluginDescriptor.WHERE_PLUGINMENU], fnc=main)
			]
