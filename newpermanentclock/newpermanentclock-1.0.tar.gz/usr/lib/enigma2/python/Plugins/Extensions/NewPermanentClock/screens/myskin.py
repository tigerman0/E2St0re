# Created by Evg77734 14-02-2023

FHDNewPermanentClock1 = """
<screen name="NewPermanentClock1" position="50,50" size="368,95" zPosition="1" flags="wfNoBorder" backgroundColor="transparent">
  <widget name="pic6" position="322,0" zPosition="2" size="42,72" alphatest="on"/>
  <widget name="pic5" position="264,0" zPosition="2" size="42,72" alphatest="on"/>
  <widget name="pic4" position="192,0" zPosition="2" size="42,72" alphatest="on"/>
  <widget name="pic3" position="134,0" zPosition="2" size="42,72" alphatest="on"/>
  <widget name="pic2" position="62,0" zPosition="2" size="42,72" alphatest="on"/>
  <widget name="pic1" position="4,0" zPosition="2" size="42,72" alphatest="on"/>
  <widget name="points" position="242,0" zPosition="2" size="14,72" alphatest="on"/>
  <widget name="points1" position="112,0" zPosition="2" size="14,72" alphatest="on"/>
  <widget source="session.CurrentService" backgroundColor="red" foregroundColor="white" position="4,85" zPosition="-3" render="Progress" size="360,5">
    <convert type="ServicePosition">Position</convert>
  </widget>
  <widget source="session.Event_Now" backgroundColor="red" foregroundColor="white" position="4,85" zPosition="-3" render="Progress" size="360,5">
    <convert type="EventTime">Progress</convert>
  </widget>
</screen>"""

FHDNewPermanentClock2 = """
<screen name="NewPermanentClock2" position="50,50" size="368,95" zPosition="1" flags="wfNoBorder" backgroundColor="transparent">
  <widget name="pic6" position="322,0" zPosition="2" size="42,72" alphatest="on"/>
  <widget name="pic5" position="264,0" zPosition="2" size="42,72" alphatest="on"/>
  <widget name="pic4" position="192,0" zPosition="2" size="42,72" alphatest="on"/>
  <widget name="pic3" position="134,0" zPosition="2" size="42,72" alphatest="on"/>
  <widget name="pic2" position="62,0" zPosition="2" size="42,72" alphatest="on"/>
  <widget name="pic1" position="4,0" zPosition="2" size="42,72" alphatest="on"/>
  <widget name="points" position="242,0" zPosition="2" size="14,72" alphatest="on"/>
  <widget name="points1" position="112,0" zPosition="2" size="14,72" alphatest="on"/>
</screen>"""
