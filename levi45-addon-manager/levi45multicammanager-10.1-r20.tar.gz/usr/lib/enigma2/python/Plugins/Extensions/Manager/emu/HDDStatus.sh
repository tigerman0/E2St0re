#!/bin/sh
#DESCRIPTION=This script created by Levi45\nHdd Status
hdparm -Tt /dev/ide/host0/bus0/target0/lun0/disc
