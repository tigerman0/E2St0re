# -*- coding: utf-8 -*-
#
#   Copyright (c) 2023 Billy2011 @ vuplus-support.org
#
from __future__ import absolute_import

import calendar
import datetime
import json
import os
import re
import time
import traceback

import requests
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.config import ConfigDirectory, ConfigSelection, ConfigSubsection, ConfigYesNo, config
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.Directories import fileExists, pathExists
from enigma import eDVBDB, eEPGCache, eServiceCenter, eServiceReference, eTimer, getDesktop
from twisted.internet import defer

from . import _, maybe_encode

API_BASE = "https://gizmo.rakuten.tv/v3"
EPG_URL = API_BASE + (
	"/live_channels?device_identifier=web&device_stream_audio_quality=2.0"
	"&device_stream_hdr_type=NONE&device_stream_video_quality=FHD&per_page=25"
)
CAT_URL = API_BASE + (
	"/live_channel_categories?device_identifier=web&device_stream_audio_quality=5.1"
	"&device_stream_hdr_type=NONE&device_stream_video_quality=FHD"
)
SINFO_URL = API_BASE + (
	"/avod/streamings?device_identifier=web&device_stream_audio_quality=5.1&device_stream_hdr_type=NONE"
	"&device_stream_video_quality=FHD&disable_dash_legacy_packages=false"
)
CHNINFO_URL = API_BASE + (
	"/live_channels/{0}?device_identifier=web&device_stream_audio_quality=5.1&device_stream_hdr_type=NONE"
	"&device_stream_video_quality=FHD&disable_dash_legacy_packages=false"
)
BOUQUET = "userbouquet.rakuten_tv{0}.tv"
DATA_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/RakutenTV/data/"

_regions = {
	"de": "{0}, {1}".format(_("DE"), _("Germany")),
	"it": "{0}, {1}".format(_("IT"), _("Italy")),
	"pl": "{0}, {1}".format(_("PL"), _("Poland")),
	"uk": "{0}, {1}".format(_("UK"), _("United Kingdom")),
	"es": "{0}, {1}".format(_("ES"), _("Spain")),
	"at": "{0}, {1}".format(_("AT"), _("Austria")),
	"ch": "{0}, {1}".format(_("CH"), _("Switzerland")),
	"nl": "{0}, {1}".format(_("NL"), _("Netherlands")),
	"fr": "{0}, {1}".format(_("FR"), _("France")),
	"se": "{0}, {1}".format(_("SE"), _("Sweden")),
	"dk": "{0}, {1}".format(_("DK"), _("Denmark")),
	"no": "{0}, {1}".format(_("NO"), _("Norway")),
	"fi": "{0}, {1}".format(_("FI"), _("Finland")),
	"be": "{0}, {1}".format(_("BE"), _("Belgium")),
	"cz": "{0}, {1}".format(_("CZ"), _("Czech Republic")),
	"pt": "{0}, {1}".format(_("PT"), _("Portugal")),
	"gr": "{0}, {1}".format(_("GR"), _("Greece")),
	"lu": "{0}, {1}".format(_("LU"), _("Luxembourg")),
	"ie": "{0}, {1}".format(_("IE"), _("Ireland")),
	"is": "{0}, {1}".format(_("IS"), _("Iceland")),
	"bg": "{0}, {1}".format(_("BG"), _("Bulgaria")),
	"hu": "{0}, {1}".format(_("HU"), _("Hungary")),
	"hr": "{0}, {1}".format(_("HR"), _("Croatia")),
	"si": "{0}, {1}".format(_("SI"), _("Slovenia")),
	"ro": "{0}, {1}".format(_("RO"), _("Romania")),
	"lt": "{0}, {1}".format(_("LT"), _("Lithuania")),
	"lv": "{0}, {1}".format(_("LV"), _("Latvia")),
	"ee": "{0}, {1}".format(_("EE"), _("Estonia")),
	"mt": "{0}, {1}".format(_("MT"), _("Malta")),
	"cy": "{0}, {1}".format(_("CY"), _("Cyprus")),
	"al": "{0}, {1}".format(_("AL"), _("Albania")),
	"ba": "{0}, {1}".format(_("BA"), _("Bosnia and Herzegovina")),
	"me": "{0}, {1}".format(_("ME"), _("Montenegro")),
	"mk": "{0}, {1}".format(_("MK"), _("North Macedonia")),
	"rs": "{0}, {1}".format(_("RS"), _("Serbia")),
	"sk": "{0}, {1}".format(_("SK"), _("Slovakia")),
}

REGIONS = [
	("de", "{0}".format(_regions["de"])),
	("it", "{0}".format(_regions["it"])),
	("pl", "{0}".format(_regions["pl"])),
	("uk", "{0}".format(_regions["uk"])),
	("es", "{0}".format(_regions["es"])),
	("at", "{0}".format(_regions["at"])),
	("ch", "{0}".format(_regions["ch"])),
	("nl", "{0}".format(_regions["nl"])),
	("fr", "{0}".format(_regions["fr"])),
	("se", "{0}".format(_regions["se"])),
	("dk", "{0}".format(_regions["dk"])),
	("no", "{0}".format(_regions["no"])),
	("fi", "{0}".format(_regions["fi"])),
	("be", "{0}".format(_regions["be"])),
	("cz", "{0}".format(_regions["cz"])),
	("pt", "{0}".format(_regions["pt"])),
	("gr", "{0}".format(_regions["gr"])),
	("lu", "{0}".format(_regions["lu"])),
	("ie", "{0}".format(_regions["ie"])),
	("is", "{0}".format(_regions["is"])),
	("bg", "{0}".format(_regions["bg"])),
	("hu", "{0}".format(_regions["hu"])),
	("hr", "{0}".format(_regions["hr"])),
	("si", "{0}".format(_regions["si"])),
	("ro", "{0}".format(_regions["ro"])),
	("lt", "{0}".format(_regions["lt"])),
	("lv", "{0}".format(_regions["lv"])),
	("ee", "{0}".format(_regions["ee"])),
	("mt", "{0}".format(_regions["mt"])),
	("cy", "{0}".format(_regions["cy"])),
	("al", "{0}".format(_regions["al"])),
	("ba", "{0}".format(_regions["ba"])),
	("me", "{0}".format(_regions["me"])),
	("mk", "{0}".format(_regions["mk"])),
	("rs", "{0}".format(_regions["rs"])),
	("sk", "{0}".format(_regions["sk"])),
]
REGIONS.sort()

CH_REGIONS = REGIONS + [("none", _("NONE"))]

region_params = {
	"de": {
		"classification_id": "307",
		"locale": "de",
		"market_code": "de",
	},
	"it": {
		"classification_id": "36",
		"locale": "it",
		"market_code": "it",
	},
	"pl": {
		"classification_id": "277",
		"locale": "pl",
		"market_code": "pl",
	},
	"uk": {
		"classification_id": "18",
		"locale": "en",
		"market_code": "uk",
	},
	"es": {
		"classification_id": "5",
		"locale": "es",
		"market_code": "es",
	},
	"at": {
		"classification_id": "300",
		"locale": "de",
		"market_code": "at",
	},
	"ch": {
		"classification_id": "319",
		"locale": "de",
		"market_code": "ch",
	},
	"nl": {
		"classification_id": "69",
		"locale": "nl",
		"market_code": "nl",
	},
	"fr": {
		"classification_id": "23",
		"locale": "fr",
		"market_code": "fr",
	},
	"se": {
		"classification_id": "282",
		"locale": "sv",
		"market_code": "se",
	},
	"dk": {
		"classification_id": "283",
		"locale": "da",
		"market_code": "dk",
	},
	"no": {
		"classification_id": "286",
		"locale": "nb",
		"market_code": "no",
	},
	"fi": {
		"classification_id": "284",
		"locale": "fi",
		"market_code": "fi",
	},
	"be": {
		"classification_id": "308",
		"locale": "fr",
		"market_code": "be",
	},
	"cz": {
		"classification_id": "272",
		"locale": "cs",
		"market_code": "cz",
	},
	"pt": {
		"classification_id": "64",
		"locale": "pt",
		"market_code": "pt",
	},
	"gr": {
		"classification_id": "279",
		"locale": "en",
		"market_code": "gr",
	},
	"lu": {
		"classification_id": "74",
		"locale": "fr",
		"market_code": "lu",
	},
	"ie": {
		"classification_id": "41",
		"locale": "en",
		"market_code": "ie",
	},
	"is": {
		"classification_id": "287",
		"locale": "en",
		"market_code": "is",
	},
	"bg": {
		"classification_id": "269",
		"locale": "bg",
		"market_code": "bg",
	},
	"hu": {
		"classification_id": "274",
		"locale": "hu",
		"market_code": "hu",
	},
	"hr": {
		"classification_id": "302",
		"locale": "en",
		"market_code": "hr",
	},
	"si": {
		"classification_id": "271",
		"locale": "en",
		"market_code": "si",
	},
	"ro": {
		"classification_id": "268",
		"locale": "ro",
		"market_code": "ro",
	},
	"lt": {
		"classification_id": "290",
		"locale": "en",
		"market_code": "lt",
	},
	"lv": {
		"classification_id": "289",
		"locale": "en",
		"market_code": "lv",
	},
	"ee": {
		"classification_id": "288",
		"locale": "en",
		"market_code": "ee",
	},
	"mt": {
		"classification_id": "278",
		"locale": "en",
		"market_code": "mt",
	},
	"cy": {
		"classification_id": "281",
		"locale": "en",
		"market_code": "cy",
	},
	"al": {
		"classification_id": "270",
		"locale": "en",
		"market_code": "al",
	},
	"ba": {
		"classification_id": "245",
		"locale": "en",
		"market_code": "ba",
	},
	"me": {
		"classification_id": "259",
		"locale": "en",
		"market_code": "me",
	},
	"mk": {
		"classification_id": "275",
		"locale": "en",
		"market_code": "mk",
	},
	"rs": {
		"classification_id": "266",
		"locale": "en",
		"market_code": "rs",
	},
	"sk": {
		"classification_id": "273",
		"locale": "en",
		"market_code": "sk",
	},
}

epg_languages = {
	"de": "de-DE",
	"at": "de-AT",
	"ch": "de-CH",
	"it": "en-US",
	"pl": "en-US",
	"uk": "en-GB",
	"es": "en-US",
	"nl": "en-US",
	"fr": "en-US",
	"se": "en-US",
	"dk": "en-US",
	"no": "en-US",
	"fi": "en-US",
	"be": "en-US",
	"cz": "en-US",
	"pt": "en-US",
	"gr": "en-GR",
	"lu": "en-US",
	"ie": "en-IE",
	"is": "en-IS",
	"bg": "en-US",
	"hu": "en-US",
	"hr": "en-HR",
	"si": "en-SI",
	"ro": "en-US",
	"lt": "en-LT",
	"lv": "en-LV",
	"ee": "en-EE",
	"mt": "en-MT",
	"cy": "en-CY",
	"al": "en-AL",
	"ba": "en-BA",
	"me": "en-ME",
	"mk": "en-MK",
	"rs": "en-RS",
	"sk": "en-SK",
}

TIDS = {
	"de": "130",
	"it": "131",
	"pl": "132",
	"uk": "133",
	"es": "134",
	"fr": "135",
	"nl": "136",
	"be": "137",
	"lu": "138",
	"se": "139",
	"dk": "13A",
	"no": "13B",
	"fi": "13C",
	"ie": "13D",
	"cz": "13E",
	"pt": "13F",
	"gr": "140",
	"at": "141",
	"ch": "142",
	"is": "143",
	"bg": "144",
	"hu": "145",
	"hr": "146",
	"si": "147",
	"ro": "148",
	"lt": "149",
	"lv": "14A",
	"ee": "14B",
	"mt": "14C",
	"cy": "14D",
	"al": "14E",
	"ba": "14F",
	"me": "150",
	"mk": "151",
	"rs": "152",
	"sk": "153",
}

config.plugins.rakutentv = ConfigSubsection()
config.plugins.rakutentv.bq_service1 = ConfigSelection(
	default="4097",
	choices={"4097": _("4097"), "5001": _("5001"), "5002": _("5002")}
)
config.plugins.rakutentv.bq_service2 = ConfigSelection(
	default="5002",
	choices={"none": _("NONE"), "4097": _("4097"), "5001": _("5001"), "5002": _("5002")}
)
config.plugins.rakutentv.update_home_region = ConfigYesNo(default=False)
config.plugins.rakutentv.home_region = ConfigSelection(default="de", choices=CH_REGIONS)
config.plugins.rakutentv.ch_region_1 = ConfigSelection(default="de", choices=CH_REGIONS)
config.plugins.rakutentv.ch_region_2 = ConfigSelection(default="none", choices=CH_REGIONS)
config.plugins.rakutentv.ch_region_3 = ConfigSelection(default="none", choices=CH_REGIONS)
config.plugins.rakutentv.ch_region_4 = ConfigSelection(default="none", choices=CH_REGIONS)
config.plugins.rakutentv.ch_region_5 = ConfigSelection(default="none", choices=CH_REGIONS)

screenWidth = getDesktop(0).size().width()
config.usage.picon_dir = ConfigDirectory(default="/usr/share/enigma2/picon")
picon_dir = config.usage.picon_dir.value
if not pathExists(picon_dir):
	os.makedirs(picon_dir)


def parse_date(dstr):
	return time.struct_time(
		(int(dstr[0:4]), int(dstr[5:7]), int(dstr[8:10]), int(dstr[11:13]), int(dstr[14:16]), 0, -1, -1, 0))


def get_time_utc(timestring):
	value1 = timestring[0:23]
	value2 = timestring[23:26] + timestring[27:]
	tm = parse_date(value1)
	timegm = calendar.timegm(tm)
	timegm -= 3600 * int(value2) // 100
	return timegm


class RakutenAPIDownloader(object):
	service_types_tv = (
		"1:7:1:0:0:0:0:0:0:0:(type == 1) || (type == 17) || (type == 22) || (type == 25) || (type == 134) || (type == 195)"
	)

	def __init__(self, silent):
		self.last_err = None
		self.silent = silent
		self.iprogress = 0
		self.total = 0
		self.state = 1
		self.epg_tm_ofs = 0
		self.leave_called = False
		self.downloadActive = False
		self.categories = []
		self.epgcache = eEPGCache.getInstance()
		self.req_session = requests.Session()
		self.req_session.hooks = {"response": lambda r, *args, **kwargs: r.raise_for_status()}
		self.req_session.headers.update(
			{
				"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0",
				"Origin": "https://rakuten.tv",
				"Referer": "https://rakuten.tv/",
			}
		)

	@defer.inlineCallbacks
	def leave(self):
		if self.leave_called or self.downloadActive:
			return

		self.leave_called = True
		self.d_close = defer.Deferred()
		stri = _("The update is in progress. Exit now?")
		self.session.openWithCallback(self.leave_ok, MessageBox, stri, MessageBox.TYPE_YESNO, timeout=30)
		yield self.d_close
		self.leave_called = False

	def leave_ok(self, answer=True, deferred=True):
		if answer and not deferred:
			if not self.last_err:
				Silent.stop()
				Silent.start()
			self.close(not self.abort)
		elif deferred:
			self.abort = answer
			if not self.d_close.called:
				self.d_close.callback(answer)

	def tmCallback(self):
		if not self.deferred.called:
			self.deferred.callback(None)

	@staticmethod
	def getLocalTime():
		offset = datetime.datetime.utcnow() - datetime.datetime.now()
		return time.time() + offset.total_seconds()

	def get_stream_infos(self, cid="top-free-de-rakuten-tv", sl="MIS", al="DEU"):
		postdata = {
			"audio_language": al,
			"audio_quality": "5.1",
			"classification_id": region_params[self.region]["classification_id"],
			"content_id": cid,
			"content_type": "live_channels",
			"device_make": "firefox",
			"device_model": "GENERIC",
			"device_serial": "not implemented",
			"device_stream_video_quality": "HD",
			"device_uid": "d32afb59-1d6f-4288-8a04-98cee6b0cd51",
			"device_year": "1970",
			"gdpr_consent_opt_out": "0",
			"gdpr_consent": "",
			"hdr_type": "NONE",
			"ifa_subscriber_id": "none",
			"player_height": 1080,
			"player_width": 1920,
			"player": "web:HLS-NONE:NONE",
			"publisher_provided_id": "09bef241-987c-45b2-b024-acc61a336afa",
			"strict_video_quality": "false",
			"subtitle_formats": ["vtt"],
			"subtitle_language": sl,
			"video_type": "stream",
			"support_thumbnails": "false",
		}

		r = self.req_session.post(SINFO_URL, params=region_params[self.region], json=postdata)
		return r.json()

	@defer.inlineCallbacks
	def get_categories(self):
		print("[RakutenDownload] get_categories(), region '{}'...".format(_regions[self.region]))
		r = self.req_session.get(CAT_URL, params=region_params[self.region]).json()
		categories = []
		ncats = len(r["data"])
		progress = 0.0
		if ncats:
			pstep = 19.0 / ncats
		for item in r["data"]:
			progress += pstep 
			yield self.update_progress(progress=int(progress), ms=2)
			cat = {u"id": item["id"], u"name": item["name"], u"channels": []}
			channels = item["live_channels"]
			channels.reverse()
			for ch in channels:
				data = self.req_session.get(CHNINFO_URL.format(ch), params=region_params[self.region]).json()["data"]
				yield self.update_progress(ms=2)
				chn = {
					"id": data["id"], "tvg_id": data["numerical_id"],
					"tvg_chno": data["channel_number"],	"name": data["title"],
				}
				uname = data["title"]
				service_num = 4097
				chn["sref"] = "{0}:0:1:{1}:{2}:0:0:0:0:0:0".format(service_num, chn["tvg_id"], TIDS[self.region])
				streams = data["view_options"]["private"]["streams"]
				for stream in streams:
					for sl in stream["subtitle_languages"]:
						lid = sl["id"]

					for al in stream["audio_languages"]:
						aid = al["id"]

				data = self.get_stream_infos(ch, lid, aid)["data"]
				yield self.update_progress(ms=2)
				for si in data["stream_infos"]:
					chn["url"] = si["url"].replace(":", "%3A")
				cat["channels"].append(chn)
			categories.append(cat)

		defer.returnValue(categories)

	def create_bouquet(self):
		print("[RakutenDownload] build bouquet, region '{}'...".format(_regions[self.region]))
		bq = "_{}".format(self.region)
		bq = BOUQUET.format(bq)

		with open("/etc/enigma2/bouquets.tv", "r") as fd:
			bouquets = fd.read()

		if bq not in bouquets:
			print("[RakutenDownload] add bouquet, region '{}'...".format(_regions[self.region]))
			self.add_bouquet(bq, self.region)
			bupd = True
		else:
			bupd = False

		bq_path = "/etc/enigma2/{0}".format(bq)
		self.update_bouquet(bupd, bq_path)

	@staticmethod
	def m3u2json(m3u, region):
		lines = iter(filter(bool, m3u.splitlines()))
		line = re.search(r"#(EXTM3U)+", next(lines)).group(1)
		cat_ctr = 0
		cats = set()
		categories = []
		for line in lines:
			tvg_chno, tvg_id, tvg_name, group_title = re.search(
				r'#EXTINF:.*?(?:tvg-chno=(\d+))+\s+(?:tvg-id="(.+?)")+\s+(?:tvg-name="(.+?)")+\s+(?:group-title="(.+?)")+',
				line
			).groups()
			url = next(lines).replace(":", "%3A")
			if group_title not in cats:
				cat_ctr += 1
				cats.add(group_title)
				categories.append(
					{
						"id": cat_ctr,
						"name": group_title.capitalize(),
						"channels": [],
					}
				)
			categories[-1]["channels"].append(
				{
					"name": tvg_name,
					"url": url,
					"sref": "4097:0:1:{0}:{1}:0:0:0:0:0:0".format(tvg_chno, TIDS[region]),
					"tvg_id": tvg_chno,
					"tvg_chno": tvg_chno,
					"id": tvg_id,
				}
			)

		return categories

	def update_bouquet(self, bupd, bq_path):
		path = os.path.join(DATA_PATH, "rakutentv-{0}").format(self.region)
		if not self.categories:
			if fileExists(path + ".m3u"):
				with open(path + ".m3u", "rb") as fp:
					self.categories = self.m3u2json(fp.read().decode("utf-8"), self.region)
			else:
				with open(path + ".json", "rb") as fp:
					self.categories = json.load(fp)
		else:
			with open(path + ".json", "w") as fp:
				json.dump(self.categories, fp)
			print("[RakutenDownload] file '{0}' updated.".format(path + ".json"))
			if fileExists(path + ".m3u"):
				os.unlink(path + ".m3u")
				print("[RakutenDownload] file '{0}' deleted.".format(path + ".m3u"))
			config.plugins.rakutentv.update_home_region.value = False
			config.plugins.rakutentv.update_home_region.save()

		bq = []
		nm = " ({0})".format(self.region.upper())
		bq.append("#NAME Rakuten TV{0}\n".format(nm))
		services = filter(
			lambda v: v != "none",
			set([config.plugins.rakutentv.bq_service1.value, config.plugins.rakutentv.bq_service2.value])
		)
		services = sorted(services)
		ch_ctr = 0
		for cat in self.categories:
			bq.append("#SERVICE 1:64:{0}:0:0:0:0:0:0:0::{1}\n#DESCRIPTION {1}\n".format(cat["id"], cat["name"]))
			for chn in cat["channels"]:
				for iservice in services:
					iservice = int(iservice)
					snum = "[{0}]".format(iservice) if len(services) == 2 else ""
					bq.append(
						u"#SERVICE {0}:0:1:{tvg_id}:{2}:0:0:0:0:0:{url}:{name}{1}\n#DESCRIPTION {name}{1}\n".format(
							iservice, snum, TIDS[self.region], **chn
						)
					)
					ch_ctr += 1
		new_bq = "".join(bq)
		if not bupd:
			with open(bq_path, "rb") as fp:
				bupd = new_bq != fp.read()

		if bupd:
			with open(bq_path, "wb") as fp:
				fp.write(new_bq.encode("utf-8"))
			db = eDVBDB.getInstance()
			db.reloadBouquets()
			db.reloadServicelist()
			print("[RakutenDownload] Bouquet with {0} channels updated/created".format(ch_ctr))
		else:
			print("[RakutenDownload] Bouquet not changed")

	@classmethod
	def add_bouquet(cls, bouquet, region):
		if config.usage.multibouquet.value:
			bouquet_rootstr = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet'
		else:
			bouquet_rootstr = '%s FROM BOUQUET "userbouquet.favourites.tv" ORDER BY bouquet' % cls.service_types_tv
		bouquet_root = eServiceReference(bouquet_rootstr)
		serviceHandler = eServiceCenter.getInstance()
		mutableBouquetList = serviceHandler.list(bouquet_root).startEdit()
		if mutableBouquetList:
			esref = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "' + bouquet + '" ORDER BY bouquet'
			new_bouquet_ref = eServiceReference(esref)
			if not mutableBouquetList.addService(new_bouquet_ref):
				mutableBouquetList.flushChanges()
				eDVBDB.getInstance().reloadBouquets()
				mutableBouquet = serviceHandler.list(new_bouquet_ref).startEdit()
				if mutableBouquet:
					bq_region = " ({})".format(region.upper())
					mutableBouquet.setListName("Rakuten TV{}".format(bq_region))
					mutableBouquet.flushChanges()
				else:
					print("[RakutenDownload] get mutable list for new created bouquet failed")

	@staticmethod
	def get_timeline(event):
		timeline = {"title": event["title"], "subtitle": event["subtitle"], "description": event["description"],
					"start": get_time_utc(event["starts_at"]), "stop": get_time_utc(event["ends_at"])}

		return timeline

	@defer.inlineCallbacks
	def get_timelines(self, local_time=None):
		lang = epg_languages[self.region]
		headers = {"accept-language": lang}
		if not local_time:
			starts_at_timestamp = int(self.getLocalTime())
		else:
			starts_at_timestamp = int(local_time)

		starts_at_timestamp += self.epg_tm_ofs
		dura = 12
		starts_at = datetime.datetime.fromtimestamp(starts_at_timestamp).strftime("%Y-%m-%dT%H:00:00.000Z")
		ends_at = (datetime.datetime.fromtimestamp(starts_at_timestamp) + datetime.timedelta(hours=dura)).strftime(
			"%Y-%m-%dT%H:00:00.000Z"
		)
		epg_times = {
			"epg_duration_minutes": dura * 60,
			"epg_ends_at": ends_at,
			"epg_starts_at": starts_at,
		}
		epg_times.update(region_params[self.region])
		page = 1
		timelines = {}
		r = self.req_session.get(EPG_URL, params=epg_times, headers=headers, timeout=10).json()

		def get_items():
			for item in r["data"]:
				timelines[item["id"]] = []
				fsk = item["classification"]["name"]
				lang = item["labels"]["languages"][0]["name"]
				for event in item["live_programs"]:
					ev = self.get_timeline(event)
					ev.update({"fsk": fsk, "lang": lang})
					timelines[item["id"]].append(ev)

		get_items()
		pages = r["meta"]["pagination"]["total_pages"]
		for n in range(page + 1, pages + 1):
			epg_times["page"] = n
			yield self.update_progress(ms=100)
			r = self.req_session.get(EPG_URL, params=epg_times, headers=headers, timeout=10).json()
			get_items()

		defer.returnValue(timelines)

	def build_guide(self, timelines):
		guide_list = {}
		genre = 0
		for cat in self.categories:
			for channel in cat["channels"]:
				_id = channel["id"]
				if _id not in timelines:
					continue

				guide_list[channel["sref"]] = []
				for event in timelines[_id]:
					title = event["title"]
					subtitle = event["subtitle"]
					info = "{fsk}  {lang}".format(**event)
					subtitle = "\n".join((subtitle, info)) if subtitle else info
					description = event["description"]
					start = event["start"]
					stop = event["stop"]
					item = (start, stop - start, maybe_encode(title), maybe_encode(subtitle), maybe_encode(description), genre)
					guide_list[channel["sref"]].append(item)

		return guide_list

	def import_events(self, guide_list):
		print("[RakutenDownload] import epg, region '{}'...".format(_regions[self.region]))
		evt_cnt = 0
		for ref, events in guide_list.items():
			if not events:
				continue
			evt_cnt += len(events)
			self.epgcache.importEvents(maybe_encode(ref), events)
		print("[RakutenDownload] {0} events imported".format(evt_cnt))

	def update_progress(self, progress=None, ms=5):
		self.deferred = defer.Deferred()
		self.TimerTemp.start(ms, True)
		if progress is not None:
			self.iprogress = progress
		if not self.silent:
			self["progress"].setValue(self.iprogress)
			self["wait"].setText("{0} %".format(self.iprogress))
		return self.deferred

	@defer.inlineCallbacks
	def update_epg(self):
		if self.downloadActive:
			if not self.silent:
				msg = _("The silent update is in progress.")
				res = self.session.openWithCallback(self.close, MessageBox, msg, MessageBox.TYPE_INFO, timeout=30)
			print("[RakutenDownload] update is in progress.")
			return

		self.downloadActive = True
		self.abort = False
		print("[RakutenDownload] update is active.")
		self.last_err = None
		try:
			self.TimerTemp = eTimer()
			self.TimerTemp.callback.append(self.tmCallback)
			upd_list = [
				config.plugins.rakutentv.ch_region_1.value,
				config.plugins.rakutentv.ch_region_2.value,
				config.plugins.rakutentv.ch_region_3.value,
				config.plugins.rakutentv.ch_region_4.value,
				config.plugins.rakutentv.ch_region_5.value,
			]
			for self.region in filter(lambda v: v != "none", set(upd_list)):
				_msg = _("Rakuten TV update: {0}").format(_regions[self.region])
				if not self.silent:
					self["action"].setText(_msg)
					self["status"].setText(_("Updating in progress..."))
				print(_msg)
				yield self.update_progress(progress=0, ms=100)

				if config.plugins.rakutentv.update_home_region.value and config.plugins.rakutentv.home_region.value == self.region:
					self.categories = yield self.get_categories()
					self.req_session.close()
				else:
					self.categories *= 0
				yield self.update_progress(progress=20, ms=500)

				self.create_bouquet()
				yield self.update_progress(progress=40, ms=500)

				timelines = yield self.get_timelines()
				yield self.update_progress(progress=60, ms=500)

				guide_list = self.build_guide(timelines)
				yield self.update_progress(progress=80, ms=500)

				self.import_events(guide_list)

			with open("/etc/Rakutentv.timer", "w") as fp:
				fp.write(str(time.time()))

			if not self.silent:
				self["status"].setText(_("Update finished"))
			yield self.update_progress(progress=100, ms=2000)
		except Exception as err:
			print("[RakutenDownload] update error: {}".format(traceback.format_exc()))
			if not self.silent and not self.abort:
				self.session.open(
					MessageBox,
					_("An error occurred while updating, update aborted."),
					type=MessageBox.TYPE_ERROR,
					timeout=10,
				)
			self.abort = True
			self.last_err = err
			Silent.stop()
			if fileExists("/etc/Rakutentv.timer"):
				os.unlink("/etc/Rakutentv.timer")

		self.req_session.close()
		self.categories *= 0
		self.downloadActive = False
		print("[RakutenDownload] update finished")
		if not self.silent:
			self.leave_ok(deferred=False)
		elif not self.last_err:
			self.start()


class RakutenDownload(Screen, RakutenAPIDownloader):
	if screenWidth and screenWidth == 1920:
		skin = """
		<screen name="RakutenTVdownload" position="60,60" size="615,195" title="RakutenTV EPG Download" flags="wfNoBorder" backgroundColor="#ff000000">
		<ePixmap name="background" position="0,0" size="615,195" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/RakutenTV/images/download-fhd.png" zPosition="-1" alphatest="off" />
		<widget name="picon" position="15,91" size="120,80" transparent="1" alphatest="blend" />
		<widget name="action" halign="left" valign="center" position="15,9" size="585,30" font="Regular;26" foregroundColor="#ffffff" transparent="1" backgroundColor="#000000" noWrap="1"/>
		<widget name="progress" position="150,127" size="420,12" backgroundColor="#1143495b" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/RakutenTV/images/progressbar-fhd.png" zPosition="2" />
		<eLabel name="fondoprogreso" position="150,127" size="420,12" backgroundColor="#102a3b58" />
		<widget name="wait" valign="center" halign="center" position="150,93" size="420,30" font="Regular;23" foregroundColor="#ffffff" transparent="1" backgroundColor="#000000" noWrap="1"/>
		<widget name="status" halign="center" valign="center" position="150,150" size="420,30" font="Regular;24" foregroundColor="#ffffff" transparent="1" backgroundColor="#000000" noWrap="1"/>
		</screen>"""
	else:
		skin = """
		<screen name="RakutenTVdownload" position="40,40" size="410,130" title="RakutenTV EPG Download" flags="wfNoBorder" backgroundColor="#ff000000">
		<ePixmap name="background" position="0,0" size="410,130" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/RakutenTV/images/download-hd.png" zPosition="-1" alphatest="off" />
		<widget name="picon" position="10,61" size="80,53" transparent="1" alphatest="blend" />
		<widget name="action" halign="left" valign="center" position="10,6" size="390,20" font="Regular;17" foregroundColor="#00ffffff" transparent="1" backgroundColor="#00000000" noWrap="1" />
		<widget name="progress" position="100,85" size="280,8" backgroundColor="#1143495b" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/RakutenTV/images/progressbar-hd.png" zPosition="2" />
		<eLabel name="fondoprogreso" position="100,85" size="280,8" backgroundColor="#102a3b58" />
		<widget name="wait" valign="center" halign="center" position="100,62" size="280,20" font="Regular;15" foregroundColor="#00ffffff" transparent="1" backgroundColor="#00000000" noWrap="1" />
		<widget name="status" halign="center" valign="center" position="100,100" size="280,20" font="Regular;16" foregroundColor="#00ffffff" transparent="1" backgroundColor="#00000000" noWrap="1" />
		</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)
		RakutenAPIDownloader.__init__(self, False)
		self.skinName = "RakutenTVdownload"
		self["progress"] = ProgressBar()
		self["action"] = Label(_("Rakuten TV update"))
		self["wait"] = Label()
		self["status"] = Label()
		self["actions"] = ActionMap(["OkCancelActions"], {"cancel": self.leave}, -1)
		self["picon"] = Pixmap()
		self.onFirstExecBegin.append(self.init)

	def init(self):
		self["picon"].instance.setScale(1)
		self["picon"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/RakutenTV/images/picon.png")
		self["progress"].setValue(0)
		self.update_epg()


class DownloadSilent(RakutenAPIDownloader):
	def __init__(self, session):
		RakutenAPIDownloader.__init__(self, True)
		self.timer = eTimer()
		self.timer.timeout.get().append(self.update_epg)
		self.session = session
		self.start()

	def start(self):
		minutes = 60 * 5
		if fileExists("/etc/Rakutentv.timer"):
			with open("/etc/Rakutentv.timer", "r") as f:
				last = float(f.read().strip())
				minutes = minutes - int((time.time() - last) / 60)
				if minutes <= 0 or minutes > 60 * 24:
					minutes = 1
				self.timer.start(minutes * 60000, False)
		else:
			self.stop()

	def stop(self):
		self.timer.stop()

	def close(*args):
		pass


Silent = None
