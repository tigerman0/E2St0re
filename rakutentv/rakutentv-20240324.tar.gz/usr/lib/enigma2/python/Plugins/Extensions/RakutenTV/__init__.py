# -*- coding: utf-8 -*-
#
#   Copyright (c) 2023 Billy2011 @vuplus-support.org
#
from __future__ import absolute_import
import gettext
import os

from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from enigma import getDesktop
from six import PY2 as IS_PY2

__version__ = "20240324"

PluginLanguageDomain = "RakutenTV"
PluginLanguagePath = "Extensions/RakutenTV/locale"


def maybe_encode(text, encoding="utf8"):
	if IS_PY2:
		if isinstance(text, unicode):
			return text.encode(encoding)
		else:
			return text
	else:
		return text

def maybe_decode(text, encoding="utf8"):
    if not IS_PY2 and isinstance(text, bytes):
        return text.decode(encoding)
    else:
        return text

def localeInit():
	lang = language.getLanguage()[:2] # getLanguage returns e.g. "fi_FI" for "language_country"
	os.environ["LANGUAGE"] = lang # Enigma doesn't set this (or LC_ALL, LC_MESSAGES, LANG). gettext needs it!
	print("[RakutenTV] set language to ", lang)
	gettext.bindtextdomain(PluginLanguageDomain, resolveFilename(SCOPE_PLUGINS, PluginLanguagePath))

def _(txt):
	if gettext.dgettext(PluginLanguageDomain, txt):
		return gettext.dgettext(PluginLanguageDomain, txt)
	else:
		print("[" + PluginLanguageDomain + "] fallback to default translation for " + txt)
		return gettext.gettext(txt)

language.addCallback(localeInit())
