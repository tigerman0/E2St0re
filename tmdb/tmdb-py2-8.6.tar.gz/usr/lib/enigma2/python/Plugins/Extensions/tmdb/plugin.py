#!/usr/bin/env python
# -*- coding: utf-8 -*-
#######################################################################
# maintainer: <schomi@vuplus-support.org> 
# This plugin is free software, you are allowed to
# modify it (if you keep the license),
# but you are not allowed to distribute/publish
# it without source code (this version and your modifications).
# This means you also have to distribute
# source code of your modifications.
#######################################################################

from Plugins.Plugin import PluginDescriptor

from Screens.EpgSelection import EPGSelection
from Screens.EventView import EventViewBase
from Components.EpgList import EPGList, EPG_TYPE_SINGLE, EPG_TYPE_MULTI
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap, HelpableActionMap
from Components.config import *
from Components.ConfigList import ConfigList, ConfigListScreen
from .__init__ import _
from . import tmdb


pname = "TMDb"
pdesc = _("Show movie details from TMDb")
pversion = "1.1.0"
pdate = "20230508"

config.plugins.tmdb = ConfigSubsection()
config.plugins.tmdb.themoviedb_coversize = ConfigSelection(default="w185", choices = ["w92", "w185", "w500", "original"])
config.plugins.tmdb.lang = ConfigSelection(default="it", choices = ["de", "en", "it", "fr", "ar", "ru", "bg", "po", "lv", "da", "nl", "fi", "el", "he", "hu", "no", "pt", "ro", "sk", "sl", "es", "swe", "tr", "uk", "cz"])
config.plugins.tmdb.firsthit = ConfigYesNo(default = True)
config.plugins.tmdb.secondsearch = ConfigYesNo(default = True)
config.plugins.tmdb.keyyellow = ConfigYesNo(default = True)
config.plugins.tmdb.backdropQuality = ConfigSelection(default="1280x720", choices = ["300x169", "780x439", "1280x720", "1920x1080", "original"])
config.plugins.tmdb.coverQuality = ConfigSelection(default="500x750", choices = ["185x280", "342x513", "500x750", "780x1170", "original"])
config.plugins.tmdb.cert = ConfigYesNo(default = True)
config.plugins.tmdb.apiKey = ConfigText(default = 'intern')

def getConfigValue( key, default='' ):  # sichere Abfrage eines Konfigurationswertes aus tmdb.py
    try:
        if hasattr(config.plugins.tmdb, key):
            return getattr(config.plugins.tmdb, key).value
    except: 
		pass
    return default

# Autostart
def autostart(reason, **kwargs):
	if reason == 0:
		try:
			# for yellow key activating in EPGSelection and EventView
			if config.plugins.tmdb.keyyellow.value:
				print ("[TMDb] Add key yellow to EPGs")
				EPGSelectionInit()
				EventViewInit()
		except Exception:
			pass

# Modify EPGSelection.__init__
baseEPGSelection__init__ = None
def EPGSelectionInit():
	global baseEPGSelection__init__
	if baseEPGSelection__init__ is None:
		baseEPGSelection__init__ = EPGSelection.__init__
	EPGSelection.__init__ = EPGSelection__init__

# Modified EPGSelection __init__
def EPGSelection__init__(self, session, service, zapFunc=None, eventid=None, bouquetChangeCB=None, serviceChangeCB=None, isEPGBar=None, switchBouquet=None, EPGNumberZap=None, togglePiP=None):
	baseEPGSelection__init__(self, session, service, zapFunc, eventid, bouquetChangeCB, serviceChangeCB, isEPGBar, switchBouquet, EPGNumberZap, togglePiP)
	print ("[TMDb] Added key yellow to EPGSelection")
	if self.type != EPG_TYPE_MULTI:
		def yellowClicked():
			cur = self["list"].getCurrent()
			if cur[0] is not None:
				name = cur[0].getEventName()
			else:
				name = ''
			session.open(tmdb.tmdbScreen, name, 2)
		self["tmdb_actions"] = ActionMap(["EPGSelectActions"],
				{
					"yellow": yellowClicked,
				})
		self["key_yellow"].text = _("TMDb Infos ...")
		

# Modify EventView.__init__ 
EventViewBase__init__ = None
def EventViewInit():
	global EventViewBase__init__
	if EventViewBase__init__ is None:
		EventViewBase__init__ = EventViewBase.__init__
	EventViewBase.__init__ = EventView__init__

# Modified EventView __init__
def EventView__init__(self, Event, Ref, callback=None, similarEPGCB=None):
	EventViewBase__init__(self, Event, Ref, callback, similarEPGCB)
	print ("[TMDb] Added key yellow to EventView")
	def yellowClicked():
		name = self.event.getEventName() or info.getName() or ''
		self.session.open(tmdb.tmdbScreen, name, 2)
		
	self["tmdb_actions"] = ActionMap(["EPGSelectActions"],
			{
				"yellow": yellowClicked,
			})
	self["key_yellow"].text = _("TMDb Infos ...")
	
		
def main(session, service, **kwargs):
	reload(tmdb)
	try:
		session.open(tmdb.tmdbScreen, service, 1)
	except:
		import traceback
		traceback.print_exc()
		
def eventinfo(session, eventName="", **kwargs):
	reload(tmdb)
	try:
		s = session.nav.getCurrentService()
		info = s.info()
		event = info.getEvent(0) # 0 = now, 1 = next
		name = event and event.getEventName() or info.getName() or ''
		session.open(tmdb.tmdbScreen, name, 2)
	except:
		import traceback
		traceback.print_exc()
		
def Plugins(**kwargs):
	return [
			PluginDescriptor(name="TMDb", description=_("TMDb Infos ..."), where = PluginDescriptor.WHERE_AUTOSTART, fnc=autostart, needsRestart = False),
			PluginDescriptor(name="TMDb", description=_("TMDb Infos ..."), where = PluginDescriptor.WHERE_MOVIELIST, fnc=main, needsRestart = False),
			PluginDescriptor(name="TMDb" ,description=_("TMDb Infos ..."), where = PluginDescriptor.WHERE_EVENTINFO, fnc=eventinfo, needsRestart = False)
			]
