#!/bin/sh
opkg remove stream
opkg remove najdi
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/StreamHunter/
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/NAJDIbilibili/
sleep 1
echo "stahuji plugin ...StreamHunter"
echo ""
cd /tmp
curl --retry 2 -k -Lbk -m 55532 -m 555104 -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36" -d POST "https://drive.google.com/uc?id=1cgkf7d_D-_ijpWyVPe2tjGkCwSwJ6zrT&uuid=6013fa44-bd1c-4ad5-b16d-49b30a978e2b&confirm=t&uuid=6013fa44-bd1c-4ad5-b16d-49b30a978e2b" > /tmp/stream_hunter8_all.ipk



sleep 1
echo "instaluji ...."
cd /tmp
opkg install /tmp/stream_hunter8_all.ipk

echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/stream_hunter8_all.ipk

echo "OK"
killall -9 enigma2
exit
