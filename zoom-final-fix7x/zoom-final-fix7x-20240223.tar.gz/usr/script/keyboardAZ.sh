#!/bin/sh
echo "stahuji keyboardFIX ........."
echo ""
cd /tmp
if  curl  -k -Lbk -m 55532 -m 555104 "https://drive.google.com/uc?id=18V98gesOqLbpUZvHNphBQWGujDaYVBBw&export=download" > /tmp/fix_keybordOpenPLI7.0_all.ipk ; then
rm -rf /usr/share/enigma2/keymap.xml
else
echo 'nepodařilo se stáhnout soubor!' 
echo 'zkontrolujte internet!' 
echo 'nedělám nic!' 
sleep 8
exit
fi

echo ""
sleep 1
echo "instaluji ...."
cd /tmp
opkg install /tmp/fix_keybordOpenPLI7.0_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/fix_keybordOpenPLI7.0_all.ipk
sleep 2
killall -9 enigma2
exit
