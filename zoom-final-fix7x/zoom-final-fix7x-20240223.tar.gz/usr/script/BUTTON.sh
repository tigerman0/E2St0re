#!/bin/sh

while :; do
    if ps 2>/dev/null | grep "/usr/script/tichestart1.sh" | grep -v grep > /dev/null 2>&1 ; then
        echo "Skript je stále aktivní....čekejte prosím" > /dev/null 2>&1
    else
        break  # Ukončí smyčku, pokud skript není aktivní
    fi

    echo ""
    echo "stahování ještě nebylo dokončeno!!!!"
    echo "nyní ho nemohu spustit znovu!"
	sleep 2
	echo ""
    echo "pokud ho opravdu znovu budete potřebovat,"
	echo "zkuste to prosím později"
	sleep 8
	/usr/script/exit.sh  >>/dev/null 2>&1 </dev/null &
	exit
done

while :; do
    if ps -aux 2>/dev/null | grep "/usr/script/tichestart1.sh" | grep -v grep > /dev/null 2>&1 ; then
        echo "Skript je stále aktivní....čekejte prosím" > /dev/null 2>&1
    else
        break  # Ukončí smyčku, pokud skript není aktivní
    fi

    echo ""
    echo "stahování ještě nebylo dokončeno!!!!"
    echo "nyní ho nemohu spustit znovu!"
	sleep 2
	echo ""
    echo "pokud ho opravdu znovu budete potřebovat,"
	echo "zkuste to prosím později"
	sleep 8
	/usr/script/exit.sh  >>/dev/null 2>&1 </dev/null &
	exit
done


/usr/script/tichestart1.sh >/dev/null 2>&1 </dev/null &
sleep 1
echo ""
echo "zahájil jsem neviditelné stahování"
echo "nenechte se rušit"
echo "já budu stahovat dál......"
echo "výsledek budu postupně tiše ukládat"
echo "přeji příjemné sledování TV!!!"
echo ""
sleep 2
/usr/script/exit.sh  >>/dev/null 2>&1 </dev/null &
cp /usr/script/upozor.sh /tmp/upozor.sh >>/dev/null 2>&1 </dev/null &
chmod 755 /tmp/upozor.sh >>/dev/null 2>&1 </dev/null &
exit 