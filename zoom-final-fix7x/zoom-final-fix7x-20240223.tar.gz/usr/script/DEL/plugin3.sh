#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu Eporner"
opkg remove epodown
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/eporner/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit
