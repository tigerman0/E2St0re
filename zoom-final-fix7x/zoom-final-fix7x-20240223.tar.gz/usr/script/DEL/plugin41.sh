#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu Heavyr"
opkg remove enigma2-plugin-extensions-heavyr
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/heavyr/


echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

