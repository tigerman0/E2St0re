#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu AddonsPanel od Levi45"
opkg remove enigma2-plugin-extensions-levi45-addonsmanager
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/Levi45AddonsPanel/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

