#!/bin/sh
echo "Restarting E2"
sleep 1
echo "Restartování E2"
echo ""
killall -9 enigma2
exit
