#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu najdi StreamHunter"
opkg remove stream
opkg remove najdi
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/StreamHunter/
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/NAJDIbilibili/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

