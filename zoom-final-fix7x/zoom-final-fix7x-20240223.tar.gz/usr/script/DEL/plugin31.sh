#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu CCcam FINDER"
opkg remove cccam-finder
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/CCcamFinder/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

