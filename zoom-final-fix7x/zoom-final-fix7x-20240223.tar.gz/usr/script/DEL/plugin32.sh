#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu Oscam FINDER"
opkg remove oscam-finder
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/OscamFinder/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

