#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu glasssysutil 10.78"
opkg remove enigma2-plugin-glasssysutil
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit
