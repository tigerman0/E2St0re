#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu najdi BILIBILI"
opkg remove najdi - BILIBILI
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/NAJDIbilibili/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

