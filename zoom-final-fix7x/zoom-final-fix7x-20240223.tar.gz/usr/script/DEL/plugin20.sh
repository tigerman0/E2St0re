#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu LuxSatMENU"
opkg remove enigma2-luxsat-menu
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/MenuLux/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

