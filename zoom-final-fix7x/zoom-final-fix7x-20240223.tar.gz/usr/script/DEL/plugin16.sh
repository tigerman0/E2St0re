#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu alternativní softcam Manager zelda77"
opkg remove sm - x
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/SoftCam_Manager/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

