#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu XBMC (KODI)"
opkg remove funkce - x
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/XBMCAddons/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit
