#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu SatVenusPANEL"
opkg remove enigma2-plugin-extensions-satvenus-panel
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/SatVenusPanel/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

