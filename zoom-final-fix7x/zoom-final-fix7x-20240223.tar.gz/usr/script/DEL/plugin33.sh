#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu najdi KLIP"
opkg remove najdi - KLIP
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/NAJDIklip/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

