#!/bin/sh
echo "Tímto bych chtěl poděkovat"
echo ""
echo "I would like to thank you"
sleep 2
echo ""
echo ""
echo "všem kteří při práci na tomto pluginu pomohli"
echo ""
echo "to all who helped with this plugin"
sleep 2
echo ""
echo ""
echo "děkuji....."
echo ""
echo "Thank you....."
sleep 2
echo ""
echo ""
echo "Vladimir Zvolensky (vlado222)"
sleep 2
echo "Ludek Ptacek"
sleep 2
echo "(hrbekl)"
sleep 2
echo "(chocholousek)"
sleep 2
echo "(kuzmik)"
sleep 2
echo "(005jon)"
sleep 2
echo "(vitamin)"
sleep 2
echo "(bambule)"
sleep 2
echo "a další ......"
sleep 2
echo "speciální poděkování pro..."
echo ""
echo "special thanks for..."
sleep 2
echo "ziko"
sleep 2
echo "giorbak"
sleep 2
echo "Mino6060"
sleep 2
echo "zelda77"
sleep 2
echo "Levi45"
sleep 2
echo "************************************************************"
     echo "           21.11.2020         BextrH"
echo "************************************************************"
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
exit 0
