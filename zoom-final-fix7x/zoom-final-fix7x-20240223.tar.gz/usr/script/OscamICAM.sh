#!/bin/sh
echo "Instaluji oscamicam_11718-V9-Kitte888-V8"
sleep 1
echo "Vhodné pouze pro ALL!!"
opkg remove enigma2-plugin-softcams-oscamicam
cd /tmp
curl --retry 2 -k -Lbk -m 55532 -m 555104 -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36" -d POST "https://drive.google.com/uc?id=1AVnyL6sBFRg-uGPIg7kCvkwcNZMlUI3r&uuid=6013fa44-bd1c-4ad5-b16d-49b30a978e2b&confirm=t&uuid=6013fa44-bd1c-4ad5-b16d-49b30a978e2b" > /tmp/enigma2-plugin-softcams-oscamicam_11718-V9-Kitte888-V8_all.ipk
sleep 1
echo "instaluji Oscam...."
cd /tmp
opkg install /tmp/enigma2-plugin-softcams-oscamicam_11718-V9-Kitte888-V8_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/enigma2-plugin-softcams-oscamicam_11718-V9-Kitte888-V8_all.ipk
sleep 2
killall -9 enigma2
exit
