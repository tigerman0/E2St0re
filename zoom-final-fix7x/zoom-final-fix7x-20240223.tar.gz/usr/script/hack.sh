#!/bin/sh
[ -d /tmp/xtest ] || mkdir -p /tmp/xtest
####################################################################################################
cd /tmp/xtest
####################################################################################################
curl -Lbk -m 4555 -m 6555 -k 'https://sky.dhoom.org/test-free-cccam/' > /tmp/xtest/token


grep -o -i -E '"_token" id="name" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/token1
grep -o -i -E '"trial" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/jmeno
grep -o -i -E '"ok" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/heslo




TOKEN_FILE="/tmp/xtest/token1"
JMENO_FILE="/tmp/xtest/jmeno"
HESLO_FILE="/tmp/xtest/heslo"
OUTPUT_FILE="/tmp/xtest/souborXX"



PATH_J_XM=$(cat "$TOKEN_FILE" | tr -d '[:space:]')
PATH_J_XM1=$(cat "$JMENO_FILE")
PATH_J_XM2=$(cat "$HESLO_FILE")

PATH_J_XM=$(echo "$PATH_J_XM" | sed 's/[^a-zA-Z0-9=]//g')


  curl -Lbk -m 4555 -m 6555 -k 'https://sky.dhoom.org/wp-admin/admin-post.php' \
    -X POST \
    -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0' \
    -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8' \
    -H 'Accept-Language: cs,sk;q=0.8,en-US;q=0.5,en;q=0.3' \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -H 'Origin: https://sky.dhoom.org' \
    -H 'Connection: keep-alive' \
    -H 'Referer: https://sky.dhoom.org/test-free-cccam/' \
    -H 'Upgrade-Insecure-Requests: 1' \
    -H 'Sec-Fetch-Dest: document' \
    -H 'Sec-Fetch-Mode: navigate' \
    -H 'Sec-Fetch-Site: same-origin' \
    -H 'Sec-Fetch-User: ?1' \
    --data-raw "action=ts_test_line_submission&_token=$PATH_J_XM&trial=$PATH_J_XM1&ok=$PATH_J_XM2" \
    > "$OUTPUT_FILE"
####################################################################################################
grep -o -i -E '"_os_token" id="name" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/xtoken1
grep -o -i -E '"os_trial" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/xjmeno
grep -o -i -E '"os_ok" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/xheslo

XTOKEN_FILE="/tmp/xtest/xtoken1"
XJMENO_FILE="/tmp/xtest/xjmeno"
XHESLO_FILE="/tmp/xtest/xheslo"
OUTPUT_FILE="/tmp/xtest/souborYY"

XPATH_J_XM=$(cat "$XTOKEN_FILE" | tr -d '[:space:]')
XPATH_J_XM1=$(cat "$XJMENO_FILE")
XPATH_J_XM2=$(cat "$XHESLO_FILE")

XPATH_J_XM=$(echo "$XPATH_J_XM" | sed 's/[^a-zA-Z0-9=]//g')


  curl -Lbk -m 4555 -m 6555 -k 'https://sky.dhoom.org/wp-admin/admin-post.php' \
    -X POST \
    -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0' \
    -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8' \
    -H 'Accept-Language: cs,sk;q=0.8,en-US;q=0.5,en;q=0.3' \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -H 'Origin: https://sky.dhoom.org' \
    -H 'Connection: keep-alive' \
    -H 'Referer: https://sky.dhoom.org/test-free-cccam/' \
    -H 'Upgrade-Insecure-Requests: 1' \
    -H 'Sec-Fetch-Dest: document' \
    -H 'Sec-Fetch-Mode: navigate' \
    -H 'Sec-Fetch-Site: same-origin' \
    -H 'Sec-Fetch-User: ?1' \
    --data-raw "action=ts_test_os_line_submission&_os_token=$XPATH_J_XM&os_trial=$XPATH_J_XM1&os_ok=$XPATH_J_XM2" \
    > "$OUTPUT_FILE"
####################################################################################################
 sleep 7
####################################################################################################
grep -o -i -E '"_token" id="name" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/token1
grep -o -i -E '"trial" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/jmeno
grep -o -i -E '"ok" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/heslo


TOKEN_FILE="/tmp/xtest/token1"
JMENO_FILE="/tmp/xtest/jmeno"
HESLO_FILE="/tmp/xtest/heslo"
OUTPUT_FILE="/tmp/xtest/souborXX"

PATH_J_XM=$(cat "$TOKEN_FILE" | tr -d '[:space:]')
PATH_J_XM1=$(cat "$JMENO_FILE")
PATH_J_XM2=$(cat "$HESLO_FILE")


PATH_J_XM=$(echo "$PATH_J_XM" | sed 's/[^a-zA-Z0-9=]//g')

  curl -Lbk -m 4555 -m 6555 -k 'https://sky.dhoom.org/wp-admin/admin-post.php' \
    -X POST \
    -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0' \
    -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8' \
    -H 'Accept-Language: cs,sk;q=0.8,en-US;q=0.5,en;q=0.3' \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -H 'Origin: https://sky.dhoom.org' \
    -H 'Connection: keep-alive' \
    -H 'Referer: https://sky.dhoom.org/test-free-cccam/' \
    -H 'Upgrade-Insecure-Requests: 1' \
    -H 'Sec-Fetch-Dest: document' \
    -H 'Sec-Fetch-Mode: navigate' \
    -H 'Sec-Fetch-Site: same-origin' \
    -H 'Sec-Fetch-User: ?1' \
    --data-raw "action=ts_test_line_submission&_token=$PATH_J_XM&trial=$PATH_J_XM1&ok=$PATH_J_XM2" \
    > "$OUTPUT_FILE"
####################################################################################################
grep -o -i -E '"_os_token" id="name" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/xtoken1
grep -o -i -E '"os_trial" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/xjmeno
grep -o -i -E '"os_ok" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/xheslo

XTOKEN_FILE="/tmp/xtest/xtoken1"
XJMENO_FILE="/tmp/xtest/xjmeno"
XHESLO_FILE="/tmp/xtest/xheslo"
OUTPUT_FILE="/tmp/xtest/souborYY"

XPATH_J_XM=$(cat "$XTOKEN_FILE" | tr -d '[:space:]')
XPATH_J_XM1=$(cat "$XJMENO_FILE")
XPATH_J_XM2=$(cat "$XHESLO_FILE")

XPATH_J_XM=$(echo "$XPATH_J_XM" | sed 's/[^a-zA-Z0-9=]//g')


  curl -Lbk -m 4555 -m 6555 -k 'https://sky.dhoom.org/wp-admin/admin-post.php' \
    -X POST \
    -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0' \
    -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8' \
    -H 'Accept-Language: cs,sk;q=0.8,en-US;q=0.5,en;q=0.3' \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -H 'Origin: https://sky.dhoom.org' \
    -H 'Connection: keep-alive' \
    -H 'Referer: https://sky.dhoom.org/test-free-cccam/' \
    -H 'Upgrade-Insecure-Requests: 1' \
    -H 'Sec-Fetch-Dest: document' \
    -H 'Sec-Fetch-Mode: navigate' \
    -H 'Sec-Fetch-Site: same-origin' \
    -H 'Sec-Fetch-User: ?1' \
    --data-raw "action=ts_test_os_line_submission&_os_token=$XPATH_J_XM&os_trial=$XPATH_J_XM1&os_ok=$XPATH_J_XM2" \
    > "$OUTPUT_FILE"
####################################################################################################
sleep 7
####################################################################################################
grep -o -i -E '"_token" id="name" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/token1
grep -o -i -E '"trial" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/jmeno
grep -o -i -E '"ok" value="[^"<]*' token | grep -o -i -E 'value="[^"]*'|sed 's/value="//'|sed -n '1,1p' > /tmp/xtest/heslo


TOKEN_FILE="/tmp/xtest/token1"
JMENO_FILE="/tmp/xtest/jmeno"
HESLO_FILE="/tmp/xtest/heslo"
OUTPUT_FILE="/tmp/xtest/souborXX"

PATH_J_XM=$(cat "$TOKEN_FILE" | tr -d '[:space:]')
PATH_J_XM1=$(cat "$JMENO_FILE")
PATH_J_XM2=$(cat "$HESLO_FILE")


PATH_J_XM=$(echo "$PATH_J_XM" | sed 's/[^a-zA-Z0-9=]//g')

  curl -Lbk -m 4555 -m 6555 -k 'https://sky.dhoom.org/wp-admin/admin-post.php' \
    -X POST \
    -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0' \
    -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8' \
    -H 'Accept-Language: cs,sk;q=0.8,en-US;q=0.5,en;q=0.3' \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -H 'Origin: https://sky.dhoom.org' \
    -H 'Connection: keep-alive' \
    -H 'Referer: https://sky.dhoom.org/test-free-cccam/' \
    -H 'Upgrade-Insecure-Requests: 1' \
    -H 'Sec-Fetch-Dest: document' \
    -H 'Sec-Fetch-Mode: navigate' \
    -H 'Sec-Fetch-Site: same-origin' \
    -H 'Sec-Fetch-User: ?1' \
    --data-raw "action=ts_test_line_submission&_token=$PATH_J_XM&trial=$PATH_J_XM1&ok=$PATH_J_XM2" \
    > "$OUTPUT_FILE"
####################################################################################################
grep -o -i -E 'C: sky.dhoom.org [^<]*' /tmp/xtest/souborXX > /tmp/xtest/souborXXX
grep -o -i -E 'C: vip.dhoom.org [^<]*' /tmp/xtest/souborYY > /tmp/xtest/souborYYY
####################################################################################################

sleep 1

if opkg list_installed | grep python-requests ; then
    echo ""
    echo "python-requests is installed"
    echo ""
else
    echo 'python-requests was not found'
    echo ""
    opkg update
    opkg install python-requests
    echo "Do you want to install python-requests? (Y/N)"
    read answer
    if [ "$answer" != "${answer#[Yy]}" ] ;then
        opkg install python-requests
    else
        echo "Exiting..."
        exit 1
    fi
fi


LINE="************************************************************"

python <<'EOF'
import requests
import re
import time
from datetime import datetime

S = requests.Session()

def get_bigtezz_com(url):
    r = S.get(url, verify=False)  # 
    rgx = '''<input type="hidden" name="_token" value="(.+?)">'''
    rgx1 = '''<input type="hidden" name="trial-ok">.+?<input type="hidden" name="trial" value="(.+?)">'''
    rgx2 = '''<input type="hidden" name="ok" value="(.+?)"></form>'''
    _token = re.findall(rgx, r.content)
    _Dream = re.findall(rgx1, r.content, re.S)
    _CS = re.findall(rgx2, r.content)
    print(_token)
    print(_Dream)
    print(_CS)
    prm = {"trial": ["trial-ok", _Dream[0]], "CS": ["trial-ok", _CS[0]], "ok": ["trial-ok", _CS[0]],
           "x": "105", "y": "24", "_token": _token[0], "trial-ok": "24"}
    hdr = {'Host': 'dhoom.org',
           'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
           'Accept-Language': 'cs,sk;q=0.8,en-US;q=0.5,en;q=0.3',
           'Accept-Encoding': 'gzip, deflate, br',
           'Content-Type': 'application/x-www-form-urlencoded',
           'Origin': 'https://dhoom.org',
           'Connection': 'keep-alive',
           'Referer': url,
           'Upgrade-Insecure-Requests': '1'}
    print(prm)
    time.sleep(5)
    data = S.post(url, headers=hdr, data=prm, verify=False).content  # 
    tmx = '''color="White"> (.+?)</font>'''
    cline = re.findall(tmx, data)[0]
    print("cline", cline)
    with open('/tmp/xtest/souborZZZ', "a") as f: f.write("\n" + cline)
    return cline

S1 = "https://dhoom.org/test/"
print(get_bigtezz_com(S1))

#******************************************************************************
ncamfile = "/etc/tuxbox/config/ncam.server"
oscamfile = "/etc/tuxbox/config/oscam.server"
ccamfile = "/tmp/xtest/souborZZZ"
EOF
####################################################################################################
sed -i '/^$/d' /tmp/xtest/souborZZZ
echo ""  >> /tmp/xtest/souborZZZ
sed -i '/^$/d' /tmp/xtest/souborZZZ
####################################################################################################

curl -Lbk -m 4555 -m 6555 -k 'https://aromatv.online/'  > /tmp/xtest/www
adresa=$(grep -o 'http[^"]*\.jpg' /tmp/xtest/www | sed -n '$p')
curl -Lbk -m 4555 -m 6555 -k "$adresa" > /tmp/free.jpg

curl -Lbk -m 4555 -m 6555 -k -X POST -F "apikey=K83993917388957" -F "image=@/tmp/free.jpg" https://api.ocr.space/parse/image > /tmp/xtest/x

cat /tmp/xtest/x | \
grep -o '"ParsedText":"[^"]*' | \
sed 's/"ParsedText":"//' | \
sed 's/\\r\\n/\n/g' | \
awk '/Host:/ {print "Host:"} /Port:/ {print "Port:"} /User:/ {print "User:"} /pass:/ {print "pass:"} {print}' > /tmp/xtest/xx
sed -i "s#Daily Free CCCAM##g" /tmp/xtest/xx
sed -i "s#Host##g" /tmp/xtest/xx
sed -i "s#host##g" /tmp/xtest/xx
sed -i "s#Port##g" /tmp/xtest/xx
sed -i "s#port##g" /tmp/xtest/xx
sed -i "s#User##g" /tmp/xtest/xx
sed -i "s#user##g" /tmp/xtest/xx
sed -i "s#Pass##g" /tmp/xtest/xx
sed -i "s#pass##g" /tmp/xtest/xx
sed -i "s#:##g" /tmp/xtest/xx
sed -i "s# ##g" /tmp/xtest/xx
sed -i '/^$/d' /tmp/xtest/xx
sed -n 'H; $x; $s/\n/ /gp' /tmp/xtest/xx > /tmp/xtest/xxx
echo "C:"  > hotovoX
cat /tmp/xtest/xxx >> hotovoX
sed -i -n 'H; $x; $s/\n//gp' hotovoX
echo ""  >> hotovoX
cat hotovoX > hotovoX2
grep -o -i -E 'C: [a-z][^<]*' hotovoX2 > /tmp/xtest/souborAA


####################################################################################################
grep -o -i -E 'C: [^<]*' /tmp/xtest/souborAA > /tmp/xtest/souborAAA
rm -rf /tmp/free.jpg
####################################################################################################


exit 