cp /etc/panel/openpanel.xml /etc/
exit