/usr/script/tichestart1.sh >/dev/null 2>&1 </dev/null &
sleep 1
echo ""
echo "Ich habe einen unsichtbaren Download gestartet"
echo "Lass dich nicht stören"
echo "Ich werde weiter herunterladen ......"
echo "Ich werde das Ergebnis nach und nach leise speichern"
echo "Ich wünsche dir ein angenehmes Fernsehen !!!"
echo ""
sleep 2
/usr/script/exit.sh  >>/dev/null 2>&1 </dev/null &
cp /usr/script/upozor.sh /tmp/upozor.sh >>/dev/null 2>&1 </dev/null &
chmod 755 /tmp/upozor.sh >>/dev/null 2>&1 </dev/null &
exit 