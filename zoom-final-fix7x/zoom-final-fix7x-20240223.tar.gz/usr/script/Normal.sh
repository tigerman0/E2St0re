/usr/script/Normalstart.sh >/dev/null 2>&1 </dev/null &
sleep 1
echo "přepínám na Zoom verzi"
exit