cp /etc/panel/lite.xml /etc/openpanel.xml
exit