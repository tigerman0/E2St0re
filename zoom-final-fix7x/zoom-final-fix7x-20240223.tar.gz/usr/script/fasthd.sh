#!/bin/sh
echo "stahuji z : aromatv.online"

echo "ukládám server..."

echo "zobrazuji...."
echo ""
echo ""

[ -d /tmp/xtest ] || mkdir -p /tmp/xtest
####################################################################################################
cd /tmp/xtest
####################################################################################################



echo ""
echo "1 fáze ...získání adresy obrázku se serverem"
echo ""
curl -# -Lbk -m 4555 -m 6555 -k 'https://aromatv.online/'  > /tmp/xtest/www
echo ""
echo "2 fáze ...stažení obrázku"
echo ""


adresa=$(grep -o 'http[^"]*\.jpg' /tmp/xtest/www | sed -n '$p')
curl -# -Lbk -m 4555 -m 6555 -k "$adresa" > /tmp/free.jpg
echo ""
echo "3 fáze ...odeslání obrázku na převod ..na text"
echo ""
curl -# -Lbk -m 4555 -m 6555 -k -X POST -F "apikey=K83993917388957" -F "image=@/tmp/free.jpg" https://api.ocr.space/parse/image > /tmp/xtest/x
echo ""
echo "4 fáze ...převod textu na řádek (server)"
echo ""
cat /tmp/xtest/x | \
grep -o '"ParsedText":"[^"]*' | \
sed 's/"ParsedText":"//' | \
sed 's/\\r\\n/\n/g' | \
awk '/Host:/ {print "Host:"} /Port:/ {print "Port:"} /User:/ {print "User:"} /pass:/ {print "pass:"} {print}' > /tmp/xtest/xx
sed -i "s#Daily Free CCCAM##g" /tmp/xtest/xx
sed -i "s#Host##g" /tmp/xtest/xx
sed -i "s#host##g" /tmp/xtest/xx
sed -i "s#Port##g" /tmp/xtest/xx
sed -i "s#port##g" /tmp/xtest/xx
sed -i "s#User##g" /tmp/xtest/xx
sed -i "s#user##g" /tmp/xtest/xx
sed -i "s#Pass##g" /tmp/xtest/xx
sed -i "s#pass##g" /tmp/xtest/xx
sed -i "s#:##g" /tmp/xtest/xx
sed -i "s# ##g" /tmp/xtest/xx
sed -i '/^$/d' /tmp/xtest/xx
sed -n 'H; $x; $s/\n/ /gp' /tmp/xtest/xx > /tmp/xtest/xxx
echo "C:"  > hotovoX
cat /tmp/xtest/xxx >> hotovoX
sed -i -n 'H; $x; $s/\n//gp' hotovoX
echo ""  >> hotovoX
cat hotovoX > hotovoX2
grep -o -i -E 'C: [a-z][^<]*' hotovoX2 > /tmp/xtest/souborAA


####################################################################################################
grep -o -i -E 'C: [^<]*' /tmp/xtest/souborAA > /tmp/xtest/souborAAA
rm -rf /tmp/free.jpg
####################################################################################################
echo "OK"
echo ""
echo ""
####################################################################################################
more /tmp/xtest/souborAAA 
####################################################################################################
echo ""

cat souborAAA > /tmp/CCcam.cfg 
sed -i "s/c:/C:/" /tmp/CCcam.cfg
while read radek; do
    pocet=$(echo $radek | wc -w)
    if [ $pocet -le 4 ]; then
        echo "server ERROR"
        echo ""
		rm -rf /tmp/CCcam.cfg
        rm -rf /tmp/xtest
        sleep 2
        exit 1
    else
        echo $radek >> /tmp/CCcam.cfg2
    fi
done < '/tmp/CCcam.cfg'

sleep 2

cd /
rm -rf /etc/CCcam.cfg
cp /tmp/CCcam.cfg2 /etc/CCcam.cfg
rm -rf /tmp/CCcam.cfg2
rm -rf /tmp/CCcam.cfg
rm -rf /tmp/xtest


rm -rf /CCcam*
rm -rf /hotovo*



####################################################################################################
/usr/script/conv.sh
####################################################################################################

####################################################################################################
sleep 1
####################################################################################################
/usr/script/restart.sh
####################################################################################################
echo ""
sleep 2
pocet1=`wc -l < /etc/CCcam.cfg`
pocet1=$pocet1
echo "SERVERS..... "$pocet1
sleep 2
####################################################################################################

####################################################################################################


exit
