#!/bin/sh
cat /etc/CCcam.cfg > /tmp/CCcam.cfg
cat /etc/CCcamDATAx.cfg > /etc/CCcam.cfg
echo "" >> /etc/CCcam.cfg
grep -v '^ *$' /tmp/CCcam.cfg >> /etc/CCcam.cfg
sed -i "/^$/d " /etc/CCcam.cfg
rm -rf /tmp/CCcam.cfg
sleep 0
OUTPUT2='/tmp/server'
echo -n "Converting ....."
FS=" "      
group_number=1
cat /etc/CCcam.cfg | grep -i "^C:.*" | while read line ; do
    SERVER=$(echo $line | cut -d"$FS" -f2)
    PORT=$(echo $line | cut -d"$FS" -f3)
    USER=$(echo $line | cut -d"$FS" -f4)
    PASS=$(echo $line | cut -d"$FS" -f5)

    echo -n "."

    echo "[reader]" >> $OUTPUT2
    echo "label = $SERVER" >> $OUTPUT2
    echo "protocol = cccam" >> $OUTPUT2
    echo "device = $SERVER,$PORT" >> $OUTPUT2
    echo "user = $USER" >> $OUTPUT2
    echo "password = $PASS" >> $OUTPUT2
    echo "disablecrccws = 1" >> $OUTPUT2
    echo "inactivitytimeout = 30" >> $OUTPUT2
    echo "group = $group_number" >> $OUTPUT2
    echo "cccversion = 2.3.2" >> $OUTPUT2
    echo "ccckeepalive = 1" >> $OUTPUT2
    echo "audisabled = 0" >> $OUTPUT2
    echo "" >> $OUTPUT2
    echo "" >> $OUTPUT2

    
    group_number=$((group_number+1))
done


cp /tmp/server /etc/tuxbox/config/oscam/oscam.server  2>/dev/null || true
sleep 0
cp /tmp/server /etc/tuxbox/config/oscam_atv_free/oscam.server  2>/dev/null || true
sleep 0
cp /tmp/server /etc/tuxbox/config/oscam.server  2>/dev/null || true
sleep 0
cp /tmp/server /etc/tuxbox/config/gcam.server  2>/dev/null || true
sleep 0
cp /tmp/server /etc/tuxbox/config/ncam.server  2>/dev/null || true
sleep 0
cp /tmp/server /etc/tuxbox/config/supcam-emu  2>/dev/null || true
sleep 0
cp /tmp/server /etc/tuxbox/config/supcam-emu/oscam.server  2>/dev/null || true
sleep 0
cp /tmp/server /etc/tuxbox/config/oscamicam/oscam.server  2>/dev/null || true
sleep 0

find / -name "oscam.server" | xargs -I {} cp /tmp/server {}  2>/dev/null || true
rm -rf /tmp/server 2>/dev/null || true

exit
