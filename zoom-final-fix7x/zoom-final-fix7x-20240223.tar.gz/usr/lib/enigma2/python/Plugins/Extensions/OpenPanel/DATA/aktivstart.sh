#!/bin/sh
echo "Již je nainstalováno!!!"
echo "It is already installed !!!" 
exit









