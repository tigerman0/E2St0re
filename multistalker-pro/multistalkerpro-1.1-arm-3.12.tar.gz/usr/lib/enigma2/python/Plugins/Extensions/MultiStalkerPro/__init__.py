from skin import loadSkin
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, fileExists

__version__ = 1.1


def loadPluginSkin():
    skin = resolveFilename(SCOPE_PLUGINS, "Extensions/MultiStalkerPro/assets/skins/skin.xml")
    print("[MultiStalkerPro] load skin", skin)
    if fileExists(skin):
        loadSkin(skin)
