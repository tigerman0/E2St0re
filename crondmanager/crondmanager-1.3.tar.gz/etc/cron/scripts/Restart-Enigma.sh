#!/bin/sh
#DESCRIPTION=This script shows the ecm-, emm- and pid.info for some emu's
init 4; sleep 5; init 3