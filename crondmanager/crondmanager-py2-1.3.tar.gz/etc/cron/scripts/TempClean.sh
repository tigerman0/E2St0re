#!/bin/sh
################################
#####  TSpanel  #####
#######  mFaraj57  #######
####  Tunisia-sat.com  ####
################################
echo $LINE 
echo Temp Cleaner
echo Please Wait
echo $LINE

cd /tmp
rm -rf * > /dev/null 2>&1

echo $LINE
echo Done !

echo $LINE

exit 0